/**
 ******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 ******************************************************************************
 * Copyright 2022 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 ******************************************************************************
 *
 * @modified    Tom Clay, 2026 - Adapted for ReXGlue runtime
 */

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include <SPIRV/GLSL.std.450.h>
#include <fmt/format.h>

#include <rex/assert.h>
#include <rex/graphics/pipeline/shader/spirv.h>
#include <rex/graphics/pipeline/shader/spirv_translator.h>

#include <rex/cvar.h>
#include <rex/math.h>
#include <rex/platform.h>
#include <rex/string/buffer.h>

// The defaults below measured on Android's Adreno also apply to Linux on ARM
// handhelds (ArmadaOS on the Odin 2 Portal: Mesa Turnip, Adreno 740). There
// the five together took a free-roam drive from 20.4 to 16.4 ms of GPU a frame
// (median, same spot, one run each), from 99.8 % of frames over 17.5 ms to
// 0.1 %. Desktop GPUs measured no gain from bindless or the texel buffer.
#if REX_PLATFORM_ANDROID || (REX_PLATFORM_GNU_LINUX && defined(REX_ARCH_ARM64))
#define REX_MOBILE_GPU_DEFAULTS 1
#else
#define REX_MOBILE_GPU_DEFAULTS 0
#endif

// On Android: Adreno has no pushed pixel textures (see the command processor),
// so each change allocated and wrote a set; on the Odin 2 Portal bindless takes
// the recorder's CPU from 9.25 and 9.05 to 7.67 and 7.81 ms a frame (two pairs).
REXCVAR_DEFINE_BOOL(vulkan_bindless_textures, REX_MOBILE_GPU_DEFAULTS, "GPU/Vulkan",
                    "Bind textures and samplers from one long-lived descriptor set indexed by "
                    "per-draw indices instead of per-draw descriptor sets and pushes, on devices "
                    "with Vulkan 1.2 descriptor indexing (RECORDER_PER_DRAW_BACKLOG PD-4)")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);
// On Android: the rule was most of a typical FH1 vertex shader on the
// Adreno 740 (a depth-only one: 81 multiplies, 88 compares, 94 selects and 81
// minimums). Without it the Odin 2 Portal's frame-600 replay falls from 14.19
// to 13.87 ms, and that frame, free roam, a race, photo mode and the title
// replay byte-identical.
REXCVAR_DEFINE_BOOL(spirv_ieee_vertex_math, REX_MOBILE_GPU_DEFAULTS, "GPU",
                    "Vulkan: vertex shaders multiply as IEEE floats, without the Direct3D 9 "
                    "rule that 0 * anything = 0 (a compare and a select per product). "
                    "Products stay unfused, so positions match between passes; a 0 * Inf "
                    "vertex comes out NaN")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

// On Android: the Odin 2 Portal's 1x drive GPU frame falls about 4 ms (36 to
// 32), with only scattered pixels of foliage and shadow noise changing. That
// was with plain IEEE products, whose 0 * Inf = NaN smeared the scene (#403);
// with the NaN check the Thor's parked scene pass is 10.4 ms, as with the full
// rule, against 10.0 ms with plain products. On macOS: an M4 Pro free-roam
// drive's median frame falls from 10.9 to 8.6 ms (two runs each), brightness
// and the image unchanged against Windows.
REXCVAR_DEFINE_BOOL(spirv_fast_pixel_math, REX_MOBILE_GPU_DEFAULTS || REX_PLATFORM_MAC, "GPU",
                    "Vulkan: in pixel shaders, apply the Direct3D 9 multiply rule (0 * anything "
                    "= 0) only to products that come out NaN, and let the driver fuse "
                    "multiply-adds. Less pixel shader work at high scales; a NaN operand times "
                    "a nonzero one also gives 0")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

// On Android: the Odin 2 Portal's 1x drive frame falls about 3 ms (6 %) when
// the texture sign switches fold away. On macOS the M4 Pro drive's median
// frame falls from 10.9 to 9.8 ms.
REXCVAR_DEFINE_BOOL(spirv_specialize_texture_signs, REX_MOBILE_GPU_DEFAULTS || REX_PLATFORM_MAC, "GPU",
                    "Vulkan: make each texture fetch's signedness (unsigned, signed, biased, "
                    "gamma) a specialization constant set from the bound textures when the "
                    "pipeline is created, so drivers fold the per-fetch switch away; pipelines "
                    "made without it read the signedness at run time as before")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

// Turnip on the Odin 2 Portal (Adreno 740): 6 % off the frame at 4x MSAA,
// the image unchanged but for a few pixels at level transitions. Qualcomm's
// own driver gained nothing.
REXCVAR_DEFINE_BOOL(spirv_implicit_lod_2d_turnip, false, "GPU",
                    "Vulkan: on Mesa Turnip, sample 2D textures in pixel shaders with implicit "
                    "LOD as spirv_implicit_lod_2d does. Off by default: on the Adreno 740 some "
                    "2x2 quads of FH1's flags, signs and foliage then sample wrong mips, "
                    "speckles that change every frame")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

// The Turnip speckles came from fetches some pixels of a quad skip: in a
// per-pixel predicated exec or instruction, a loop or a program with jumps,
// implicit derivatives are undefined. The rest are safe, and FH1's full-screen
// passes are among them.
REXCVAR_DEFINE_BOOL(spirv_implicit_lod_2d_uniform_turnip, true, "GPU",
                    "Vulkan: on Mesa Turnip, sample 2D textures in pixel shaders with implicit "
                    "LOD where every pixel of the quad runs the fetch (no per-pixel predicate, "
                    "loop or jump around it), as spirv_implicit_lod_2d does everywhere")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

REXCVAR_DEFINE_BOOL(spirv_implicit_lod_2d, false, "GPU",
                    "Vulkan: sample 2D textures whose level the pixel shader computes with "
                    "implicit level of detail plus the bias, as cube maps already are, "
                    "instead of explicit gradients - cheaper on tiled mobile GPUs")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

// The Adreno 740's 128 MB storage buffer range split shared memory into four
// bindings, and each vertex fetch word was a switch whose loads Turnip
// serializes (548 instructions and about 470 stalled cycles in a typical FH1
// vertex shader, 252 and 51 with one texel buffer). The Odin 2 Portal's
// frame-600 replay: 16.65 to 15.01 ms at 1x, 20.48 to 18.9 at 4x, the image
// bit-identical.
REXCVAR_DEFINE_BOOL(vulkan_shared_memory_texel_buffer, REX_MOBILE_GPU_DEFAULTS, "GPU/Vulkan",
                    "Read shared memory (vertex fetches) through one R32_UINT uniform texel "
                    "buffer over all 512 MB on devices whose storage buffer range is smaller, "
                    "instead of a switch over several storage buffer bindings")
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

namespace rex::graphics {

spv::Id SpirvShaderTranslator::TextureSignsWord(uint32_t fetch_constant_index,
                                                spv::Id system_constant_word) {
  if (!REXCVAR_GET(spirv_specialize_texture_signs)) {
    return system_constant_word;
  }
  const uint32_t word = (fetch_constant_index >> 2) & 7;
  if (spec_texture_signs_[word] == spv::NoResult) {
    spv::Id spec = builder_->makeUintConstant(kTextureSignsDynamic, true);
    builder_->addDecoration(spec, spv::DecorationSpecId,
                            int(kSpecConstantTextureSignsFirst + word));
    spec_texture_signs_[word] = spec;
  }
  spv::Id spec = spec_texture_signs_[word];
  return builder_->createTriOp(
      spv::OpSelect, type_uint_,
      builder_->createBinOp(spv::OpINotEqual, type_bool_, spec,
                            builder_->makeUintConstant(kTextureSignsDynamic)),
      spec, system_constant_word);
}

SpirvShaderTranslator::Features::Features(bool all)
    : spirv_version(all ? spv::Spv_1_5 : spv::Spv_1_0),
      max_storage_buffer_range(all ? UINT32_MAX : (128 * 1024 * 1024)),
      full_draw_index_uint32(all),
      vertex_pipeline_stores_and_atomics(all),
      fragment_stores_and_atomics(all),
      clip_distance(all),
      cull_distance(all),
      image_view_format_swizzle(all),
      signed_zero_inf_nan_preserve_float32(all),
      denorm_flush_to_zero_float32(all),
      rounding_mode_rte_float32(all),
      fragment_shader_sample_interlock(all),
      demote_to_helper_invocation(all),
      sample_rate_shading(all),
      quad_operations_fragment(all),
      bindless_textures(false),
      implicit_lod_2d(false),
      implicit_lod_2d_uniform(false),
      shared_memory_texel_buffer(false) {}

SpirvShaderTranslator::Features::Features(const ui::vulkan::VulkanDevice* const vulkan_device)
    : max_storage_buffer_range(vulkan_device->properties().maxStorageBufferRange),
      full_draw_index_uint32(vulkan_device->properties().fullDrawIndexUint32),
      vertex_pipeline_stores_and_atomics(
          vulkan_device->properties().vertexPipelineStoresAndAtomics),
      fragment_stores_and_atomics(vulkan_device->properties().fragmentStoresAndAtomics),
      clip_distance(vulkan_device->properties().shaderClipDistance),
      cull_distance(vulkan_device->properties().shaderCullDistance),
      image_view_format_swizzle(vulkan_device->properties().imageViewFormatSwizzle),
      signed_zero_inf_nan_preserve_float32(
          vulkan_device->properties().shaderSignedZeroInfNanPreserveFloat32),
      denorm_flush_to_zero_float32(vulkan_device->properties().shaderDenormFlushToZeroFloat32),
      rounding_mode_rte_float32(vulkan_device->properties().shaderRoundingModeRTEFloat32),
      fragment_shader_sample_interlock(vulkan_device->properties().fragmentShaderSampleInterlock),
      demote_to_helper_invocation(vulkan_device->properties().shaderDemoteToHelperInvocation),
      sample_rate_shading(vulkan_device->properties().sampleRateShading),
      quad_operations_fragment(vulkan_device->properties().subgroupQuadFragment),
      implicit_lod_2d(REXCVAR_GET(spirv_implicit_lod_2d) ||
                      (REXCVAR_GET(spirv_implicit_lod_2d_turnip) &&
                       vulkan_device->properties().driverID == VK_DRIVER_ID_MESA_TURNIP)),
      implicit_lod_2d_uniform(REXCVAR_GET(spirv_implicit_lod_2d_uniform_turnip) &&
                              vulkan_device->properties().driverID ==
                                  VK_DRIVER_ID_MESA_TURNIP) {
  const uint32_t vulkan_api_version = vulkan_device->properties().apiVersion;
  if (vulkan_api_version >= VK_MAKE_API_VERSION(0, 1, 2, 0)) {
    spirv_version = spv::Spv_1_5;
  } else if (vulkan_device->extensions().ext_1_2_KHR_spirv_1_4) {
    spirv_version = spv::Spv_1_4;
  } else if (vulkan_api_version >= VK_MAKE_API_VERSION(0, 1, 1, 0)) {
    spirv_version = spv::Spv_1_3;
  } else {
    spirv_version = spv::Spv_1_0;
  }
  if (spirv_version < spv::Spv_1_3) {
    quad_operations_fragment = false;
  }
  const auto& device_properties = vulkan_device->properties();
  bindless_textures = REXCVAR_GET(vulkan_bindless_textures) &&
                      vulkan_api_version >= VK_MAKE_API_VERSION(0, 1, 2, 0) &&
                      device_properties.shaderSampledImageArrayDynamicIndexing &&
                      device_properties.runtimeDescriptorArray &&
                      device_properties.descriptorBindingSampledImageUpdateAfterBind &&
                      device_properties.descriptorBindingPartiallyBound &&
                      device_properties.descriptorBindingUpdateUnusedWhilePending &&
                      // The sizes VulkanTextureCache::InitializeBindless needs.
                      device_properties.maxPerStageDescriptorUpdateAfterBindSampledImages >=
                          12288 &&
                      device_properties.maxDescriptorSetUpdateAfterBindSampledImages >= 12288 &&
                      device_properties.maxUpdateAfterBindDescriptorsInAllPools >= 24576 &&
                      device_properties.maxPerStageDescriptorUpdateAfterBindSamplers >= 256 &&
                      device_properties.maxDescriptorSetUpdateAfterBindSamplers >= 256;
  // R32_UINT uniform texel buffers are required by Vulkan, only the element
  // count limit varies.
  shared_memory_texel_buffer =
      REXCVAR_GET(vulkan_shared_memory_texel_buffer) &&
      GetSharedMemoryStorageBufferCountLog2(max_storage_buffer_range) != 0 &&
      // 512 MB in dwords.
      device_properties.maxTexelBufferElements >= (UINT32_C(1) << 27);
}

uint64_t SpirvShaderTranslator::GetDefaultVertexShaderModification(
    uint32_t dynamic_addressable_register_count,
    Shader::HostVertexShaderType host_vertex_shader_type) const {
  Modification shader_modification;
  shader_modification.vertex.dynamic_addressable_register_count =
      dynamic_addressable_register_count;
  shader_modification.vertex.host_vertex_shader_type = host_vertex_shader_type;
  return shader_modification.value;
}

uint64_t SpirvShaderTranslator::GetDefaultPixelShaderModification(
    uint32_t dynamic_addressable_register_count) const {
  Modification shader_modification;
  shader_modification.pixel.dynamic_addressable_register_count = dynamic_addressable_register_count;
  return shader_modification.value;
}

std::vector<uint8_t> SpirvShaderTranslator::CreateDepthOnlyFragmentShader(
    Modification::DepthStencilMode depth_stencil_mode) {
  is_depth_only_fragment_shader_ = true;
  // TODO(Triang3l): Handle in a nicer way (is_depth_only_fragment_shader_ is a
  // leftover from when a Shader object wasn't used during translation).
  Shader shader(xenos::ShaderType::kPixel, 0, nullptr, 0);
  string::StringBuffer instruction_disassembly_buffer;
  shader.AnalyzeUcode(instruction_disassembly_buffer);
  Modification modification(GetDefaultPixelShaderModification(0));
  modification.pixel.depth_stencil_mode = depth_stencil_mode;
  Shader::Translation& translation = *shader.GetOrCreateTranslation(modification.value);
  TranslateAnalyzedShader(translation);
  is_depth_only_fragment_shader_ = false;
  return translation.translated_binary();
}

void SpirvShaderTranslator::Reset() {
  ShaderTranslator::Reset();

  builder_.reset();

  uniform_float_constants_ = spv::NoResult;

  input_vertex_index_ = spv::NoResult;
  input_primitive_id_ = spv::NoResult;
  input_tess_coord_ = spv::NoResult;
  input_patch_control_point_indices_ = spv::NoResult;
  input_point_coordinates_ = spv::NoResult;
  input_fragment_coordinates_ = spv::NoResult;
  input_front_facing_ = spv::NoResult;
  input_sample_id_ = spv::NoResult;
  input_sample_mask_ = spv::NoResult;
  std::fill(input_output_interpolators_.begin(), input_output_interpolators_.end(), spv::NoResult);
  output_point_coordinates_ = spv::NoResult;
  output_point_size_ = spv::NoResult;
  output_per_vertex_member_count_ = 0;
  output_per_vertex_member_clip_distance_ = UINT32_MAX;
  output_per_vertex_member_cull_distance_ = UINT32_MAX;
  type_output_per_vertex_ = spv::NoResult;
  output_per_vertex_ = spv::NoResult;
  output_fragment_depth_ = spv::NoResult;
  output_fragment_sample_mask_ = spv::NoResult;

  sampler_bindings_.clear();
  texture_bindings_.clear();

  main_interface_.clear();
  var_main_registers_ = spv::NoResult;
  var_main_memexport_address_ = spv::NoResult;
  for (size_t memexport_eM_index = 0; memexport_eM_index < rex::countof(var_main_memexport_data_);
       ++memexport_eM_index) {
    var_main_memexport_data_[memexport_eM_index] = spv::NoResult;
  }
  var_main_memexport_data_written_ = spv::NoResult;
  main_memexport_allowed_ = spv::NoResult;
  var_main_rectangle_guest_vertex_index_ = spv::NoResult;
  var_main_rectangle_per_vertex_ = spv::NoResult;
  std::fill(var_main_rectangle_clip_distances_.begin(), var_main_rectangle_clip_distances_.end(),
            spv::NoResult);
  std::fill(var_main_rectangle_cull_distances_.begin(), var_main_rectangle_cull_distances_.end(),
            spv::NoResult);
  std::fill(var_main_rectangle_interpolators_.begin(), var_main_rectangle_interpolators_.end(),
            spv::NoResult);
  var_main_point_size_edge_flag_kill_vertex_ = spv::NoResult;
  var_main_kill_pixel_ = spv::NoResult;
  var_main_fragment_depth_ = spv::NoResult;
  var_main_fsi_color_written_ = spv::NoResult;

  main_switch_op_.reset();
  main_switch_next_pc_phi_operands_.clear();
  main_loop_exit_ = nullptr;

  cf_exec_conditional_merge_ = nullptr;
  cf_instruction_predicate_merge_ = nullptr;
  cf_loop_depth_ = 0;
}

uint32_t SpirvShaderTranslator::GetModificationRegisterCount() const {
  Modification modification = GetSpirvShaderModification();
  return is_vertex_shader() ? modification.vertex.dynamic_addressable_register_count
                            : modification.pixel.dynamic_addressable_register_count;
}

void SpirvShaderTranslator::StartTranslation() {
  // TODO(Triang3l): Logger.
  builder_ = std::make_unique<SpirvBuilder>(features_.spirv_version, (kSpirvMagicToolId << 16) | 1,
                                            nullptr);
  // Depth must match between passes, so shaders writing it stay exact.
  fast_pixel_math_ = REXCVAR_GET(spirv_fast_pixel_math) && is_pixel_shader() &&
                     !current_shader().writes_depth();
  builder_->allow_contraction = fast_pixel_math_;
  ieee_math_ = REXCVAR_GET(spirv_ieee_vertex_math) && is_vertex_shader();
  std::fill(std::begin(spec_texture_signs_), std::end(spec_texture_signs_), spv::NoResult);

  builder_->addCapability(IsSpirvTessEvalShader() ? spv::CapabilityTessellation
                                                  : spv::CapabilityShader);
  if (features_.spirv_version < spv::Spv_1_4) {
    if (features_.signed_zero_inf_nan_preserve_float32 || features_.denorm_flush_to_zero_float32 ||
        features_.rounding_mode_rte_float32) {
      builder_->addExtension("SPV_KHR_float_controls");
    }
  }
  ext_inst_glsl_std_450_ = builder_->import("GLSL.std.450");
  builder_->setMemoryModel(spv::AddressingModelLogical, spv::MemoryModelGLSL450);
  builder_->setSource(spv::SourceLanguageUnknown, 0);

  type_void_ = builder_->makeVoidType();
  type_bool_ = builder_->makeBoolType();
  type_bool2_ = builder_->makeVectorType(type_bool_, 2);
  type_bool3_ = builder_->makeVectorType(type_bool_, 3);
  type_bool4_ = builder_->makeVectorType(type_bool_, 4);
  type_int_ = builder_->makeIntType(32);
  type_int2_ = builder_->makeVectorType(type_int_, 2);
  type_int3_ = builder_->makeVectorType(type_int_, 3);
  type_int4_ = builder_->makeVectorType(type_int_, 4);
  type_uint_ = builder_->makeUintType(32);
  type_uint2_ = builder_->makeVectorType(type_uint_, 2);
  type_uint3_ = builder_->makeVectorType(type_uint_, 3);
  type_uint4_ = builder_->makeVectorType(type_uint_, 4);
  type_float_ = builder_->makeFloatType(32);
  type_float2_ = builder_->makeVectorType(type_float_, 2);
  type_float3_ = builder_->makeVectorType(type_float_, 3);
  type_float4_ = builder_->makeVectorType(type_float_, 4);

  const_int_0_ = builder_->makeIntConstant(0);
  id_vector_temp_.clear();
  for (uint32_t i = 0; i < 4; ++i) {
    id_vector_temp_.push_back(const_int_0_);
  }
  const_int4_0_ = builder_->makeCompositeConstant(type_int4_, id_vector_temp_);
  const_uint_0_ = builder_->makeUintConstant(0);
  id_vector_temp_.clear();
  for (uint32_t i = 0; i < 4; ++i) {
    id_vector_temp_.push_back(const_uint_0_);
  }
  const_uint4_0_ = builder_->makeCompositeConstant(type_uint4_, id_vector_temp_);
  const_float_0_ = builder_->makeFloatConstant(0.0f);
  id_vector_temp_.clear();
  id_vector_temp_.push_back(const_float_0_);
  for (uint32_t i = 1; i < 4; ++i) {
    id_vector_temp_.push_back(const_float_0_);
    const_float_vectors_0_[i] =
        builder_->makeCompositeConstant(type_float_vectors_[i], id_vector_temp_);
  }
  const_float_1_ = builder_->makeFloatConstant(1.0f);
  id_vector_temp_.clear();
  id_vector_temp_.push_back(const_float_1_);
  for (uint32_t i = 1; i < 4; ++i) {
    id_vector_temp_.push_back(const_float_1_);
    const_float_vectors_1_[i] =
        builder_->makeCompositeConstant(type_float_vectors_[i], id_vector_temp_);
  }
  id_vector_temp_.clear();
  id_vector_temp_.push_back(const_float_0_);
  id_vector_temp_.push_back(const_float_1_);
  const_float2_0_1_ = builder_->makeCompositeConstant(type_float2_, id_vector_temp_);

  // Common uniform buffer - system constants.
  struct SystemConstant {
    const char* name;
    size_t offset;
    spv::Id type;
  };
  spv::Id type_float4_array_4 =
      builder_->makeArrayType(type_float4_, builder_->makeUintConstant(4), sizeof(float) * 4);
  builder_->addDecoration(type_float4_array_4, spv::DecorationArrayStride, sizeof(float) * 4);
  spv::Id type_float4_array_6 =
      builder_->makeArrayType(type_float4_, builder_->makeUintConstant(6), sizeof(float) * 4);
  builder_->addDecoration(type_float4_array_6, spv::DecorationArrayStride, sizeof(float) * 4);
  spv::Id type_uint4_array_2 =
      builder_->makeArrayType(type_uint4_, builder_->makeUintConstant(2), sizeof(uint32_t) * 4);
  builder_->addDecoration(type_uint4_array_2, spv::DecorationArrayStride, sizeof(uint32_t) * 4);
  spv::Id type_uint4_array_4 =
      builder_->makeArrayType(type_uint4_, builder_->makeUintConstant(4), sizeof(uint32_t) * 4);
  builder_->addDecoration(type_uint4_array_4, spv::DecorationArrayStride, sizeof(uint32_t) * 4);
  const SystemConstant system_constants[] = {
      {"flags", offsetof(SystemConstants, flags), type_uint_},
      {"vertex_index_load_address", offsetof(SystemConstants, vertex_index_load_address),
       type_uint_},
      {"vertex_index_endian", offsetof(SystemConstants, vertex_index_endian), type_uint_},
      {"line_loop_closing_index", offsetof(SystemConstants, line_loop_closing_index), type_uint_},
      {"vertex_base_index", offsetof(SystemConstants, vertex_base_index), type_int_},
      {"vertex_index_reset", offsetof(SystemConstants, vertex_index_reset), type_uint_},
      {"compute_memexport_vertex_count", offsetof(SystemConstants, compute_memexport_vertex_count),
       type_uint_},
      {"user_clip_planes", offsetof(SystemConstants, user_clip_planes), type_float4_array_6},
      {"vertex_index_min", offsetof(SystemConstants, vertex_index_min), type_uint_},
      {"vertex_index_max", offsetof(SystemConstants, vertex_index_max), type_uint_},
      {"ndc_scale", offsetof(SystemConstants, ndc_scale), type_float3_},
      {"point_vertex_diameter_min", offsetof(SystemConstants, point_vertex_diameter_min),
       type_float_},
      {"ndc_offset", offsetof(SystemConstants, ndc_offset), type_float3_},
      {"point_vertex_diameter_max", offsetof(SystemConstants, point_vertex_diameter_max),
       type_float_},
      {"point_constant_diameter", offsetof(SystemConstants, point_constant_diameter), type_float2_},
      {"point_screen_diameter_to_ndc_radius",
       offsetof(SystemConstants, point_screen_diameter_to_ndc_radius), type_float2_},
      {"textures_resolution_scaled", offsetof(SystemConstants, textures_resolution_scaled),
       type_uint_},
      {"texture_swizzled_signs", offsetof(SystemConstants, texture_swizzled_signs),
       type_uint4_array_2},
      {"texture_swizzles", offsetof(SystemConstants, texture_swizzles), type_uint4_array_4},
      {"alpha_test_reference", offsetof(SystemConstants, alpha_test_reference), type_float_},
      {"alpha_to_mask", offsetof(SystemConstants, alpha_to_mask), type_uint_},
      {"edram_32bpp_tile_pitch_dwords_scaled",
       offsetof(SystemConstants, edram_32bpp_tile_pitch_dwords_scaled), type_uint_},
      {"edram_depth_base_dwords_scaled", offsetof(SystemConstants, edram_depth_base_dwords_scaled),
       type_uint_},
      {"color_exp_bias", offsetof(SystemConstants, color_exp_bias), type_float4_},
      {"edram_poly_offset_front_scale", offsetof(SystemConstants, edram_poly_offset_front_scale),
       type_float_},
      {"edram_poly_offset_back_scale", offsetof(SystemConstants, edram_poly_offset_back_scale),
       type_float_},
      {"edram_poly_offset_front_offset", offsetof(SystemConstants, edram_poly_offset_front_offset),
       type_float_},
      {"edram_poly_offset_back_offset", offsetof(SystemConstants, edram_poly_offset_back_offset),
       type_float_},
      {"edram_stencil_front", offsetof(SystemConstants, edram_stencil_front), type_uint2_},
      {"edram_stencil_back", offsetof(SystemConstants, edram_stencil_back), type_uint2_},
      {"edram_rt_base_dwords_scaled", offsetof(SystemConstants, edram_rt_base_dwords_scaled),
       type_uint4_},
      {"edram_rt_format_flags", offsetof(SystemConstants, edram_rt_format_flags), type_uint4_},
      {"edram_rt_blend_factors_ops", offsetof(SystemConstants, edram_rt_blend_factors_ops),
       type_uint4_},
      {"edram_rt_keep_mask", offsetof(SystemConstants, edram_rt_keep_mask), type_uint4_array_2},
      {"edram_rt_clamp", offsetof(SystemConstants, edram_rt_clamp), type_float4_array_4},
      {"edram_blend_constant", offsetof(SystemConstants, edram_blend_constant), type_float4_},
      {"object_slot", offsetof(SystemConstants, object_slot), type_uint_},
      {"object_row_offset", offsetof(SystemConstants, object_row_offset), type_int_},
  };
  // UP-1.7: the object slot constants (last) only in the shaders that write
  // it, so the others translate as before.
  const size_t system_constant_count =
      rex::countof(system_constants) -
      (is_pixel_shader() && !edram_fragment_shader_interlock_ &&
               GetSpirvShaderModification().pixel.object_slot_output
           ? 0
           : 2);
  id_vector_temp_.clear();
  id_vector_temp_.reserve(system_constant_count);
  for (size_t i = 0; i < system_constant_count; ++i) {
    id_vector_temp_.push_back(system_constants[i].type);
  }
  spv::Id type_system_constants = builder_->makeStructType(id_vector_temp_, "XeSystemConstants");
  for (size_t i = 0; i < system_constant_count; ++i) {
    const SystemConstant& system_constant = system_constants[i];
    builder_->addMemberName(type_system_constants, static_cast<unsigned int>(i),
                            system_constant.name);
    builder_->addMemberDecoration(type_system_constants, static_cast<unsigned int>(i),
                                  spv::DecorationOffset, int(system_constant.offset));
  }
  builder_->addDecoration(type_system_constants, spv::DecorationBlock);
  uniform_system_constants_ =
      builder_->createVariable(spv::NoPrecision, spv::StorageClassUniform, type_system_constants,
                               "xe_uniform_system_constants");
  builder_->addDecoration(uniform_system_constants_, spv::DecorationDescriptorSet,
                          int(kDescriptorSetConstants));
  builder_->addDecoration(uniform_system_constants_, spv::DecorationBinding,
                          int(kConstantBufferSystem));
  if (features_.spirv_version >= spv::Spv_1_4) {
    main_interface_.push_back(uniform_system_constants_);
  }

  bool memexport_used = IsMemoryExportUsed();

  if (!is_depth_only_fragment_shader_) {
    // Common uniform buffer - float constants.
    uint32_t float_constant_count = current_shader().constant_register_map().float_count;
    if (float_constant_count) {
      id_vector_temp_.clear();
      id_vector_temp_.push_back(builder_->makeArrayType(
          type_float4_, builder_->makeUintConstant(float_constant_count), sizeof(float) * 4));
      // Currently (as of October 24, 2020) makeArrayType only uses the stride
      // to check if deduplication can be done - the array stride decoration
      // needs to be applied explicitly.
      builder_->addDecoration(id_vector_temp_.back(), spv::DecorationArrayStride,
                              sizeof(float) * 4);
      spv::Id type_float_constants = builder_->makeStructType(id_vector_temp_, "XeFloatConstants");
      builder_->addMemberName(type_float_constants, 0, "float_constants");
      builder_->addMemberDecoration(type_float_constants, 0, spv::DecorationOffset, 0);
      builder_->addDecoration(type_float_constants, spv::DecorationBlock);
      uniform_float_constants_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassUniform, type_float_constants,
                                   "xe_uniform_float_constants");
      builder_->addDecoration(uniform_float_constants_, spv::DecorationDescriptorSet,
                              int(kDescriptorSetConstants));
      builder_->addDecoration(
          uniform_float_constants_, spv::DecorationBinding,
          int(is_pixel_shader() ? kConstantBufferFloatPixel : kConstantBufferFloatVertex));
      if (features_.spirv_version >= spv::Spv_1_4) {
        main_interface_.push_back(uniform_float_constants_);
      }
    }

    // Common uniform buffer - bool and loop constants.
    // Uniform buffers must have std140 packing, so using arrays of 4-component
    // vectors instead of scalar arrays because the latter would have padding to
    // 16 bytes in each element.
    id_vector_temp_.clear();
    // 256 bool constants.
    id_vector_temp_.push_back(
        builder_->makeArrayType(type_uint4_, builder_->makeUintConstant(2), sizeof(uint32_t) * 4));
    builder_->addDecoration(id_vector_temp_.back(), spv::DecorationArrayStride,
                            sizeof(uint32_t) * 4);
    // 32 loop constants.
    id_vector_temp_.push_back(
        builder_->makeArrayType(type_uint4_, builder_->makeUintConstant(8), sizeof(uint32_t) * 4));
    builder_->addDecoration(id_vector_temp_.back(), spv::DecorationArrayStride,
                            sizeof(uint32_t) * 4);
    spv::Id type_bool_loop_constants =
        builder_->makeStructType(id_vector_temp_, "XeBoolLoopConstants");
    builder_->addMemberName(type_bool_loop_constants, 0, "bool_constants");
    builder_->addMemberDecoration(type_bool_loop_constants, 0, spv::DecorationOffset, 0);
    builder_->addMemberName(type_bool_loop_constants, 1, "loop_constants");
    builder_->addMemberDecoration(type_bool_loop_constants, 1, spv::DecorationOffset,
                                  sizeof(uint32_t) * 8);
    builder_->addDecoration(type_bool_loop_constants, spv::DecorationBlock);
    uniform_bool_loop_constants_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassUniform,
                                 type_bool_loop_constants, "xe_uniform_bool_loop_constants");
    builder_->addDecoration(uniform_bool_loop_constants_, spv::DecorationDescriptorSet,
                            int(kDescriptorSetConstants));
    builder_->addDecoration(uniform_bool_loop_constants_, spv::DecorationBinding,
                            int(kConstantBufferBoolLoop));
    if (features_.spirv_version >= spv::Spv_1_4) {
      main_interface_.push_back(uniform_bool_loop_constants_);
    }

    for (spv::Id& bindless_array : bindless_arrays_) {
      bindless_array = spv::NoResult;
    }
    // Common uniform buffer - fetch constants (32 x 6 uints packed in std140 as
    // 4-component vectors).
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeArrayType(
        type_uint4_, builder_->makeUintConstant(32 * 6 / 4), sizeof(uint32_t) * 4));
    builder_->addDecoration(id_vector_temp_.back(), spv::DecorationArrayStride,
                            sizeof(uint32_t) * 4);
    if (features_.bindless_textures) {
      // PD-4: the draw's bindless indices follow the fetch constants.
      id_vector_temp_.push_back(builder_->makeArrayType(
          type_uint4_, builder_->makeUintConstant(kBindlessIndicesBytes / (sizeof(uint32_t) * 4)),
          sizeof(uint32_t) * 4));
      builder_->addDecoration(id_vector_temp_.back(), spv::DecorationArrayStride,
                              sizeof(uint32_t) * 4);
    }
    spv::Id type_fetch_constants = builder_->makeStructType(id_vector_temp_, "XeFetchConstants");
    builder_->addMemberName(type_fetch_constants, 0, "fetch_constants");
    builder_->addMemberDecoration(type_fetch_constants, 0, spv::DecorationOffset, 0);
    if (features_.bindless_textures) {
      builder_->addMemberName(type_fetch_constants, 1, "bindless_indices");
      builder_->addMemberDecoration(type_fetch_constants, 1, spv::DecorationOffset,
                                    int(kFetchConstantsBytes));
    }
    builder_->addDecoration(type_fetch_constants, spv::DecorationBlock);
    uniform_fetch_constants_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassUniform, type_fetch_constants,
                                 "xe_uniform_fetch_constants");
    builder_->addDecoration(uniform_fetch_constants_, spv::DecorationDescriptorSet,
                            int(kDescriptorSetConstants));
    builder_->addDecoration(uniform_fetch_constants_, spv::DecorationBinding,
                            int(kConstantBufferFetch));
    if (features_.spirv_version >= spv::Spv_1_4) {
      main_interface_.push_back(uniform_fetch_constants_);
    }

    // Common storage buffers - shared memory uint[], each 128 MB or larger,
    // depending on what's possible on the device.
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeRuntimeArray(type_uint_));
    // Storage buffers have std430 packing, no padding to 4-component vectors.
    builder_->addDecoration(id_vector_temp_.back(), spv::DecorationArrayStride, sizeof(uint32_t));
    spv::Id type_shared_memory = builder_->makeStructType(id_vector_temp_, "XeSharedMemory");
    builder_->addMemberName(type_shared_memory, 0, "shared_memory");
    builder_->addMemberDecoration(type_shared_memory, 0, spv::DecorationRestrict);
    if (!memexport_used) {
      builder_->addMemberDecoration(type_shared_memory, 0, spv::DecorationNonWritable);
    }
    builder_->addMemberDecoration(type_shared_memory, 0, spv::DecorationOffset, 0);
    builder_->addDecoration(type_shared_memory, features_.spirv_version >= spv::Spv_1_3
                                                    ? spv::DecorationBlock
                                                    : spv::DecorationBufferBlock);
    unsigned int shared_memory_binding_count = 1 << GetSharedMemoryStorageBufferCountLog2();
    if (shared_memory_binding_count > 1) {
      type_shared_memory = builder_->makeArrayType(
          type_shared_memory, builder_->makeUintConstant(shared_memory_binding_count), 0);
    }
    buffers_shared_memory_ = builder_->createVariable(spv::NoPrecision,
                                                      features_.spirv_version >= spv::Spv_1_3
                                                          ? spv::StorageClassStorageBuffer
                                                          : spv::StorageClassUniform,
                                                      type_shared_memory, "xe_shared_memory");
    builder_->addDecoration(buffers_shared_memory_, spv::DecorationDescriptorSet,
                            int(kDescriptorSetSharedMemoryAndEdram));
    builder_->addDecoration(buffers_shared_memory_, spv::DecorationBinding, 0);
    if (features_.spirv_version >= spv::Spv_1_4) {
      main_interface_.push_back(buffers_shared_memory_);
    }
    texel_buffer_shared_memory_ = spv::NoResult;
    if (features_.shared_memory_texel_buffer) {
      builder_->addCapability(spv::CapabilitySampledBuffer);
      texel_buffer_shared_memory_ = builder_->createVariable(
          spv::NoPrecision, spv::StorageClassUniformConstant,
          builder_->makeImageType(type_uint_, spv::DimBuffer, false, false, false, 1,
                                  spv::ImageFormatUnknown),
          "xe_shared_memory_texel_buffer");
      builder_->addDecoration(texel_buffer_shared_memory_, spv::DecorationDescriptorSet,
                              int(kDescriptorSetSharedMemoryAndEdram));
      builder_->addDecoration(texel_buffer_shared_memory_, spv::DecorationBinding,
                              int(kSharedMemoryTexelBufferBinding));
      if (features_.spirv_version >= spv::Spv_1_4) {
        main_interface_.push_back(texel_buffer_shared_memory_);
      }
    }
  }

  if (is_vertex_shader()) {
    StartVertexOrTessEvalShaderBeforeMain();
  } else if (is_pixel_shader()) {
    StartFragmentShaderBeforeMain();
  }

  // Begin the main function.
  std::vector<spv::Id> main_param_types;
  std::vector<std::vector<spv::Decoration>> main_precisions;
  spv::Block* function_main_entry;
  function_main_ =
      builder_->makeFunctionEntry(spv::NoPrecision, type_void_, "main", main_param_types,
                                  main_precisions, &function_main_entry);

  // Load the flags system constant since it may be used in many places.
  id_vector_temp_.clear();
  id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantFlags));
  main_system_constant_flags_ =
      builder_->createLoad(builder_->createAccessChain(spv::StorageClassUniform,
                                                       uniform_system_constants_, id_vector_temp_),
                           spv::NoPrecision);

  if (!is_depth_only_fragment_shader_) {
    // Begin ucode translation. Initialize everything, even without defined
    // defaults, for safety.
    var_main_predicate_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_bool_,
                                 "xe_var_predicate", builder_->makeBoolConstant(false));
    var_main_loop_count_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_uint4_,
                                 "xe_var_loop_count", const_uint4_0_);
    var_main_address_register_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_int_,
                                 "xe_var_address_register", const_int_0_);
    var_main_loop_address_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_int4_,
                                 "xe_var_loop_address", const_int4_0_);
    var_main_previous_scalar_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_float_,
                                 "xe_var_previous_scalar", const_float_0_);
    var_main_vfetch_address_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_int_,
                                 "xe_var_vfetch_address", const_int_0_);
    var_main_tfetch_lod_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_float_,
                                 "xe_var_tfetch_lod", const_float_0_);
    var_main_tfetch_gradients_h_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_float3_,
                                 "xe_var_tfetch_gradients_h", const_float3_0_);
    var_main_tfetch_gradients_v_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_float3_,
                                 "xe_var_tfetch_gradients_v", const_float3_0_);
    if (register_count()) {
      spv::Id type_register_array =
          builder_->makeArrayType(type_float4_, builder_->makeUintConstant(register_count()), 1);
      var_main_registers_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction,
                                                     type_register_array, "xe_var_registers");
    }
    if (IsSpirvRectangleListVertexLoopEnabled()) {
      Modification shader_modification = GetSpirvShaderModification();
      var_main_rectangle_guest_vertex_index_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_uint_,
                                   "xe_var_rectangle_guest_vertex_index", const_uint_0_);
      // Keep the interpolated gl_PerVertex members in plain function-local
      // arrays - the block type's BuiltIn and ArrayStride decorations are only
      // valid in Input and Output storage. Desktop drivers accept it anyway,
      // MoltenVK's SPIRV-Cross does not.
      spv::Id type_rectangle_per_vertex_array =
          builder_->makeArrayType(type_float4_, builder_->makeUintConstant(3), 0);
      var_main_rectangle_per_vertex_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction,
                                   type_rectangle_per_vertex_array, "xe_var_rectangle_per_vertex");
      spv::Id type_rectangle_distance_array =
          builder_->makeArrayType(type_float_, builder_->makeUintConstant(3), 0);
      uint32_t clip_distance_count = shader_modification.GetVertexClipDistanceCount();
      assert_true(clip_distance_count <= kMaxRectanglePerVertexDistances);
      for (uint32_t i = 0; i < clip_distance_count; ++i) {
        var_main_rectangle_clip_distances_[i] = builder_->createVariable(
            spv::NoPrecision, spv::StorageClassFunction, type_rectangle_distance_array,
            fmt::format("xe_var_rectangle_clip_distance_{}", i).c_str());
      }
      uint32_t cull_distance_count = shader_modification.GetVertexCullDistanceCount();
      assert_true(cull_distance_count <= kMaxRectanglePerVertexDistances);
      for (uint32_t i = 0; i < cull_distance_count; ++i) {
        var_main_rectangle_cull_distances_[i] = builder_->createVariable(
            spv::NoPrecision, spv::StorageClassFunction, type_rectangle_distance_array,
            fmt::format("xe_var_rectangle_cull_distance_{}", i).c_str());
      }
      uint32_t interpolators_remaining = GetModificationInterpolatorMask();
      uint32_t interpolator_index;
      while (rex::bit_scan_forward(interpolators_remaining, &interpolator_index)) {
        interpolators_remaining &= ~(UINT32_C(1) << interpolator_index);
        spv::Id type_rectangle_interpolator_array =
            builder_->makeArrayType(type_float4_, builder_->makeUintConstant(3), 0);
        var_main_rectangle_interpolators_[interpolator_index] = builder_->createVariable(
            spv::NoPrecision, spv::StorageClassFunction, type_rectangle_interpolator_array,
            fmt::format("xe_var_rectangle_interpolator_{}", interpolator_index).c_str());
      }
    }
    if (memexport_used) {
      var_main_memexport_address_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_float4_,
                                   "xe_var_memexport_address", const_float4_0_);
      uint8_t memexport_eM_remaining = current_shader().memexport_eM_written();
      uint32_t memexport_eM_index;
      while (rex::bit_scan_forward(memexport_eM_remaining, &memexport_eM_index)) {
        memexport_eM_remaining &= ~(uint8_t(1) << memexport_eM_index);
        var_main_memexport_data_[memexport_eM_index] = builder_->createVariable(
            spv::NoPrecision, spv::StorageClassFunction, type_float4_,
            fmt::format("xe_var_memexport_data_{}", memexport_eM_index).c_str(), const_float4_0_);
      }
      var_main_memexport_data_written_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_uint_,
                                   "xe_var_memexport_data_written", const_uint_0_);
    }
  }

  // Write the execution model-specific prologue with access to variables in the
  // main function.
  if (is_vertex_shader()) {
    StartVertexOrTessEvalShaderInMain();
  } else if (is_pixel_shader()) {
    StartFragmentShaderInMain();
  }

  if (is_depth_only_fragment_shader_) {
    return;
  }

  // Open the main loop.
  spv::Block& main_loop_pre_header = *builder_->getBuildPoint();
  main_loop_header_ = &builder_->makeNewBlock();
  spv::Block& main_loop_body = builder_->makeNewBlock();
  // Added later because the body has nested control flow, but according to the
  // specification:
  // "The order of blocks in a function must satisfy the rule that blocks appear
  //  before all blocks they dominate."
  main_loop_continue_ = new spv::Block(builder_->getUniqueId(), *function_main_);
  main_loop_merge_ = new spv::Block(builder_->getUniqueId(), *function_main_);
  main_loop_exit_ = main_loop_merge_;
  if (IsSpirvRectangleListVertexLoopEnabled()) {
    // Need a block in the loop body to converge exits and to decide whether to
    // continue with the next guest rectangle vertex.
    main_loop_exit_ = new spv::Block(builder_->getUniqueId(), *function_main_);
  }
  builder_->createBranch(main_loop_header_);

  // If no jumps, don't create a switch, but still create a loop so exece can
  // break.
  bool has_main_switch = !current_shader().label_addresses().empty();

  // Main loop header - based on whether it's the first iteration (entered from
  // the function or from the continuation), choose the program counter.
  builder_->setBuildPoint(main_loop_header_);
  spv::Id main_loop_pc_current = spv::NoResult;
  if (has_main_switch) {
    // OpPhi must be the first in the block.
    id_vector_temp_.clear();
    id_vector_temp_.push_back(const_int_0_);
    id_vector_temp_.push_back(main_loop_pre_header.getId());
    main_loop_pc_next_ = builder_->getUniqueId();
    id_vector_temp_.push_back(main_loop_pc_next_);
    id_vector_temp_.push_back(main_loop_continue_->getId());
    main_loop_pc_current = builder_->createOp(spv::OpPhi, type_int_, id_vector_temp_);
  }
  uint_vector_temp_.clear();
  builder_->createLoopMerge(main_loop_exit_, main_loop_continue_, spv::LoopControlDontUnrollMask,
                            uint_vector_temp_);
  builder_->createBranch(&main_loop_body);

  // Main loop body.
  builder_->setBuildPoint(&main_loop_body);
  if (has_main_switch) {
    // Create the program counter switch with cases for every label and for
    // label 0.
    main_switch_header_ = builder_->getBuildPoint();
    main_switch_merge_ = new spv::Block(builder_->getUniqueId(), *function_main_);
    builder_->createSelectionMerge(main_switch_merge_, spv::SelectionControlDontFlattenMask);
    main_switch_op_ = std::make_unique<spv::Instruction>(spv::OpSwitch);
    main_switch_op_->addIdOperand(main_loop_pc_current);
    main_switch_op_->addIdOperand(main_switch_merge_->getId());
    // The default case (the merge here) must have the header as a predecessor.
    main_switch_merge_->addPredecessor(main_switch_header_);
    // The instruction will be inserted later, when all cases are filled.
    // Insert and enter case 0.
    spv::Block* main_switch_case_0_block = new spv::Block(builder_->getUniqueId(), *function_main_);
    main_switch_op_->addImmediateOperand(0);
    main_switch_op_->addIdOperand(main_switch_case_0_block->getId());
    // Every switch case must have the OpSelectionMerge/OpSwitch block as a
    // predecessor.
    main_switch_case_0_block->addPredecessor(main_switch_header_);
    function_main_->addBlock(main_switch_case_0_block);
    builder_->setBuildPoint(main_switch_case_0_block);
  }
}

std::vector<uint8_t> SpirvShaderTranslator::CompleteTranslation() {
  bool rectangle_vertex_loop = IsSpirvRectangleListVertexLoopEnabled();
  if (!is_depth_only_fragment_shader_) {
    // Close flow control within the last switch case.
    CloseExecConditionals();
    bool has_main_switch = !current_shader().label_addresses().empty();
    // The rectangle-list vertex loop (below, after the main loop) continues
    // it for the next guest vertex, so its edge into the continuation must be
    // an operand of the program counter OpPhi, which is built first. That
    // edge leaves from a block made now, whose id the OpPhi can name.
    spv::Block* rectangle_next_vertex_block = nullptr;
    if (rectangle_vertex_loop && has_main_switch) {
      rectangle_next_vertex_block = new spv::Block(builder_->getUniqueId(), *function_main_);
      main_switch_next_pc_phi_operands_.push_back(const_int_0_);
      main_switch_next_pc_phi_operands_.push_back(rectangle_next_vertex_block->getId());
    }
    // After the final exec (if it happened to be not exece, which would already
    // have a break branch), break from the switch if it exists, or from the
    // loop it doesn't.
    if (!builder_->getBuildPoint()->isTerminated()) {
      builder_->createBranch(has_main_switch ? main_switch_merge_ : main_loop_merge_);
    }
    if (has_main_switch) {
      // Insert the switch instruction with all cases added as operands.
      builder_->setBuildPoint(main_switch_header_);
      builder_->getBuildPoint()->addInstruction(std::move(main_switch_op_));
      // Build the main switch merge, breaking out of the loop after falling
      // through the end or breaking from exece (only continuing if a jump -
      // from a guest loop or from jmp/call - was made).
      function_main_->addBlock(main_switch_merge_);
      builder_->setBuildPoint(main_switch_merge_);
      builder_->createBranch(main_loop_merge_);
    }

    // Main loop continuation - choose the program counter based on the path
    // taken (-1 if not from a jump as a safe fallback, which would result in
    // not hitting any switch case and reaching the final break in the body).
    function_main_->addBlock(main_loop_continue_);
    builder_->setBuildPoint(main_loop_continue_);
    if (has_main_switch) {
      // OpPhi, if added, must be the first in the block.
      // If labels were added, but not jumps (for example, due to the call
      // instruction not being implemented as of October 18, 2020), send an
      // impossible program counter value (-1) to the OpPhi at the next
      // iteration.
      if (main_switch_next_pc_phi_operands_.empty()) {
        main_switch_next_pc_phi_operands_.push_back(builder_->makeIntConstant(-1));
      }
      std::unique_ptr<spv::Instruction> main_loop_pc_next_op = std::make_unique<spv::Instruction>(
          main_loop_pc_next_, type_int_,
          main_switch_next_pc_phi_operands_.size() >= 2 ? spv::OpPhi : spv::OpCopyObject);
      for (spv::Id operand : main_switch_next_pc_phi_operands_) {
        main_loop_pc_next_op->addIdOperand(operand);
      }
      builder_->getBuildPoint()->addInstruction(std::move(main_loop_pc_next_op));
    }
    builder_->createBranch(main_loop_header_);

    // Add the main loop merge block and go back to the function.
    function_main_->addBlock(main_loop_merge_);
    builder_->setBuildPoint(main_loop_merge_);
    if (rectangle_vertex_loop) {
      // For rectangle-list fallback without geometry shaders, run the guest
      // vertex shader 3 times (for all source vertices), then choose or
      // synthesize the output for the current host strip vertex.
      Modification shader_modification = GetSpirvShaderModification();
      uint32_t clip_distance_count = shader_modification.GetVertexClipDistanceCount();
      uint32_t cull_distance_count = shader_modification.GetVertexCullDistanceCount();

      CompleteVertexOrTessEvalShaderInMain();

      spv::Id rectangle_guest_vertex_index =
          builder_->createLoad(var_main_rectangle_guest_vertex_index_, spv::NoPrecision);
      spv::Id rectangle_guest_vertex_index_int =
          builder_->createUnaryOp(spv::OpBitcast, type_int_, rectangle_guest_vertex_index);

      // Store current iteration outputs, member by member.
      id_vector_temp_.clear();
      id_vector_temp_.push_back(builder_->makeIntConstant(kOutputPerVertexMemberPosition));
      spv::Id rectangle_vertex_position = builder_->createLoad(
          builder_->createAccessChain(spv::StorageClassOutput, output_per_vertex_, id_vector_temp_),
          spv::NoPrecision);
      id_vector_temp_.clear();
      id_vector_temp_.push_back(rectangle_guest_vertex_index_int);
      builder_->createStore(
          rectangle_vertex_position,
          builder_->createAccessChain(spv::StorageClassFunction, var_main_rectangle_per_vertex_,
                                      id_vector_temp_));
      auto store_rectangle_distance_members =
          [this, rectangle_guest_vertex_index_int](
              uint32_t member_index, uint32_t component_count,
              const std::array<spv::Id, kMaxRectanglePerVertexDistances>& variables) {
            for (uint32_t i = 0; i < component_count; ++i) {
              id_vector_temp_.clear();
              id_vector_temp_.push_back(builder_->makeIntConstant(int(member_index)));
              id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
              spv::Id value = builder_->createLoad(
                  builder_->createAccessChain(spv::StorageClassOutput, output_per_vertex_,
                                              id_vector_temp_),
                  spv::NoPrecision);
              id_vector_temp_.clear();
              id_vector_temp_.push_back(rectangle_guest_vertex_index_int);
              builder_->createStore(
                  value, builder_->createAccessChain(spv::StorageClassFunction, variables[i],
                                                     id_vector_temp_));
            }
          };
      if (clip_distance_count && output_per_vertex_member_clip_distance_ != UINT32_MAX) {
        store_rectangle_distance_members(output_per_vertex_member_clip_distance_,
                                         clip_distance_count, var_main_rectangle_clip_distances_);
      }
      if (cull_distance_count && output_per_vertex_member_cull_distance_ != UINT32_MAX) {
        store_rectangle_distance_members(output_per_vertex_member_cull_distance_,
                                         cull_distance_count, var_main_rectangle_cull_distances_);
      }
      uint32_t interpolators_remaining = GetModificationInterpolatorMask();
      uint32_t interpolator_index;
      while (rex::bit_scan_forward(interpolators_remaining, &interpolator_index)) {
        interpolators_remaining &= ~(UINT32_C(1) << interpolator_index);
        id_vector_temp_.clear();
        id_vector_temp_.push_back(rectangle_guest_vertex_index_int);
        builder_->createStore(
            builder_->createLoad(input_output_interpolators_[interpolator_index], spv::NoPrecision),
            builder_->createAccessChain(spv::StorageClassFunction,
                                        var_main_rectangle_interpolators_[interpolator_index],
                                        id_vector_temp_));
      }

      spv::Id rectangle_guest_vertex_is_last = builder_->createBinOp(
          spv::OpIEqual, type_bool_, rectangle_guest_vertex_index, builder_->makeUintConstant(2));
      SpirvBuilder::IfBuilder if_not_last_guest_vertex(
          builder_->createUnaryOp(spv::OpLogicalNot, type_bool_, rectangle_guest_vertex_is_last),
          spv::SelectionControlDontFlattenMask, *builder_);
      {
        spv::Id rectangle_guest_vertex_index_next = builder_->createBinOp(
            spv::OpIAdd, type_uint_, rectangle_guest_vertex_index, builder_->makeUintConstant(1));
        builder_->createStore(rectangle_guest_vertex_index_next,
                              var_main_rectangle_guest_vertex_index_);

        // Reinitialize per-vertex execution state before running the translated
        // guest shader for the next rectangle vertex.
        builder_->createStore(builder_->makeBoolConstant(false), var_main_predicate_);
        builder_->createStore(const_uint4_0_, var_main_loop_count_);
        builder_->createStore(const_int_0_, var_main_address_register_);
        builder_->createStore(const_int4_0_, var_main_loop_address_);
        builder_->createStore(const_float_0_, var_main_previous_scalar_);
        builder_->createStore(const_int_0_, var_main_vfetch_address_);
        builder_->createStore(const_float_0_, var_main_tfetch_lod_);
        builder_->createStore(const_float3_0_, var_main_tfetch_gradients_h_);
        builder_->createStore(const_float3_0_, var_main_tfetch_gradients_v_);
        for (uint32_t i = 0; i < register_count(); ++i) {
          id_vector_temp_.clear();
          id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
          builder_->createStore(const_float4_0_,
                                builder_->createAccessChain(spv::StorageClassFunction,
                                                            var_main_registers_, id_vector_temp_));
        }
        uint32_t iteration_interpolators_remaining = GetModificationInterpolatorMask();
        while (rex::bit_scan_forward(iteration_interpolators_remaining, &interpolator_index)) {
          iteration_interpolators_remaining &= ~(UINT32_C(1) << interpolator_index);
          builder_->createStore(const_float4_0_, input_output_interpolators_[interpolator_index]);
        }
        if (var_main_point_size_edge_flag_kill_vertex_ != spv::NoResult) {
          id_vector_temp_.clear();
          id_vector_temp_.push_back(builder_->makeFloatConstant(-1.0f));
          id_vector_temp_.push_back(const_float_0_);
          id_vector_temp_.push_back(const_float_0_);
          builder_->createStore(builder_->makeCompositeConstant(type_float3_, id_vector_temp_),
                                var_main_point_size_edge_flag_kill_vertex_);
        }
        if (IsMemoryExportUsed()) {
          // Flush and reinitialize memexport state for the next guest rectangle
          // vertex iteration in this host invocation.
          ExportToMemory(current_shader().memexport_eM_potentially_written_before_end());
          builder_->createStore(const_float4_0_, var_main_memexport_address_);
          uint8_t memexport_eM_remaining = current_shader().memexport_eM_written();
          uint32_t memexport_eM_index;
          while (rex::bit_scan_forward(memexport_eM_remaining, &memexport_eM_index)) {
            memexport_eM_remaining &= ~(uint8_t(1) << memexport_eM_index);
            builder_->createStore(const_float4_0_, var_main_memexport_data_[memexport_eM_index]);
          }
          builder_->createStore(const_uint_0_, var_main_memexport_data_written_);
        }

        // Load the next guest vertex index into r0.x.
        if (register_count()) {
          spv::Id rectangle_two_triangle_strip_vertex_index =
              builder_->createUnaryOp(spv::OpBitcast, type_uint_,
                                      builder_->createLoad(input_vertex_index_, spv::NoPrecision));
          spv::Id rectangle_primitive_index = builder_->createBinOp(
              spv::OpShiftRightLogical, type_uint_, rectangle_two_triangle_strip_vertex_index,
              builder_->makeUintConstant(2));
          spv::Id rectangle_vertex_index = builder_->createBinOp(
              spv::OpIAdd, type_uint_,
              builder_->createBinOp(spv::OpIMul, type_uint_, rectangle_primitive_index,
                                    builder_->makeUintConstant(3)),
              rectangle_guest_vertex_index_next);
          spv::Id rectangle_load_vertex_index = builder_->createBinOp(
              spv::OpINotEqual, type_bool_,
              builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                    builder_->makeUintConstant(static_cast<unsigned int>(
                                        kSysFlag_ComputeOrPrimitiveVertexIndexLoad))),
              const_uint_0_);
          SpirvBuilder::IfBuilder rectangle_load_vertex_index_if(
              rectangle_load_vertex_index, spv::SelectionControlDontFlattenMask, *builder_);
          spv::Id rectangle_loaded_vertex_index;
          {
            spv::Id rectangle_vertex_index_is_32bit = builder_->createBinOp(
                spv::OpINotEqual, type_bool_,
                builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                      builder_->makeUintConstant(static_cast<unsigned int>(
                                          kSysFlag_ComputeOrPrimitiveVertexIndexLoad32Bit))),
                const_uint_0_);
            id_vector_temp_.clear();
            id_vector_temp_.push_back(
                builder_->makeIntConstant(kSystemConstantVertexIndexLoadAddress));
            spv::Id rectangle_vertex_index_address = builder_->createBinOp(
                spv::OpIAdd, type_uint_,
                builder_->createLoad(
                    builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                                id_vector_temp_),
                    spv::NoPrecision),
                builder_->createBinOp(spv::OpShiftLeftLogical, type_uint_, rectangle_vertex_index,
                                      builder_->createTriOp(spv::OpSelect, type_uint_,
                                                            rectangle_vertex_index_is_32bit,
                                                            builder_->makeUintConstant(2),
                                                            builder_->makeUintConstant(1))));
            rectangle_loaded_vertex_index = LoadUint32FromSharedMemory(
                builder_->createUnaryOp(spv::OpBitcast, type_int_,
                                        builder_->createBinOp(spv::OpShiftRightLogical, type_uint_,
                                                              rectangle_vertex_index_address,
                                                              builder_->makeUintConstant(2))));
            rectangle_loaded_vertex_index = builder_->createTriOp(
                spv::OpSelect, type_uint_, rectangle_vertex_index_is_32bit,
                rectangle_loaded_vertex_index,
                builder_->createTriOp(
                    spv::OpBitFieldUExtract, type_uint_, rectangle_loaded_vertex_index,
                    builder_->createBinOp(spv::OpShiftLeftLogical, type_uint_,
                                          builder_->createBinOp(spv::OpBitwiseAnd, type_uint_,
                                                                rectangle_vertex_index_address,
                                                                builder_->makeUintConstant(2)),
                                          builder_->makeUintConstant(3)),
                    builder_->makeUintConstant(16)));
            id_vector_temp_.clear();
            id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexEndian));
            rectangle_loaded_vertex_index = EndianSwap32Uint(
                rectangle_loaded_vertex_index,
                builder_->createLoad(
                    builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                                id_vector_temp_),
                    spv::NoPrecision));
          }
          rectangle_load_vertex_index_if.makeEndIf();
          rectangle_vertex_index = rectangle_load_vertex_index_if.createMergePhi(
              rectangle_loaded_vertex_index, rectangle_vertex_index);

          id_vector_temp_.clear();
          id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexBaseIndex));
          spv::Id rectangle_vertex_base_index = builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                          id_vector_temp_),
              spv::NoPrecision);
          id_vector_temp_.clear();
          id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexMin));
          spv::Id rectangle_vertex_index_min = builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                          id_vector_temp_),
              spv::NoPrecision);
          id_vector_temp_.clear();
          id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexMax));
          spv::Id rectangle_vertex_index_max = builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                          id_vector_temp_),
              spv::NoPrecision);
          rectangle_vertex_index = builder_->createBinOp(
              spv::OpIAdd, type_uint_, rectangle_vertex_index,
              builder_->createUnaryOp(spv::OpBitcast, type_uint_, rectangle_vertex_base_index));
          rectangle_vertex_index =
              builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, rectangle_vertex_index,
                                    builder_->makeUintConstant(xenos::kVertexIndexMask));
          rectangle_vertex_index = builder_->createTriBuiltinCall(
              type_uint_, ext_inst_glsl_std_450_, GLSLstd450UClamp, rectangle_vertex_index,
              rectangle_vertex_index_min, rectangle_vertex_index_max);
          spv::Id rectangle_vertex_index_float =
              builder_->createUnaryOp(spv::OpConvertUToF, type_float_, rectangle_vertex_index);
          id_vector_temp_.clear();
          id_vector_temp_.push_back(const_int_0_);
          id_vector_temp_.push_back(const_int_0_);
          builder_->createStore(rectangle_vertex_index_float,
                                builder_->createAccessChain(spv::StorageClassFunction,
                                                            var_main_registers_, id_vector_temp_));
        }

        if (rectangle_next_vertex_block) {
          builder_->createBranch(rectangle_next_vertex_block);
          function_main_->addBlock(rectangle_next_vertex_block);
          builder_->setBuildPoint(rectangle_next_vertex_block);
        }
        builder_->createBranch(main_loop_continue_);
      }
      // The branch to the loop continuation already terminated the "then" side.
      if_not_last_guest_vertex.makeBeginElse(false);
      {
        spv::Id rectangle_host_vertex_in_primitive = builder_->createBinOp(
            spv::OpBitwiseAnd, type_uint_,
            builder_->createUnaryOp(spv::OpBitcast, type_uint_,
                                    builder_->createLoad(input_vertex_index_, spv::NoPrecision)),
            builder_->makeUintConstant(3));
        spv::Id rectangle_host_vertex_is_synthetic =
            builder_->createBinOp(spv::OpIEqual, type_bool_, rectangle_host_vertex_in_primitive,
                                  builder_->makeUintConstant(3));
        spv::Id rectangle_host_vertex_is_0 = builder_->createBinOp(
            spv::OpIEqual, type_bool_, rectangle_host_vertex_in_primitive, const_uint_0_);
        spv::Id rectangle_host_vertex_is_1 =
            builder_->createBinOp(spv::OpIEqual, type_bool_, rectangle_host_vertex_in_primitive,
                                  builder_->makeUintConstant(1));

        auto load_rectangle_position_xy = [this](spv::Id vertex_index, uint32_t component) {
          id_vector_temp_.clear();
          id_vector_temp_.push_back(vertex_index);
          id_vector_temp_.push_back(builder_->makeIntConstant(int(component)));
          return builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassFunction, var_main_rectangle_per_vertex_,
                                          id_vector_temp_),
              spv::NoPrecision);
        };

        spv::Id const_int_0 = builder_->makeIntConstant(0);
        spv::Id const_int_1 = builder_->makeIntConstant(1);
        spv::Id const_int_2 = builder_->makeIntConstant(2);
        spv::Id const_int_3 = builder_->makeIntConstant(3);

        spv::Id edge_lengths[3];
        for (uint32_t i = 0; i < 3; ++i) {
          spv::Id edge_0 = builder_->makeIntConstant(int((1 + i) % 3));
          spv::Id edge_1 = builder_->makeIntConstant(int((2 + i) % 3));
          spv::Id edge_x =
              builder_->createBinOp(spv::OpFSub, type_float_, load_rectangle_position_xy(edge_1, 0),
                                    load_rectangle_position_xy(edge_0, 0));
          spv::Id edge_y =
              builder_->createBinOp(spv::OpFSub, type_float_, load_rectangle_position_xy(edge_1, 1),
                                    load_rectangle_position_xy(edge_0, 1));
          edge_lengths[i] = builder_->createBinOp(
              spv::OpFAdd, type_float_,
              builder_->createBinOp(spv::OpFMul, type_float_, edge_x, edge_x),
              builder_->createBinOp(spv::OpFMul, type_float_, edge_y, edge_y));
        }

        spv::Id rectangle_vertex_indices[3];
        rectangle_vertex_indices[0] = builder_->createTriOp(
            spv::OpSelect, type_int_,
            builder_->createBinOp(spv::OpLogicalAnd, type_bool_,
                                  builder_->createBinOp(spv::OpFOrdGreaterThan, type_bool_,
                                                        edge_lengths[0], edge_lengths[1]),
                                  builder_->createBinOp(spv::OpFOrdGreaterThan, type_bool_,
                                                        edge_lengths[0], edge_lengths[2])),
            const_int_0,
            builder_->createTriOp(spv::OpSelect, type_int_,
                                  builder_->createBinOp(spv::OpFOrdGreaterThan, type_bool_,
                                                        edge_lengths[1], edge_lengths[2]),
                                  const_int_1, const_int_2));
        for (uint32_t i = 1; i < 3; ++i) {
          spv::Id vertex_index_without_wrapping =
              builder_->createBinOp(spv::OpIAdd, type_int_, rectangle_vertex_indices[0],
                                    builder_->makeIntConstant(int(i)));
          rectangle_vertex_indices[i] = builder_->createTriOp(
              spv::OpSelect, type_int_,
              builder_->createBinOp(spv::OpSLessThan, type_bool_, vertex_index_without_wrapping,
                                    const_int_3),
              vertex_index_without_wrapping,
              builder_->createBinOp(spv::OpISub, type_int_, vertex_index_without_wrapping,
                                    const_int_3));
        }

        auto select_rectangle_vertex_component =
            [this, rectangle_host_vertex_is_0, rectangle_host_vertex_is_1](
                spv::Id value_0, spv::Id value_1, spv::Id value_2, spv::Id type) {
              return builder_->createTriOp(
                  spv::OpSelect, type, rectangle_host_vertex_is_0, value_0,
                  builder_->createTriOp(spv::OpSelect, type, rectangle_host_vertex_is_1, value_1,
                                        value_2));
            };

        interpolators_remaining = GetModificationInterpolatorMask();
        while (rex::bit_scan_forward(interpolators_remaining, &interpolator_index)) {
          interpolators_remaining &= ~(UINT32_C(1) << interpolator_index);
          id_vector_temp_.clear();
          id_vector_temp_.push_back(rectangle_vertex_indices[0]);
          spv::Id interpolator_0 = builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassFunction,
                                          var_main_rectangle_interpolators_[interpolator_index],
                                          id_vector_temp_),
              spv::NoPrecision);
          id_vector_temp_[0] = rectangle_vertex_indices[1];
          spv::Id interpolator_1 = builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassFunction,
                                          var_main_rectangle_interpolators_[interpolator_index],
                                          id_vector_temp_),
              spv::NoPrecision);
          id_vector_temp_[0] = rectangle_vertex_indices[2];
          spv::Id interpolator_2 = builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassFunction,
                                          var_main_rectangle_interpolators_[interpolator_index],
                                          id_vector_temp_),
              spv::NoPrecision);
          spv::Id interpolator_original = select_rectangle_vertex_component(
              interpolator_0, interpolator_1, interpolator_2, type_float4_);
          spv::Id interpolator_synthetic = builder_->createNoContractionBinOp(
              spv::OpFAdd, type_float4_,
              builder_->createNoContractionBinOp(spv::OpFSub, type_float4_, interpolator_1,
                                                 interpolator_0),
              interpolator_2);
          builder_->createStore(
              builder_->createTriOp(spv::OpSelect, type_float4_, rectangle_host_vertex_is_synthetic,
                                    interpolator_synthetic, interpolator_original),
              input_output_interpolators_[interpolator_index]);
        }

        auto load_rectangle_vertex_value = [this](spv::Id variable, spv::Id vertex_index) {
          id_vector_temp_.clear();
          id_vector_temp_.push_back(vertex_index);
          return builder_->createLoad(
              builder_->createAccessChain(spv::StorageClassFunction, variable, id_vector_temp_),
              spv::NoPrecision);
        };

        id_vector_temp_.clear();
        id_vector_temp_.push_back(builder_->makeIntConstant(kOutputPerVertexMemberPosition));
        spv::Id rectangle_position_ptr = builder_->createAccessChain(
            spv::StorageClassOutput, output_per_vertex_, id_vector_temp_);
        spv::Id position_0 = load_rectangle_vertex_value(var_main_rectangle_per_vertex_,
                                                         rectangle_vertex_indices[0]);
        spv::Id position_1 = load_rectangle_vertex_value(var_main_rectangle_per_vertex_,
                                                         rectangle_vertex_indices[1]);
        spv::Id position_2 = load_rectangle_vertex_value(var_main_rectangle_per_vertex_,
                                                         rectangle_vertex_indices[2]);
        spv::Id position_original =
            select_rectangle_vertex_component(position_0, position_1, position_2, type_float4_);
        spv::Id position_synthetic = builder_->createNoContractionBinOp(
            spv::OpFAdd, type_float4_,
            builder_->createNoContractionBinOp(spv::OpFSub, type_float4_, position_1, position_0),
            position_2);
        builder_->createStore(
            builder_->createTriOp(spv::OpSelect, type_float4_, rectangle_host_vertex_is_synthetic,
                                  position_synthetic, position_original),
            rectangle_position_ptr);

        auto write_rectangle_distance_member =
            [this, &select_rectangle_vertex_component, rectangle_host_vertex_is_synthetic,
             &load_rectangle_vertex_value, rectangle_vertex_indices](
                uint32_t member_index, uint32_t component_count,
                const std::array<spv::Id, kMaxRectanglePerVertexDistances>& variables) {
              for (uint32_t i = 0; i < component_count; ++i) {
                spv::Id value_0 =
                    load_rectangle_vertex_value(variables[i], rectangle_vertex_indices[0]);
                spv::Id value_1 =
                    load_rectangle_vertex_value(variables[i], rectangle_vertex_indices[1]);
                spv::Id value_2 =
                    load_rectangle_vertex_value(variables[i], rectangle_vertex_indices[2]);
                spv::Id value_original =
                    select_rectangle_vertex_component(value_0, value_1, value_2, type_float_);
                spv::Id value_synthetic = builder_->createNoContractionBinOp(
                    spv::OpFAdd, type_float_,
                    builder_->createNoContractionBinOp(spv::OpFSub, type_float_, value_1, value_0),
                    value_2);
                id_vector_temp_.clear();
                id_vector_temp_.push_back(builder_->makeIntConstant(int(member_index)));
                id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
                builder_->createStore(
                    builder_->createTriOp(spv::OpSelect, type_float_,
                                          rectangle_host_vertex_is_synthetic, value_synthetic,
                                          value_original),
                    builder_->createAccessChain(spv::StorageClassOutput, output_per_vertex_,
                                                id_vector_temp_));
              }
            };

        if (clip_distance_count && output_per_vertex_member_clip_distance_ != UINT32_MAX) {
          write_rectangle_distance_member(output_per_vertex_member_clip_distance_,
                                          clip_distance_count, var_main_rectangle_clip_distances_);
        }
        if (cull_distance_count && output_per_vertex_member_cull_distance_ != UINT32_MAX) {
          write_rectangle_distance_member(output_per_vertex_member_cull_distance_,
                                          cull_distance_count, var_main_rectangle_cull_distances_);
        }
      }
      if_not_last_guest_vertex.makeEndIf();
    }
    if (main_loop_exit_ != main_loop_merge_) {
      if (!builder_->getBuildPoint()->isTerminated()) {
        builder_->createBranch(main_loop_exit_);
      }
      function_main_->addBlock(main_loop_exit_);
      builder_->setBuildPoint(main_loop_exit_);
    }
  }

  // Write data for the last memexport.
  ExportToMemory(current_shader().memexport_eM_potentially_written_before_end());

  if (is_vertex_shader() && !IsSpirvComputeShader() && !rectangle_vertex_loop) {
    CompleteVertexOrTessEvalShaderInMain();
  } else if (is_pixel_shader()) {
    CompleteFragmentShaderInMain();
  }

  // End the main function.
  builder_->leaveFunction();

  // Make the main function the entry point.
  spv::ExecutionModel execution_model;
  if (is_pixel_shader()) {
    execution_model = spv::ExecutionModelFragment;
    builder_->addExecutionMode(function_main_, spv::ExecutionModeOriginUpperLeft);
    if (output_fragment_depth_ != spv::NoResult) {
      builder_->addExecutionMode(function_main_, spv::ExecutionModeDepthReplacing);
      if (!current_shader().writes_depth() &&
          GetSpirvShaderModification().pixel.depth_stencil_mode ==
              Modification::DepthStencilMode::kFloat24Truncating) {
        builder_->addExecutionMode(function_main_, spv::ExecutionModeDepthLess);
      }
    }
    if (IsExecutionModeEarlyFragmentTests()) {
      builder_->addExecutionMode(function_main_, spv::ExecutionModeEarlyFragmentTests);
    }
    if (edram_fragment_shader_interlock_) {
      // Accessing per-sample values, so interlocking just when there's common
      // coverage is enough if the device exposes that.
      if (features_.fragment_shader_sample_interlock) {
        builder_->addCapability(spv::CapabilityFragmentShaderSampleInterlockEXT);
        builder_->addExecutionMode(function_main_, spv::ExecutionModeSampleInterlockOrderedEXT);
      } else {
        builder_->addCapability(spv::CapabilityFragmentShaderPixelInterlockEXT);
        builder_->addExecutionMode(function_main_, spv::ExecutionModePixelInterlockOrderedEXT);
      }
    }
  } else {
    assert_true(is_vertex_shader());
    bool is_compute_shader = IsSpirvComputeShader();
    bool is_tess_eval_shader = IsSpirvTessEvalShader();
    execution_model = is_compute_shader
                          ? spv::ExecutionModelGLCompute
                          : (is_tess_eval_shader ? spv::ExecutionModelTessellationEvaluation
                                                 : spv::ExecutionModelVertex);
    if (is_compute_shader) {
      builder_->addExecutionMode(function_main_, spv::ExecutionModeLocalSize, 1, 1, 1);
    } else if (is_tess_eval_shader) {
      Modification shader_modification = GetSpirvShaderModification();
      switch (shader_modification.vertex.host_vertex_shader_type) {
        case Shader::HostVertexShaderType::kLineDomainCPIndexed:
        case Shader::HostVertexShaderType::kLineDomainPatchIndexed:
          builder_->addExecutionMode(function_main_, spv::ExecutionModeIsolines);
          break;
        case Shader::HostVertexShaderType::kTriangleDomainCPIndexed:
        case Shader::HostVertexShaderType::kTriangleDomainPatchIndexed:
          builder_->addExecutionMode(function_main_, spv::ExecutionModeTriangles);
          break;
        case Shader::HostVertexShaderType::kQuadDomainCPIndexed:
        case Shader::HostVertexShaderType::kQuadDomainPatchIndexed:
          builder_->addExecutionMode(function_main_, spv::ExecutionModeQuads);
          break;
        default:
          assert_unhandled_case(shader_modification.vertex.host_vertex_shader_type);
          break;
      }
      builder_->addExecutionMode(function_main_, (shader_modification.vertex.tessellation_mode ==
                                                  uint32_t(xenos::TessellationMode::kDiscrete))
                                                     ? spv::ExecutionModeSpacingEqual
                                                     : spv::ExecutionModeSpacingFractionalEven);
      builder_->addExecutionMode(function_main_, spv::ExecutionModeVertexOrderCw);
    }
  }
  if (features_.denorm_flush_to_zero_float32) {
    // Flush to zero, similar to the real hardware, also for things like Shader
    // Model 3 multiplication emulation.
    builder_->addCapability(spv::CapabilityDenormFlushToZero);
    builder_->addExecutionMode(function_main_, spv::ExecutionModeDenormFlushToZero, 32);
  }
  if (features_.signed_zero_inf_nan_preserve_float32) {
    // Signed zero used to get VFACE from ps_param_gen, also special behavior
    // for infinity in certain instructions (such as logarithm, reciprocal,
    // muls_prev2).
    builder_->addCapability(spv::CapabilitySignedZeroInfNanPreserve);
    builder_->addExecutionMode(function_main_, spv::ExecutionModeSignedZeroInfNanPreserve, 32);
  }
  if (features_.rounding_mode_rte_float32) {
    builder_->addCapability(spv::CapabilityRoundingModeRTE);
    builder_->addExecutionMode(function_main_, spv::ExecutionModeRoundingModeRTE, 32);
  }
  spv::Instruction* entry_point = builder_->addEntryPoint(execution_model, function_main_, "main");
  for (spv::Id interface_id : main_interface_) {
    entry_point->addIdOperand(interface_id);
  }

  if (!is_depth_only_fragment_shader_) {
    // Specify the binding indices for samplers when the number of textures is
    // known, as samplers are located after images in the texture descriptor
    // set.
    size_t texture_binding_count = texture_bindings_.size();
    size_t sampler_binding_count = sampler_bindings_.size();
    if (!features_.bindless_textures) {
      for (size_t i = 0; i < sampler_binding_count; ++i) {
        builder_->addDecoration(sampler_bindings_[i].variable, spv::DecorationBinding,
                                int(texture_binding_count + i));
      }
    }
  }

  // TODO(Triang3l): Avoid copy?
  std::vector<unsigned int> module_uints;
  builder_->dump(module_uints);
  std::vector<uint8_t> module_bytes;
  module_bytes.reserve(sizeof(unsigned int) * module_uints.size());
  module_bytes.insert(module_bytes.cend(), reinterpret_cast<const uint8_t*>(module_uints.data()),
                      reinterpret_cast<const uint8_t*>(module_uints.data()) +
                          sizeof(unsigned int) * module_uints.size());
  return module_bytes;
}

void SpirvShaderTranslator::PostTranslation() {
  Shader::Translation& translation = current_translation();
  if (!translation.is_valid()) {
    return;
  }
  SpirvShader* spirv_shader = dynamic_cast<SpirvShader*>(&translation.shader());
  if (spirv_shader &&
      !spirv_shader->bindings_setup_entered_.test_and_set(std::memory_order_relaxed)) {
    spirv_shader->texture_bindings_.clear();
    spirv_shader->texture_bindings_.reserve(texture_bindings_.size());
    for (const TextureBinding& translator_binding : texture_bindings_) {
      SpirvShader::TextureBinding& shader_binding = spirv_shader->texture_bindings_.emplace_back();
      // For a stable hash.
      std::memset(&shader_binding, 0, sizeof(shader_binding));
      shader_binding.fetch_constant = translator_binding.fetch_constant;
      shader_binding.dimension = translator_binding.dimension;
      shader_binding.is_signed = translator_binding.is_signed;
      spirv_shader->used_texture_mask_ |= UINT32_C(1) << translator_binding.fetch_constant;
    }
    spirv_shader->sampler_bindings_.clear();
    spirv_shader->sampler_bindings_.reserve(sampler_bindings_.size());
    for (const SamplerBinding& translator_binding : sampler_bindings_) {
      SpirvShader::SamplerBinding& shader_binding = spirv_shader->sampler_bindings_.emplace_back();
      shader_binding.fetch_constant = translator_binding.fetch_constant;
      shader_binding.mag_filter = translator_binding.mag_filter;
      shader_binding.min_filter = translator_binding.min_filter;
      shader_binding.mip_filter = translator_binding.mip_filter;
      shader_binding.aniso_filter = translator_binding.aniso_filter;
    }
    spirv_shader->bindings_setup_complete_.store(true, std::memory_order_release);
  }
}

void SpirvShaderTranslator::ProcessLabel(uint32_t cf_index) {
  if (cf_index == 0) {
    // 0 already added in the beginning.
    return;
  }

  assert_false(current_shader().label_addresses().empty());

  // Close flow control within the previous switch case.
  CloseExecConditionals();

  spv::Function& function = builder_->getBuildPoint()->getParent();
  // Create the next switch case and fallthrough to it.
  spv::Block* new_case = new spv::Block(builder_->getUniqueId(), function);
  main_switch_op_->addImmediateOperand(cf_index);
  main_switch_op_->addIdOperand(new_case->getId());
  // Every switch case must have the OpSelectionMerge/OpSwitch block as a
  // predecessor.
  new_case->addPredecessor(main_switch_header_);
  // The previous block may have already been terminated if was exece.
  if (!builder_->getBuildPoint()->isTerminated()) {
    // Don't fall through directly into the next case block. An OpSwitch case
    // fall-through inside the main loop makes the NVIDIA shader compiler emit
    // a non-terminating loop (a device loss). Instead re-enter the loop with
    // this label as the program counter, like an unconditional jump to it
    // does (xenia-edge f145711a4a).
    main_switch_next_pc_phi_operands_.push_back(builder_->makeIntConstant(int(cf_index)));
    main_switch_next_pc_phi_operands_.push_back(builder_->getBuildPoint()->getId());
    builder_->createBranch(main_loop_continue_);
  }
  function.addBlock(new_case);
  builder_->setBuildPoint(new_case);
}

void SpirvShaderTranslator::ProcessExecInstructionBegin(const ParsedExecInstruction& instr) {
  UpdateExecConditionals(instr.type, instr.bool_constant_index, instr.condition);
}

void SpirvShaderTranslator::ProcessExecInstructionEnd(const ParsedExecInstruction& instr) {
  if (instr.is_end) {
    // Break out of the main switch (if exists) and the main loop.
    CloseInstructionPredication();
    if (!builder_->getBuildPoint()->isTerminated()) {
      builder_->createBranch(current_shader().label_addresses().empty() ? main_loop_merge_
                                                                        : main_switch_merge_);
    }
  }
  UpdateExecConditionals(instr.type, instr.bool_constant_index, instr.condition);
}

void SpirvShaderTranslator::ProcessLoopStartInstruction(const ParsedLoopStartInstruction& instr) {
  ++cf_loop_depth_;
  // loop il<idx>, L<idx> - loop with loop data il<idx>, end @ L<idx>

  // Loop control is outside execs - actually close the last exec.
  CloseExecConditionals();

  EnsureBuildPointAvailable();

  id_vector_temp_.clear();
  // Loop constants (member 1).
  id_vector_temp_.push_back(builder_->makeIntConstant(1));
  // 4-component vector.
  id_vector_temp_.push_back(builder_->makeIntConstant(int(instr.loop_constant_index >> 2)));
  // Scalar within the vector.
  id_vector_temp_.push_back(builder_->makeIntConstant(int(instr.loop_constant_index & 3)));
  // Count (unsigned) in bits 0:7 of the loop constant (struct member 1),
  // initial aL (unsigned) in 8:15.
  spv::Id loop_constant = builder_->createLoad(
      builder_->createAccessChain(spv::StorageClassUniform, uniform_bool_loop_constants_,
                                  id_vector_temp_),
      spv::NoPrecision);

  spv::Id const_int_8 = builder_->makeIntConstant(8);

  // Push the count to the loop count stack - move XYZ to YZW and set X to the
  // new iteration count (swizzling the way glslang does it for similar GLSL).
  spv::Id loop_count_stack_old = builder_->createLoad(var_main_loop_count_, spv::NoPrecision);
  spv::Id loop_count_new = builder_->createTriOp(spv::OpBitFieldUExtract, type_uint_, loop_constant,
                                                 const_int_0_, const_int_8);
  id_vector_temp_.clear();
  id_vector_temp_.push_back(loop_count_new);
  for (unsigned int i = 0; i < 3; ++i) {
    id_vector_temp_.push_back(
        builder_->createCompositeExtract(loop_count_stack_old, type_uint_, i));
  }
  builder_->createStore(builder_->createCompositeConstruct(type_uint4_, id_vector_temp_),
                        var_main_loop_count_);

  // Push aL - keep the same value as in the previous loop if repeating, or the
  // new one otherwise.
  spv::Id address_relative_stack_old =
      builder_->createLoad(var_main_loop_address_, spv::NoPrecision);
  id_vector_temp_.clear();
  if (instr.is_repeat) {
    id_vector_temp_.emplace_back();
  } else {
    id_vector_temp_.push_back(
        builder_->createUnaryOp(spv::OpBitcast, type_int_,
                                builder_->createTriOp(spv::OpBitFieldUExtract, type_uint_,
                                                      loop_constant, const_int_8, const_int_8)));
  }
  for (unsigned int i = 0; i < 3; ++i) {
    id_vector_temp_.push_back(
        builder_->createCompositeExtract(address_relative_stack_old, type_int_, i));
  }
  if (instr.is_repeat) {
    id_vector_temp_[0] = id_vector_temp_[1];
  }
  builder_->createStore(builder_->createCompositeConstruct(type_int4_, id_vector_temp_),
                        var_main_loop_address_);

  // Break (jump to the skip label) if the loop counter is 0 (since the
  // condition is checked in the end).
  spv::Block& head_block = *builder_->getBuildPoint();
  spv::Id loop_count_zero =
      builder_->createBinOp(spv::OpIEqual, type_bool_, loop_count_new, const_uint_0_);
  spv::Block& skip_block = builder_->makeNewBlock();
  spv::Block& body_block = builder_->makeNewBlock();
  builder_->createSelectionMerge(&body_block, spv::SelectionControlMaskNone);
  {
    std::unique_ptr<spv::Instruction> branch_conditional_op =
        std::make_unique<spv::Instruction>(spv::OpBranchConditional);
    branch_conditional_op->addIdOperand(loop_count_zero);
    branch_conditional_op->addIdOperand(skip_block.getId());
    branch_conditional_op->addIdOperand(body_block.getId());
    // More likely to enter than to skip.
    branch_conditional_op->addImmediateOperand(1);
    branch_conditional_op->addImmediateOperand(2);
    head_block.addInstruction(std::move(branch_conditional_op));
  }
  skip_block.addPredecessor(&head_block);
  body_block.addPredecessor(&head_block);
  builder_->setBuildPoint(&skip_block);
  main_switch_next_pc_phi_operands_.push_back(
      builder_->makeIntConstant(int(instr.loop_skip_address)));
  main_switch_next_pc_phi_operands_.push_back(builder_->getBuildPoint()->getId());
  builder_->createBranch(main_loop_continue_);
  builder_->setBuildPoint(&body_block);
}

void SpirvShaderTranslator::ProcessLoopEndInstruction(const ParsedLoopEndInstruction& instr) {
  if (cf_loop_depth_) --cf_loop_depth_;
  // endloop il<idx>, L<idx> - end loop w/ data il<idx>, head @ L<idx>

  // Loop control is outside execs - actually close the last exec.
  CloseExecConditionals();

  EnsureBuildPointAvailable();

  // Subtract 1 from the loop counter (will store later).
  spv::Id loop_count_stack_old = builder_->createLoad(var_main_loop_count_, spv::NoPrecision);
  spv::Id loop_count =
      builder_->createBinOp(spv::OpISub, type_uint_,
                            builder_->createCompositeExtract(loop_count_stack_old, type_uint_, 0),
                            builder_->makeUintConstant(1));
  spv::Id address_relative_stack_old =
      builder_->createLoad(var_main_loop_address_, spv::NoPrecision);

  // Predicated break works like break if (loop_count == 0 || [!]p0).
  // Three options, due to logical operations usage (so OpLogicalNot is not
  // required):
  // - Continue if (loop_count != 0).
  // - Continue if (loop_count != 0 && p0), if breaking if !p0.
  // - Break if (loop_count == 0 || p0), if breaking if p0.
  bool break_is_true = instr.is_predicated_break && instr.predicate_condition;
  spv::Id condition = builder_->createBinOp(break_is_true ? spv::OpIEqual : spv::OpINotEqual,
                                            type_bool_, loop_count, const_uint_0_);
  if (instr.is_predicated_break) {
    condition = builder_->createBinOp(
        instr.predicate_condition ? spv::OpLogicalOr : spv::OpLogicalAnd, type_bool_, condition,
        builder_->createLoad(var_main_predicate_, spv::NoPrecision));
  }

  spv::Block& body_block = *builder_->getBuildPoint();
  spv::Block& continue_block = builder_->makeNewBlock();
  spv::Block& break_block = builder_->makeNewBlock();
  builder_->createSelectionMerge(&break_block, spv::SelectionControlMaskNone);
  {
    std::unique_ptr<spv::Instruction> branch_conditional_op =
        std::make_unique<spv::Instruction>(spv::OpBranchConditional);
    branch_conditional_op->addIdOperand(condition);
    // More likely to continue than to break.
    if (break_is_true) {
      branch_conditional_op->addIdOperand(break_block.getId());
      branch_conditional_op->addIdOperand(continue_block.getId());
      branch_conditional_op->addImmediateOperand(1);
      branch_conditional_op->addImmediateOperand(2);
    } else {
      branch_conditional_op->addIdOperand(continue_block.getId());
      branch_conditional_op->addIdOperand(break_block.getId());
      branch_conditional_op->addImmediateOperand(2);
      branch_conditional_op->addImmediateOperand(1);
    }
    body_block.addInstruction(std::move(branch_conditional_op));
  }
  continue_block.addPredecessor(&body_block);
  break_block.addPredecessor(&body_block);

  // Continue case.
  builder_->setBuildPoint(&continue_block);
  // Store the loop count with 1 subtracted.
  builder_->createStore(
      builder_->createCompositeInsert(loop_count, loop_count_stack_old, type_uint4_, 0),
      var_main_loop_count_);
  // Extract the value to add to aL (signed, in bits 16:23 of the loop
  // constant).
  id_vector_temp_.clear();
  // Loop constants (member 1).
  id_vector_temp_.push_back(builder_->makeIntConstant(1));
  // 4-component vector.
  id_vector_temp_.push_back(builder_->makeIntConstant(int(instr.loop_constant_index >> 2)));
  // Scalar within the vector.
  id_vector_temp_.push_back(builder_->makeIntConstant(int(instr.loop_constant_index & 3)));
  spv::Id loop_constant = builder_->createLoad(
      builder_->createAccessChain(spv::StorageClassUniform, uniform_bool_loop_constants_,
                                  id_vector_temp_),
      spv::NoPrecision);
  spv::Id address_relative_old =
      builder_->createCompositeExtract(address_relative_stack_old, type_int_, 0);
  builder_->createStore(
      builder_->createCompositeInsert(
          builder_->createBinOp(
              spv::OpIAdd, type_int_, address_relative_old,
              builder_->createTriOp(
                  spv::OpBitFieldSExtract, type_int_,
                  builder_->createUnaryOp(spv::OpBitcast, type_int_, loop_constant),
                  builder_->makeIntConstant(16), builder_->makeIntConstant(8))),
          address_relative_stack_old, type_int4_, 0),
      var_main_loop_address_);
  // Jump back to the beginning of the loop body.
  main_switch_next_pc_phi_operands_.push_back(
      builder_->makeIntConstant(int(instr.loop_body_address)));
  main_switch_next_pc_phi_operands_.push_back(builder_->getBuildPoint()->getId());
  builder_->createBranch(main_loop_continue_);

  // Break case.
  builder_->setBuildPoint(&break_block);
  // Pop the current loop off the loop counter and the relative address stacks -
  // move YZW to XYZ and set W to 0.
  id_vector_temp_.clear();
  for (unsigned int i = 1; i < 4; ++i) {
    id_vector_temp_.push_back(
        builder_->createCompositeExtract(loop_count_stack_old, type_uint_, i));
  }
  id_vector_temp_.push_back(const_uint_0_);
  builder_->createStore(builder_->createCompositeConstruct(type_uint4_, id_vector_temp_),
                        var_main_loop_count_);
  id_vector_temp_.clear();
  for (unsigned int i = 1; i < 4; ++i) {
    id_vector_temp_.push_back(
        builder_->createCompositeExtract(address_relative_stack_old, type_int_, i));
  }
  id_vector_temp_.push_back(const_int_0_);
  builder_->createStore(builder_->createCompositeConstruct(type_int4_, id_vector_temp_),
                        var_main_loop_address_);
  // Now going to fall through to the next control flow instruction.
}

void SpirvShaderTranslator::ProcessJumpInstruction(const ParsedJumpInstruction& instr) {
  // Xenos runs 64 invocations together, so a predicated jump is taken or not
  // by all of them, and the compiler predicates the instructions it skips as
  // well - jumping is only an optimization. Jumping per invocation instead
  // splits a quad between iterations of the main loop, and a derivative after
  // the jump in the lanes that didn't take it (the implicit gradients of a
  // cube fetch in FH1's car shader) then hangs Nvidia GPUs. So a predicated
  // forward jump in a pixel shader is only taken when the whole quad takes it.
  if (instr.type == ParsedJumpInstruction::Type::kPredicated && is_pixel_shader() &&
      features_.quad_operations_fragment && instr.target_address > instr.dword_index) {
    CloseExecConditionals();
    EnsureBuildPointAvailable();
    spv::Id jump = builder_->createLoad(var_main_predicate_, spv::NoPrecision);
    if (!instr.condition) {
      jump = builder_->createUnaryOp(spv::OpLogicalNot, type_bool_, jump);
    }
    builder_->addCapability(spv::CapabilityGroupNonUniformQuad);
    spv::Id scope_subgroup = builder_->makeUintConstant(uint32_t(spv::ScopeSubgroup));
    // Horizontal, then vertical: the AND of all four lanes.
    for (uint32_t direction = 0; direction < 2; ++direction) {
      id_vector_temp_.clear();
      id_vector_temp_.push_back(scope_subgroup);
      id_vector_temp_.push_back(jump);
      id_vector_temp_.push_back(builder_->makeUintConstant(direction));
      jump = builder_->createBinOp(
          spv::OpLogicalAnd, type_bool_, jump,
          builder_->createOp(spv::OpGroupNonUniformQuadSwap, type_bool_, id_vector_temp_));
    }
    cf_exec_bool_constant_or_predicate_ = kCfExecBoolConstantQuadJump;
    cf_exec_condition_ = true;
    cf_exec_conditional_merge_ =
        new spv::Block(builder_->getUniqueId(), builder_->getBuildPoint()->getParent());
    builder_->createSelectionMerge(cf_exec_conditional_merge_,
                                   spv::SelectionControlDontFlattenMask);
    spv::Block& inner_block = builder_->makeNewBlock();
    builder_->createConditionalBranch(jump, &inner_block, cf_exec_conditional_merge_);
    builder_->setBuildPoint(&inner_block);
    main_switch_next_pc_phi_operands_.push_back(
        builder_->makeIntConstant(int(instr.target_address)));
    main_switch_next_pc_phi_operands_.push_back(builder_->getBuildPoint()->getId());
    builder_->createBranch(main_loop_continue_);
    return;
  }

  // Treat like exec, merge with execs if possible, since it's an if too.
  ParsedExecInstruction::Type type;
  if (instr.type == ParsedJumpInstruction::Type::kConditional) {
    type = ParsedExecInstruction::Type::kConditional;
  } else if (instr.type == ParsedJumpInstruction::Type::kPredicated) {
    type = ParsedExecInstruction::Type::kPredicated;
  } else {
    type = ParsedExecInstruction::Type::kUnconditional;
  }
  UpdateExecConditionals(type, instr.bool_constant_index, instr.condition);

  // UpdateExecConditionals may not necessarily close the instruction-level
  // predicate check (it's not necessary if the execs are merged), but here the
  // instruction itself is on the control flow level, so the predicate check is
  // on the control flow level too.
  CloseInstructionPredication();

  if (builder_->getBuildPoint()->isTerminated()) {
    // Unreachable for some reason.
    return;
  }
  main_switch_next_pc_phi_operands_.push_back(builder_->makeIntConstant(int(instr.target_address)));
  main_switch_next_pc_phi_operands_.push_back(builder_->getBuildPoint()->getId());
  builder_->createBranch(main_loop_continue_);
}

void SpirvShaderTranslator::ProcessAllocInstruction(const ParsedAllocInstruction& instr,
                                                    uint8_t export_eM) {
  bool start_memexport =
      instr.type == ucode::AllocType::kMemory && current_shader().memexport_eM_written();
  if (export_eM || start_memexport) {
    CloseExecConditionals();
  }

  if (export_eM) {
    ExportToMemory(export_eM);
    // Reset which eM# elements have been written.
    builder_->createStore(const_uint_0_, var_main_memexport_data_written_);
    // Break dependencies from the previous memexport.
    uint8_t export_eM_remaining = export_eM;
    uint32_t eM_index;
    while (rex::bit_scan_forward(export_eM_remaining, &eM_index)) {
      export_eM_remaining &= ~(uint8_t(1) << eM_index);
      builder_->createStore(const_float4_0_, var_main_memexport_data_[eM_index]);
    }
  }

  if (start_memexport) {
    // Initialize eA to an invalid address.
    builder_->createStore(const_float4_0_, var_main_memexport_address_);
  }
}

spv::Id SpirvShaderTranslator::SpirvSmearScalarResultOrConstant(spv::Id scalar,
                                                                spv::Id vector_type) {
  bool is_constant = builder_->isConstant(scalar);
  bool is_spec_constant = builder_->isSpecConstant(scalar);
  if (!is_constant && !is_spec_constant) {
    return builder_->smearScalar(spv::NoPrecision, scalar, vector_type);
  }
  assert_true(builder_->getTypeClass(builder_->getTypeId(scalar)) ==
              builder_->getTypeClass(builder_->getScalarTypeId(vector_type)));
  if (!builder_->isVectorType(vector_type)) {
    assert_true(builder_->isScalarType(vector_type));
    return scalar;
  }
  int num_components = builder_->getNumTypeComponents(vector_type);
  id_vector_temp_util_.clear();
  for (int i = 0; i < num_components; ++i) {
    id_vector_temp_util_.push_back(scalar);
  }
  return builder_->makeCompositeConstant(vector_type, id_vector_temp_util_, is_spec_constant);
}

uint32_t SpirvShaderTranslator::GetPsParamGenInterpolator() const {
  assert_true(is_pixel_shader());
  Modification modification = GetSpirvShaderModification();
  // param_gen_interpolator is already 4 bits, no need for an interpolator count
  // safety check.
  return (modification.pixel.param_gen_enable &&
          modification.pixel.param_gen_interpolator < register_count())
             ? modification.pixel.param_gen_interpolator
             : UINT32_MAX;
}

void SpirvShaderTranslator::EnsureBuildPointAvailable() {
  if (!builder_->getBuildPoint()->isTerminated()) {
    return;
  }
  spv::Block& new_block = builder_->makeNewBlock();
  new_block.setUnreachable();
  builder_->setBuildPoint(&new_block);
}

void SpirvShaderTranslator::StartVertexOrTessEvalShaderBeforeMain() {
  if (IsSpirvComputeShader()) {
    // For memexport fallback execution, each invocation corresponds to one
    // guest vertex processing index.
    input_vertex_index_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassInput,
                                                   type_uint3_, "gl_GlobalInvocationID");
    builder_->addDecoration(input_vertex_index_, spv::DecorationBuiltIn,
                            spv::BuiltInGlobalInvocationId);
    main_interface_.push_back(input_vertex_index_);
    return;
  }

  // Create the inputs.
  if (IsSpirvTessEvalShader()) {
    input_primitive_id_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassInput,
                                                   type_int_, "gl_PrimitiveID");
    builder_->addDecoration(input_primitive_id_, spv::DecorationBuiltIn, spv::BuiltInPrimitiveId);
    main_interface_.push_back(input_primitive_id_);
    input_tess_coord_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassInput,
                                                 type_float3_, "gl_TessCoord");
    builder_->addDecoration(input_tess_coord_, spv::DecorationBuiltIn, spv::BuiltInTessCoord);
    main_interface_.push_back(input_tess_coord_);
    input_patch_control_point_indices_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassInput, type_float4_,
                                 "xe_in_patch_control_point_indices");
    builder_->addDecoration(input_patch_control_point_indices_, spv::DecorationLocation, 0);
    builder_->addDecoration(input_patch_control_point_indices_, spv::DecorationPatch);
    main_interface_.push_back(input_patch_control_point_indices_);
  } else {
    input_vertex_index_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassInput,
                                                   type_int_, "gl_VertexIndex");
    builder_->addDecoration(input_vertex_index_, spv::DecorationBuiltIn, spv::BuiltInVertexIndex);
    main_interface_.push_back(input_vertex_index_);
  }

  uint32_t output_location = 0;

  // Create the interpolator outputs.
  {
    uint32_t interpolators_remaining = GetModificationInterpolatorMask();
    uint32_t interpolator_index;
    while (rex::bit_scan_forward(interpolators_remaining, &interpolator_index)) {
      interpolators_remaining &= ~(UINT32_C(1) << interpolator_index);
      spv::Id interpolator = builder_->createVariable(
          spv::NoPrecision, spv::StorageClassOutput, type_float4_,
          fmt::format("xe_out_interpolator_{}", interpolator_index).c_str());
      input_output_interpolators_[interpolator_index] = interpolator;
      builder_->addDecoration(interpolator, spv::DecorationLocation, int(output_location));
      builder_->addDecoration(interpolator, spv::DecorationInvariant);
      main_interface_.push_back(interpolator);
      ++output_location;
    }
  }

  Modification shader_modification = GetSpirvShaderModification();

  if (shader_modification.vertex.output_point_parameters) {
    if (shader_modification.vertex.host_vertex_shader_type ==
        Shader::HostVertexShaderType::kPointListAsTriangleStrip) {
      // Create the point coordinates output.
      output_point_coordinates_ = builder_->createVariable(
          spv::NoPrecision, spv::StorageClassOutput, type_float2_, "xe_out_point_coordinates");
      builder_->addDecoration(output_point_coordinates_, spv::DecorationLocation,
                              int(output_location));
      builder_->addDecoration(output_point_coordinates_, spv::DecorationInvariant);
      main_interface_.push_back(output_point_coordinates_);
      ++output_location;
    } else {
      // Create the point size output. Not using gl_PointSize from gl_PerVertex
      // not to rely on the shaderTessellationAndGeometryPointSize feature, and
      // also because the value written to gl_PointSize must be greater than
      // zero.
      output_point_size_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassOutput,
                                                    type_float_, "xe_out_point_size");
      builder_->addDecoration(output_point_size_, spv::DecorationLocation, int(output_location));
      builder_->addDecoration(output_point_size_, spv::DecorationInvariant);
      main_interface_.push_back(output_point_size_);
      ++output_location;
    }
  }

  // Create the gl_PerVertex output for used system outputs.
  uint32_t clip_distance_count = shader_modification.GetVertexClipDistanceCount();
  uint32_t cull_distance_count = shader_modification.GetVertexCullDistanceCount();
  std::vector<spv::Id> struct_per_vertex_members;
  struct_per_vertex_members.reserve(kOutputPerVertexMemberCountMax);
  struct_per_vertex_members.push_back(type_float4_);
  output_per_vertex_member_count_ = uint32_t(struct_per_vertex_members.size());
  output_per_vertex_member_clip_distance_ = UINT32_MAX;
  output_per_vertex_member_cull_distance_ = UINT32_MAX;
  if (clip_distance_count) {
    assert_true(features_.clip_distance);
    builder_->addCapability(spv::CapabilityClipDistance);
    spv::Id type_clip_distance =
        builder_->makeArrayType(type_float_, builder_->makeUintConstant(clip_distance_count), 0);
    builder_->addDecoration(type_clip_distance, spv::DecorationArrayStride, sizeof(float));
    output_per_vertex_member_clip_distance_ = uint32_t(struct_per_vertex_members.size());
    struct_per_vertex_members.push_back(type_clip_distance);
    output_per_vertex_member_count_ = uint32_t(struct_per_vertex_members.size());
  }
  if (cull_distance_count) {
    assert_true(features_.cull_distance);
    builder_->addCapability(spv::CapabilityCullDistance);
    spv::Id type_cull_distance =
        builder_->makeArrayType(type_float_, builder_->makeUintConstant(cull_distance_count), 0);
    builder_->addDecoration(type_cull_distance, spv::DecorationArrayStride, sizeof(float));
    output_per_vertex_member_cull_distance_ = uint32_t(struct_per_vertex_members.size());
    struct_per_vertex_members.push_back(type_cull_distance);
    output_per_vertex_member_count_ = uint32_t(struct_per_vertex_members.size());
  }
  spv::Id type_struct_per_vertex =
      builder_->makeStructType(struct_per_vertex_members, "gl_PerVertex");
  builder_->addMemberName(type_struct_per_vertex, kOutputPerVertexMemberPosition, "gl_Position");
  builder_->addMemberDecoration(type_struct_per_vertex, kOutputPerVertexMemberPosition,
                                spv::DecorationBuiltIn, spv::BuiltInPosition);
  if (output_per_vertex_member_clip_distance_ != UINT32_MAX) {
    builder_->addMemberName(type_struct_per_vertex, output_per_vertex_member_clip_distance_,
                            "gl_ClipDistance");
    builder_->addMemberDecoration(type_struct_per_vertex, output_per_vertex_member_clip_distance_,
                                  spv::DecorationBuiltIn, spv::BuiltInClipDistance);
  }
  if (output_per_vertex_member_cull_distance_ != UINT32_MAX) {
    builder_->addMemberName(type_struct_per_vertex, output_per_vertex_member_cull_distance_,
                            "gl_CullDistance");
    builder_->addMemberDecoration(type_struct_per_vertex, output_per_vertex_member_cull_distance_,
                                  spv::DecorationBuiltIn, spv::BuiltInCullDistance);
  }
  builder_->addDecoration(type_struct_per_vertex, spv::DecorationBlock);
  type_output_per_vertex_ = type_struct_per_vertex;
  output_per_vertex_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassOutput,
                                                type_struct_per_vertex, "");
  builder_->addDecoration(output_per_vertex_, spv::DecorationInvariant);
  main_interface_.push_back(output_per_vertex_);
}

void SpirvShaderTranslator::StartVertexOrTessEvalShaderInMain() {
  Modification shader_modification = GetSpirvShaderModification();
  Shader::HostVertexShaderType host_vertex_shader_type =
      shader_modification.vertex.host_vertex_shader_type;

  // The edge flag isn't used for any purpose by the translator.
  if (current_shader().writes_point_size_edge_flag_kill_vertex() & 0b101) {
    id_vector_temp_.clear();
    // Set the point size to a negative value to tell the point sprite expansion
    // that it should use the default point size if the vertex shader does not
    // override it.
    id_vector_temp_.push_back(builder_->makeFloatConstant(-1.0f));
    // The edge flag is ignored.
    id_vector_temp_.push_back(const_float_0_);
    // Don't kill by default (zero bits 0:30).
    id_vector_temp_.push_back(const_float_0_);
    var_main_point_size_edge_flag_kill_vertex_ =
        builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_float3_,
                                 "xe_var_point_size_edge_flag_kill_vertex",
                                 builder_->makeCompositeConstant(type_float3_, id_vector_temp_));
  }

  // Zero general-purpose registers to prevent crashes when the game
  // references them after only initializing them conditionally.
  for (uint32_t i = 0; i < register_count(); ++i) {
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
    builder_->createStore(
        const_float4_0_, builder_->createAccessChain(spv::StorageClassFunction, var_main_registers_,
                                                     id_vector_temp_));
  }

  if (!IsSpirvComputeShader()) {
    // Zero the interpolators.
    uint32_t interpolators_remaining = GetModificationInterpolatorMask();
    uint32_t interpolator_index;
    while (rex::bit_scan_forward(interpolators_remaining, &interpolator_index)) {
      interpolators_remaining &= ~(UINT32_C(1) << interpolator_index);
      builder_->createStore(const_float4_0_, input_output_interpolators_[interpolator_index]);
    }
  }

  // For rectangle-list fallback without geometry shaders, additional guest
  // vertex iterations are driven from CompleteTranslation via main_loop_merge_.

  // Check if memory export should be allowed for this host vertex of the guest
  // primitive to make sure export is done only once for each guest vertex.
  if (IsMemoryExportUsed()) {
    spv::Id memexport_allowed_for_host_vertex_of_guest_primitive = spv::NoResult;
    if (host_vertex_shader_type == Shader::HostVertexShaderType::kPointListAsTriangleStrip ||
        host_vertex_shader_type == Shader::HostVertexShaderType::kRectangleListAsTriangleStrip) {
      spv::Id host_vertex_in_guest_primitive = builder_->createBinOp(
          spv::OpBitwiseAnd, type_uint_,
          builder_->createUnaryOp(spv::OpBitcast, type_uint_,
                                  builder_->createLoad(input_vertex_index_, spv::NoPrecision)),
          builder_->makeUintConstant(3));
      if (host_vertex_shader_type == Shader::HostVertexShaderType::kPointListAsTriangleStrip) {
        // Only for one host vertex for the point.
        memexport_allowed_for_host_vertex_of_guest_primitive = builder_->createBinOp(
            spv::OpIEqual, type_bool_, host_vertex_in_guest_primitive, const_uint_0_);
      } else {
        if (IsSpirvRectangleListVertexLoopEnabled()) {
          // In the rectangle guest-vertex loop mode, one host invocation
          // processes all 3 guest vertices, so memexport must be done only from
          // one host strip vertex.
          memexport_allowed_for_host_vertex_of_guest_primitive = builder_->createBinOp(
              spv::OpIEqual, type_bool_, host_vertex_in_guest_primitive, const_uint_0_);
        } else {
          // The synthetic fourth host vertex must not duplicate export for
          // guest vertex 2 of the rectangle.
          memexport_allowed_for_host_vertex_of_guest_primitive =
              builder_->createBinOp(spv::OpINotEqual, type_bool_, host_vertex_in_guest_primitive,
                                    builder_->makeUintConstant(3));
        }
      }
    }

    if (memexport_allowed_for_host_vertex_of_guest_primitive != spv::NoResult) {
      main_memexport_allowed_ =
          main_memexport_allowed_ != spv::NoResult
              ? builder_->createBinOp(spv::OpLogicalAnd, type_bool_, main_memexport_allowed_,
                                      memexport_allowed_for_host_vertex_of_guest_primitive)
              : memexport_allowed_for_host_vertex_of_guest_primitive;
    }
  }

  // Load the vertex index or the tessellation parameters.
  if (register_count()) {
    auto store_register_component = [this](uint32_t register_index, uint32_t component,
                                           spv::Id value) {
      id_vector_temp_.clear();
      id_vector_temp_.push_back(builder_->makeIntConstant(int(register_index)));
      id_vector_temp_.push_back(builder_->makeIntConstant(int(component)));
      builder_->createStore(
          value, builder_->createAccessChain(spv::StorageClassFunction, var_main_registers_,
                                             id_vector_temp_));
    };
    if (IsSpirvTessEvalShader()) {
      auto load_tess_coord_component = [this](uint32_t component) {
        return builder_->createCompositeExtract(
            builder_->createLoad(input_tess_coord_, spv::NoPrecision), type_float_, component);
      };
      auto load_patch_control_point_index = [this](uint32_t component) {
        return builder_->createCompositeExtract(
            builder_->createLoad(input_patch_control_point_indices_, spv::NoPrecision), type_float_,
            component);
      };
      switch (shader_modification.vertex.host_vertex_shader_type) {
        case Shader::HostVertexShaderType::kTriangleDomainCPIndexed:
          // r0.xyz = domain location zyx, r1.xyz = control point indices.
          store_register_component(0, 0, load_tess_coord_component(2));
          store_register_component(0, 1, load_tess_coord_component(1));
          store_register_component(0, 2, load_tess_coord_component(0));
          if (register_count() >= 2) {
            store_register_component(1, 0, load_patch_control_point_index(0));
            store_register_component(1, 1, load_patch_control_point_index(1));
            store_register_component(1, 2, load_patch_control_point_index(2));
          }
          break;
        case Shader::HostVertexShaderType::kTriangleDomainPatchIndexed:
          // r0.xyz = domain location zyx, r1.x = patch index, r1.y = swizzle.
          store_register_component(0, 0, load_tess_coord_component(2));
          store_register_component(0, 1, load_tess_coord_component(1));
          store_register_component(0, 2, load_tess_coord_component(0));
          if (register_count() >= 2) {
            store_register_component(1, 0, load_patch_control_point_index(0));
            store_register_component(1, 1, const_float_0_);
          }
          break;
        case Shader::HostVertexShaderType::kQuadDomainCPIndexed:
          // r0.xy = domain location xy, r0.z/r1.xyz = control point indices.
          store_register_component(0, 0, load_tess_coord_component(0));
          store_register_component(0, 1, load_tess_coord_component(1));
          store_register_component(0, 2, load_patch_control_point_index(0));
          if (register_count() >= 2) {
            store_register_component(1, 0, load_patch_control_point_index(1));
            store_register_component(1, 1, load_patch_control_point_index(2));
            store_register_component(1, 2, load_patch_control_point_index(3));
          }
          break;
        case Shader::HostVertexShaderType::kQuadDomainPatchIndexed:
          // r0.x = patch index, r0.yz = domain location xy, r1.x = swizzle.
          store_register_component(0, 0, load_patch_control_point_index(0));
          store_register_component(0, 1, load_tess_coord_component(0));
          store_register_component(0, 2, load_tess_coord_component(1));
          if (register_count() >= 2) {
            store_register_component(1, 0, const_float_0_);
          }
          break;
        default:
          break;
      }
    }
    if (IsSpirvVertexShader() || IsSpirvComputeShader()) {
      spv::Id vertex_index;
      spv::Id compute_vertex_processing_index = spv::NoResult;
      spv::Id compute_load_vertex_index = spv::NoResult;
      spv::Id compute_vertex_index_is_32bit = spv::NoResult;
      if (IsSpirvComputeShader()) {
        spv::Id global_invocation_id = builder_->createLoad(input_vertex_index_, spv::NoPrecision);
        spv::Id global_invocation_x =
            builder_->createCompositeExtract(global_invocation_id, type_uint_, 0);
        spv::Id global_invocation_y =
            builder_->createCompositeExtract(global_invocation_id, type_uint_, 1);
        spv::Id global_invocation_z =
            builder_->createCompositeExtract(global_invocation_id, type_uint_, 2);
        compute_vertex_processing_index = builder_->createBinOp(
            spv::OpIAdd, type_uint_, global_invocation_x,
            builder_->createBinOp(
                spv::OpIAdd, type_uint_,
                builder_->createBinOp(spv::OpIMul, type_uint_, global_invocation_y,
                                      builder_->makeUintConstant(kMemExportComputeDispatchX)),
                builder_->createBinOp(spv::OpIMul, type_uint_, global_invocation_z,
                                      builder_->makeUintConstant(kMemExportComputeDispatchX *
                                                                 kMemExportComputeDispatchY))));

        id_vector_temp_.clear();
        id_vector_temp_.push_back(
            builder_->makeIntConstant(kSystemConstantComputeMemExportVertexCount));
        spv::Id compute_memexport_vertex_count = builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                        id_vector_temp_),
            spv::NoPrecision);
        spv::Id compute_vertex_in_range =
            builder_->createBinOp(spv::OpULessThan, type_bool_, compute_vertex_processing_index,
                                  compute_memexport_vertex_count);
        main_memexport_allowed_ =
            main_memexport_allowed_ != spv::NoResult
                ? builder_->createBinOp(spv::OpLogicalAnd, type_bool_, main_memexport_allowed_,
                                        compute_vertex_in_range)
                : compute_vertex_in_range;
        vertex_index = builder_->createTriOp(spv::OpSelect, type_uint_, compute_vertex_in_range,
                                             compute_vertex_processing_index, const_uint_0_);
        compute_vertex_processing_index = vertex_index;
      } else {
        vertex_index =
            builder_->createUnaryOp(spv::OpBitcast, type_uint_,
                                    builder_->createLoad(input_vertex_index_, spv::NoPrecision));
      }
      if (IsSpirvVertexShader()) {
        id_vector_temp_.clear();
        id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantLineLoopClosingIndex));
        spv::Id line_loop_closing_index = builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                        id_vector_temp_),
            spv::NoPrecision);
        vertex_index =
            builder_->createTriOp(spv::OpSelect, type_uint_,
                                  builder_->createBinOp(spv::OpINotEqual, type_bool_, vertex_index,
                                                        line_loop_closing_index),
                                  vertex_index, const_uint_0_);
      }
      if (IsSpirvVertexShader() &&
          (host_vertex_shader_type == Shader::HostVertexShaderType::kPointListAsTriangleStrip ||
           host_vertex_shader_type ==
               Shader::HostVertexShaderType::kRectangleListAsTriangleStrip)) {
        spv::Id const_uint_2 = builder_->makeUintConstant(2);
        spv::Id two_triangle_strip_vertex_index = vertex_index;
        // Extract the primitive index from the two-triangle strip vertex index.
        vertex_index = builder_->createBinOp(spv::OpShiftRightLogical, type_uint_,
                                             two_triangle_strip_vertex_index, const_uint_2);
        if (host_vertex_shader_type ==
            Shader::HostVertexShaderType::kRectangleListAsTriangleStrip) {
          spv::Id const_uint_3 = builder_->makeUintConstant(3);
          spv::Id guest_vertex_in_guest_primitive;
          if (IsSpirvRectangleListVertexLoopEnabled()) {
            // In the rectangle VS fallback loop, process guest vertices 0, 1 and
            // 2 in every host invocation.
            guest_vertex_in_guest_primitive =
                builder_->createLoad(var_main_rectangle_guest_vertex_index_, spv::NoPrecision);
          } else {
            // Rectangle lists consume 3 guest vertices per primitive. Clamp the
            // synthetic fourth host vertex to guest vertex 2.
            spv::Id host_vertex_in_guest_primitive = builder_->createBinOp(
                spv::OpBitwiseAnd, type_uint_, two_triangle_strip_vertex_index, const_uint_3);
            guest_vertex_in_guest_primitive = builder_->createTriOp(
                spv::OpSelect, type_uint_,
                builder_->createBinOp(spv::OpIEqual, type_bool_, host_vertex_in_guest_primitive,
                                      const_uint_3),
                const_uint_2, host_vertex_in_guest_primitive);
          }
          vertex_index = builder_->createBinOp(
              spv::OpIAdd, type_uint_,
              builder_->createBinOp(spv::OpIMul, type_uint_, vertex_index, const_uint_3),
              guest_vertex_in_guest_primitive);
        }
        // Check if the index needs to be loaded from the index buffer.
        spv::Id load_vertex_index = builder_->createBinOp(
            spv::OpINotEqual, type_bool_,
            builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                  builder_->makeUintConstant(static_cast<unsigned int>(
                                      kSysFlag_ComputeOrPrimitiveVertexIndexLoad))),
            const_uint_0_);
        SpirvBuilder::IfBuilder load_vertex_index_if(
            load_vertex_index, spv::SelectionControlDontFlattenMask, *builder_);
        spv::Id loaded_vertex_index;
        {
          // Check if the index is 32-bit.
          spv::Id vertex_index_is_32bit = builder_->createBinOp(
              spv::OpINotEqual, type_bool_,
              builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                    builder_->makeUintConstant(static_cast<unsigned int>(
                                        kSysFlag_ComputeOrPrimitiveVertexIndexLoad32Bit))),
              const_uint_0_);
          // Calculate the vertex index address in the shared memory.
          id_vector_temp_.clear();
          id_vector_temp_.push_back(
              builder_->makeIntConstant(kSystemConstantVertexIndexLoadAddress));
          spv::Id vertex_index_address = builder_->createBinOp(
              spv::OpIAdd, type_uint_,
              builder_->createLoad(
                  builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                              id_vector_temp_),
                  spv::NoPrecision),
              builder_->createBinOp(
                  spv::OpShiftLeftLogical, type_uint_, vertex_index,
                  builder_->createTriOp(spv::OpSelect, type_uint_, vertex_index_is_32bit,
                                        const_uint_2, builder_->makeUintConstant(1))));
          // Load the 32 bits containing the whole vertex index or two 16-bit
          // vertex indices.
          // TODO(Triang3l): Bounds checking.
          loaded_vertex_index = LoadUint32FromSharedMemory(
              builder_->createUnaryOp(spv::OpBitcast, type_int_,
                                      builder_->createBinOp(spv::OpShiftRightLogical, type_uint_,
                                                            vertex_index_address, const_uint_2)));
          // Extract the 16-bit index from the loaded 32 bits if needed.
          loaded_vertex_index = builder_->createTriOp(
              spv::OpSelect, type_uint_, vertex_index_is_32bit, loaded_vertex_index,
              builder_->createTriOp(
                  spv::OpBitFieldUExtract, type_uint_, loaded_vertex_index,
                  builder_->createBinOp(spv::OpShiftLeftLogical, type_uint_,
                                        builder_->createBinOp(spv::OpBitwiseAnd, type_uint_,
                                                              vertex_index_address, const_uint_2),
                                        builder_->makeUintConstant(4 - 1)),
                  builder_->makeUintConstant(16)));
          // Endian-swap the loaded index.
          id_vector_temp_.clear();
          id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexEndian));
          loaded_vertex_index = EndianSwap32Uint(
              loaded_vertex_index,
              builder_->createLoad(
                  builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                              id_vector_temp_),
                  spv::NoPrecision));
        }
        load_vertex_index_if.makeEndIf();
        // Select between the loaded index and the original index from Vulkan.
        vertex_index = load_vertex_index_if.createMergePhi(loaded_vertex_index, vertex_index);
      } else {
        if (IsSpirvComputeShader()) {
          // For memexport compute fallback, optionally load the original index
          // from guest DMA (16-bit or 32-bit), unless emulating adaptive
          // tessellation patch indexing (the patch index comes from invocation
          // ID in that mode).
          spv::Id patch_index_from_invocation = builder_->createBinOp(
              spv::OpINotEqual, type_bool_,
              builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                    builder_->makeUintConstant(static_cast<unsigned int>(
                                        kSysFlag_ComputeMemExportPatchIndexFromInvocation))),
              const_uint_0_);
          compute_load_vertex_index = builder_->createBinOp(
              spv::OpINotEqual, type_bool_,
              builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                    builder_->makeUintConstant(static_cast<unsigned int>(
                                        kSysFlag_ComputeOrPrimitiveVertexIndexLoad))),
              const_uint_0_);
          compute_load_vertex_index = builder_->createBinOp(
              spv::OpLogicalAnd, type_bool_, compute_load_vertex_index,
              builder_->createUnaryOp(spv::OpLogicalNot, type_bool_, patch_index_from_invocation));
          compute_vertex_index_is_32bit = builder_->createBinOp(
              spv::OpINotEqual, type_bool_,
              builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                    builder_->makeUintConstant(static_cast<unsigned int>(
                                        kSysFlag_ComputeOrPrimitiveVertexIndexLoad32Bit))),
              const_uint_0_);
          SpirvBuilder::IfBuilder load_vertex_index_if(
              compute_load_vertex_index, spv::SelectionControlDontFlattenMask, *builder_);
          spv::Id loaded_vertex_index;
          {
            id_vector_temp_.clear();
            id_vector_temp_.push_back(
                builder_->makeIntConstant(kSystemConstantVertexIndexLoadAddress));
            spv::Id vertex_index_address = builder_->createBinOp(
                spv::OpIAdd, type_uint_,
                builder_->createLoad(
                    builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                                id_vector_temp_),
                    spv::NoPrecision),
                builder_->createBinOp(
                    spv::OpShiftLeftLogical, type_uint_, vertex_index,
                    builder_->createTriOp(spv::OpSelect, type_uint_, compute_vertex_index_is_32bit,
                                          builder_->makeUintConstant(2),
                                          builder_->makeUintConstant(1))));
            loaded_vertex_index = LoadUint32FromSharedMemory(builder_->createUnaryOp(
                spv::OpBitcast, type_int_,
                builder_->createBinOp(spv::OpShiftRightLogical, type_uint_, vertex_index_address,
                                      builder_->makeUintConstant(2))));
            loaded_vertex_index = builder_->createTriOp(
                spv::OpSelect, type_uint_, compute_vertex_index_is_32bit, loaded_vertex_index,
                builder_->createTriOp(
                    spv::OpBitFieldUExtract, type_uint_, loaded_vertex_index,
                    builder_->createBinOp(
                        spv::OpShiftLeftLogical, type_uint_,
                        builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, vertex_index_address,
                                              builder_->makeUintConstant(2)),
                        builder_->makeUintConstant(3)),
                    builder_->makeUintConstant(16)));
            id_vector_temp_.clear();
            id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexEndian));
            loaded_vertex_index = EndianSwap32Uint(
                loaded_vertex_index,
                builder_->createLoad(
                    builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                                id_vector_temp_),
                    spv::NoPrecision));
          }
          load_vertex_index_if.makeEndIf();
          vertex_index = load_vertex_index_if.createMergePhi(loaded_vertex_index, vertex_index);
        } else {
          // Load the unswapped index as uint for swapping, or for indirect
          // loading if needed.
          if (!features_.full_draw_index_uint32) {
            // Check if the full 32-bit index needs to be loaded indirectly.
            spv::Id load_vertex_index = builder_->createBinOp(
                spv::OpINotEqual, type_bool_,
                builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                      builder_->makeUintConstant(
                                          static_cast<unsigned int>(kSysFlag_VertexIndexLoad))),
                const_uint_0_);
            SpirvBuilder::IfBuilder load_vertex_index_if(
                load_vertex_index, spv::SelectionControlDontFlattenMask, *builder_);
            spv::Id loaded_vertex_index;
            {
              // Load the 32-bit index.
              // TODO(Triang3l): Bounds checking.
              id_vector_temp_.clear();
              id_vector_temp_.push_back(
                  builder_->makeIntConstant(kSystemConstantVertexIndexLoadAddress));
              loaded_vertex_index = LoadUint32FromSharedMemory(builder_->createUnaryOp(
                  spv::OpBitcast, type_int_,
                  builder_->createBinOp(
                      spv::OpIAdd, type_uint_,
                      builder_->createBinOp(
                          spv::OpShiftRightLogical, type_uint_,
                          builder_->createLoad(builder_->createAccessChain(
                                                   spv::StorageClassUniform,
                                                   uniform_system_constants_, id_vector_temp_),
                                               spv::NoPrecision),
                          builder_->makeUintConstant(2)),
                      vertex_index)));
            }
            load_vertex_index_if.makeEndIf();
            // Select between the loaded index and the original index from Vulkan.
            vertex_index = load_vertex_index_if.createMergePhi(loaded_vertex_index, vertex_index);
          }
          // Endian-swap the index.
          id_vector_temp_.clear();
          id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexEndian));
          vertex_index = EndianSwap32Uint(
              vertex_index, builder_->createLoad(builder_->createAccessChain(
                                                     spv::StorageClassUniform,
                                                     uniform_system_constants_, id_vector_temp_),
                                                 spv::NoPrecision));
        }
      }
      if (IsSpirvComputeShader() && IsMemoryExportUsed()) {
        // Primitive reset must suppress memexport for reset-index invocations
        // in the compute fallback path.
        spv::Id primitive_reset_enabled = builder_->createBinOp(
            spv::OpINotEqual, type_bool_,
            builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                  builder_->makeUintConstant(static_cast<unsigned int>(
                                      kSysFlag_ComputeOrPrimitiveVertexIndexReset))),
            const_uint_0_);
        spv::Id vertex_index_is_32bit = builder_->createBinOp(
            spv::OpINotEqual, type_bool_,
            builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                  builder_->makeUintConstant(static_cast<unsigned int>(
                                      kSysFlag_ComputeOrPrimitiveVertexIndexLoad32Bit))),
            const_uint_0_);
        id_vector_temp_.clear();
        id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexReset));
        spv::Id vertex_index_reset = builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                        id_vector_temp_),
            spv::NoPrecision);
        spv::Id vertex_index_not_reset_16 =
            builder_->createBinOp(spv::OpINotEqual, type_bool_, vertex_index, vertex_index_reset);
        spv::Id vertex_index_not_reset_32 = builder_->createBinOp(
            spv::OpINotEqual, type_bool_,
            builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, vertex_index,
                                  builder_->makeUintConstant(xenos::kVertexIndexMask)),
            vertex_index_reset);
        spv::Id vertex_index_not_reset =
            builder_->createTriOp(spv::OpSelect, type_bool_, vertex_index_is_32bit,
                                  vertex_index_not_reset_32, vertex_index_not_reset_16);
        spv::Id memexport_allowed_for_non_reset_index = builder_->createBinOp(
            spv::OpLogicalOr, type_bool_,
            builder_->createUnaryOp(spv::OpLogicalNot, type_bool_, primitive_reset_enabled),
            vertex_index_not_reset);
        main_memexport_allowed_ =
            main_memexport_allowed_ != spv::NoResult
                ? builder_->createBinOp(spv::OpLogicalAnd, type_bool_, main_memexport_allowed_,
                                        memexport_allowed_for_non_reset_index)
                : memexport_allowed_for_non_reset_index;
      }
      // Add the base index, apply the 24-bit index mask and clamp to the
      // draw's index range similarly to the Direct3D path.
      id_vector_temp_.clear();
      id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexBaseIndex));
      spv::Id vertex_base_index = builder_->createLoad(
          builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                      id_vector_temp_),
          spv::NoPrecision);
      id_vector_temp_.clear();
      id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexMin));
      spv::Id vertex_index_min = builder_->createLoad(
          builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                      id_vector_temp_),
          spv::NoPrecision);
      id_vector_temp_.clear();
      id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexMax));
      spv::Id vertex_index_max = builder_->createLoad(
          builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                      id_vector_temp_),
          spv::NoPrecision);
      auto remap_vertex_index_to_float = [this, vertex_base_index, vertex_index_min,
                                          vertex_index_max](spv::Id index) {
        index = builder_->createBinOp(
            spv::OpIAdd, type_uint_, index,
            builder_->createUnaryOp(spv::OpBitcast, type_uint_, vertex_base_index));
        index = builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, index,
                                      builder_->makeUintConstant(xenos::kVertexIndexMask));
        index = builder_->createTriBuiltinCall(type_uint_, ext_inst_glsl_std_450_, GLSLstd450UClamp,
                                               index, vertex_index_min, vertex_index_max);
        return builder_->createUnaryOp(spv::OpConvertUToF, type_float_, index);
      };
      // Write the index to the register expected by the current host vertex
      // shader mode.
      spv::Id vertex_index_float = remap_vertex_index_to_float(vertex_index);
      if (IsSpirvComputeShader()) {
        auto load_compute_vertex_index_float = [this, compute_load_vertex_index,
                                                compute_vertex_index_is_32bit,
                                                &remap_vertex_index_to_float](
                                                   spv::Id vertex_processing_index) {
          spv::Id index = vertex_processing_index;
          SpirvBuilder::IfBuilder load_vertex_index_if(
              compute_load_vertex_index, spv::SelectionControlDontFlattenMask, *builder_);
          spv::Id loaded_vertex_index;
          {
            id_vector_temp_.clear();
            id_vector_temp_.push_back(
                builder_->makeIntConstant(kSystemConstantVertexIndexLoadAddress));
            spv::Id vertex_index_address = builder_->createBinOp(
                spv::OpIAdd, type_uint_,
                builder_->createLoad(
                    builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                                id_vector_temp_),
                    spv::NoPrecision),
                builder_->createBinOp(
                    spv::OpShiftLeftLogical, type_uint_, vertex_processing_index,
                    builder_->createTriOp(spv::OpSelect, type_uint_, compute_vertex_index_is_32bit,
                                          builder_->makeUintConstant(2),
                                          builder_->makeUintConstant(1))));
            loaded_vertex_index = LoadUint32FromSharedMemory(builder_->createUnaryOp(
                spv::OpBitcast, type_int_,
                builder_->createBinOp(spv::OpShiftRightLogical, type_uint_, vertex_index_address,
                                      builder_->makeUintConstant(2))));
            loaded_vertex_index = builder_->createTriOp(
                spv::OpSelect, type_uint_, compute_vertex_index_is_32bit, loaded_vertex_index,
                builder_->createTriOp(
                    spv::OpBitFieldUExtract, type_uint_, loaded_vertex_index,
                    builder_->createBinOp(
                        spv::OpShiftLeftLogical, type_uint_,
                        builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, vertex_index_address,
                                              builder_->makeUintConstant(2)),
                        builder_->makeUintConstant(3)),
                    builder_->makeUintConstant(16)));
            id_vector_temp_.clear();
            id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantVertexIndexEndian));
            loaded_vertex_index = EndianSwap32Uint(
                loaded_vertex_index,
                builder_->createLoad(
                    builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                                id_vector_temp_),
                    spv::NoPrecision));
          }
          load_vertex_index_if.makeEndIf();
          index = load_vertex_index_if.createMergePhi(loaded_vertex_index, index);
          return remap_vertex_index_to_float(index);
        };
        spv::Id triangle_cp_indexed = builder_->createBinOp(
            spv::OpINotEqual, type_bool_,
            builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                  builder_->makeUintConstant(static_cast<unsigned int>(
                                      kSysFlag_ComputeMemExportTriangleCPIndexed))),
            const_uint_0_);
        spv::Id quad_cp_indexed = builder_->createBinOp(
            spv::OpINotEqual, type_bool_,
            builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                  builder_->makeUintConstant(static_cast<unsigned int>(
                                      kSysFlag_ComputeMemExportQuadCPIndexed))),
            const_uint_0_);
        spv::Id cp_indexed = builder_->createBinOp(spv::OpLogicalOr, type_bool_,
                                                   triangle_cp_indexed, quad_cp_indexed);
        SpirvBuilder::IfBuilder if_cp_indexed(cp_indexed, spv::SelectionControlDontFlattenMask,
                                              *builder_);
        {
          spv::Id cp_count =
              builder_->createTriOp(spv::OpSelect, type_uint_, triangle_cp_indexed,
                                    builder_->makeUintConstant(3), builder_->makeUintConstant(4));
          spv::Id cp_in_patch = builder_->createBinOp(spv::OpUMod, type_uint_,
                                                      compute_vertex_processing_index, cp_count);
          spv::Id patch_first_vertex_processing_index = builder_->createBinOp(
              spv::OpISub, type_uint_, compute_vertex_processing_index, cp_in_patch);
          spv::Id cp_index_0 = load_compute_vertex_index_float(patch_first_vertex_processing_index);
          spv::Id cp_index_1 = load_compute_vertex_index_float(
              builder_->createBinOp(spv::OpIAdd, type_uint_, patch_first_vertex_processing_index,
                                    builder_->makeUintConstant(1)));
          spv::Id cp_index_2 = load_compute_vertex_index_float(
              builder_->createBinOp(spv::OpIAdd, type_uint_, patch_first_vertex_processing_index,
                                    builder_->makeUintConstant(2)));

          SpirvBuilder::IfBuilder if_triangle_cp(triangle_cp_indexed,
                                                 spv::SelectionControlDontFlattenMask, *builder_);
          {
            // Emulate barycentric corner selection for the current control
            // point in the patch: r0.xyz = domain location zyx.
            spv::Id cp_is_0 =
                builder_->createBinOp(spv::OpIEqual, type_bool_, cp_in_patch, const_uint_0_);
            spv::Id cp_is_1 = builder_->createBinOp(spv::OpIEqual, type_bool_, cp_in_patch,
                                                    builder_->makeUintConstant(1));
            spv::Id cp_is_2 = builder_->createBinOp(spv::OpIEqual, type_bool_, cp_in_patch,
                                                    builder_->makeUintConstant(2));
            spv::Id domain_z = builder_->createTriOp(spv::OpSelect, type_float_, cp_is_2,
                                                     const_float_1_, const_float_0_);
            spv::Id domain_y = builder_->createTriOp(spv::OpSelect, type_float_, cp_is_1,
                                                     const_float_1_, const_float_0_);
            spv::Id domain_x = builder_->createTriOp(spv::OpSelect, type_float_, cp_is_0,
                                                     const_float_1_, const_float_0_);
            store_register_component(0, 0, domain_z);
            store_register_component(0, 1, domain_y);
            store_register_component(0, 2, domain_x);
            if (register_count() >= 2) {
              store_register_component(1, 0, cp_index_0);
              store_register_component(1, 1, cp_index_1);
              store_register_component(1, 2, cp_index_2);
            }
          }
          if_triangle_cp.makeBeginElse();
          {
            // Emulate quad corner selection for the current control point:
            // r0.xy = domain location xy.
            spv::Id cp_is_1 = builder_->createBinOp(spv::OpIEqual, type_bool_, cp_in_patch,
                                                    builder_->makeUintConstant(1));
            spv::Id cp_is_2 = builder_->createBinOp(spv::OpIEqual, type_bool_, cp_in_patch,
                                                    builder_->makeUintConstant(2));
            spv::Id cp_is_3 = builder_->createBinOp(spv::OpIEqual, type_bool_, cp_in_patch,
                                                    builder_->makeUintConstant(3));
            spv::Id domain_x = builder_->createTriOp(
                spv::OpSelect, type_float_,
                builder_->createBinOp(spv::OpLogicalOr, type_bool_, cp_is_1, cp_is_2),
                const_float_1_, const_float_0_);
            spv::Id domain_y = builder_->createTriOp(
                spv::OpSelect, type_float_,
                builder_->createBinOp(spv::OpLogicalOr, type_bool_, cp_is_2, cp_is_3),
                const_float_1_, const_float_0_);
            store_register_component(0, 0, domain_x);
            store_register_component(0, 1, domain_y);
            store_register_component(0, 2, cp_index_0);
            if (register_count() >= 2) {
              spv::Id cp_index_3 = load_compute_vertex_index_float(builder_->createBinOp(
                  spv::OpIAdd, type_uint_, patch_first_vertex_processing_index,
                  builder_->makeUintConstant(3)));
              store_register_component(1, 0, cp_index_1);
              store_register_component(1, 1, cp_index_2);
              store_register_component(1, 2, cp_index_3);
            }
          }
          if_triangle_cp.makeEndIf();
        }
        if_cp_indexed.makeBeginElse();
        if (register_count() >= 2) {
          spv::Id patch_index_in_register_1 = builder_->createBinOp(
              spv::OpINotEqual, type_bool_,
              builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                    builder_->makeUintConstant(static_cast<unsigned int>(
                                        kSysFlag_ComputeMemExportPatchIndexInRegister1))),
              const_uint_0_);
          SpirvBuilder::IfBuilder if_patch_index_in_register_1(
              patch_index_in_register_1, spv::SelectionControlDontFlattenMask, *builder_);
          store_register_component(1, 0, vertex_index_float);
          if_patch_index_in_register_1.makeBeginElse();
          store_register_component(0, 0, vertex_index_float);
          if_patch_index_in_register_1.makeEndIf();
        } else {
          store_register_component(0, 0, vertex_index_float);
        }
        if_cp_indexed.makeEndIf();
      } else {
        store_register_component(0, 0, vertex_index_float);
      }
    }
  }
}

void SpirvShaderTranslator::CompleteVertexOrTessEvalShaderInMain() {
  Modification shader_modification = GetSpirvShaderModification();

  id_vector_temp_.clear();
  id_vector_temp_.push_back(builder_->makeIntConstant(kOutputPerVertexMemberPosition));
  spv::Id position_ptr =
      builder_->createAccessChain(spv::StorageClassOutput, output_per_vertex_, id_vector_temp_);
  spv::Id guest_position = builder_->createLoad(position_ptr, spv::NoPrecision);

  // Check if the shader already returns W, not 1/W, and if it doesn't, turn 1/W
  // into W.
  spv::Id position_w = builder_->createCompositeExtract(guest_position, type_float_, 3);
  spv::Id is_w_not_reciprocal = builder_->createBinOp(
      spv::OpINotEqual, type_bool_,
      builder_->createBinOp(
          spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
          builder_->makeUintConstant(static_cast<unsigned int>(kSysFlag_WNotReciprocal))),
      const_uint_0_);
  spv::Id guest_position_w_inv =
      builder_->createNoContractionBinOp(spv::OpFDiv, type_float_, const_float_1_, position_w);
  position_w = builder_->createTriOp(spv::OpSelect, type_float_, is_w_not_reciprocal, position_w,
                                     guest_position_w_inv);

  spv::Id position_xyz;

  // Open a scope since position_xy and position_z won't be synchronized anymore
  // after position_xyz is built and modified later.
  {
    // Check if the shader returns XY/W rather than XY, and if it does, revert
    // that.
    uint_vector_temp_.clear();
    uint_vector_temp_.push_back(0);
    uint_vector_temp_.push_back(1);
    spv::Id position_xy = builder_->createRvalueSwizzle(spv::NoPrecision, type_float2_,
                                                        guest_position, uint_vector_temp_);
    spv::Id is_xy_divided_by_w = builder_->createBinOp(
        spv::OpINotEqual, type_bool_,
        builder_->createBinOp(
            spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
            builder_->makeUintConstant(static_cast<unsigned int>(kSysFlag_XYDividedByW))),
        const_uint_0_);
    spv::Id guest_position_xy_mul_w = builder_->createNoContractionBinOp(
        spv::OpVectorTimesScalar, type_float2_, position_xy, position_w);
    position_xy = builder_->createTriOp(
        spv::OpSelect, type_float2_,
        builder_->smearScalar(spv::NoPrecision, is_xy_divided_by_w, type_bool2_),
        guest_position_xy_mul_w, position_xy);

    // Check if the shader returns Z/W rather than Z, and if it does, revert
    // that.
    spv::Id position_z = builder_->createCompositeExtract(guest_position, type_float_, 2);
    spv::Id is_z_divided_by_w = builder_->createBinOp(
        spv::OpINotEqual, type_bool_,
        builder_->createBinOp(
            spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
            builder_->makeUintConstant(static_cast<unsigned int>(kSysFlag_ZDividedByW))),
        const_uint_0_);
    spv::Id guest_position_z_mul_w =
        builder_->createNoContractionBinOp(spv::OpFMul, type_float_, position_z, position_w);
    position_z = builder_->createTriOp(spv::OpSelect, type_float_, is_z_divided_by_w,
                                       guest_position_z_mul_w, position_z);

    // Build XYZ of the position with W format handled.
    {
      std::unique_ptr<spv::Instruction> composite_construct_op = std::make_unique<spv::Instruction>(
          builder_->getUniqueId(), type_float3_, spv::OpCompositeConstruct);
      composite_construct_op->addIdOperand(position_xy);
      composite_construct_op->addIdOperand(position_z);
      position_xyz = composite_construct_op->getResultId();
      builder_->getBuildPoint()->addInstruction(std::move(composite_construct_op));
    }
  }

  uint32_t clip_distance_next_component = 0;
  uint32_t cull_distance_next_component = 0;
  // Clip against user clip planes.
  if (shader_modification.vertex.user_clip_plane_count) {
    uint32_t output_per_vertex_member_clip_or_cull_distance =
        shader_modification.vertex.user_clip_plane_cull ? output_per_vertex_member_cull_distance_
                                                        : output_per_vertex_member_clip_distance_;
    assert_true(output_per_vertex_member_clip_or_cull_distance != UINT32_MAX);
    // Position with W format handled, but before guest-to-host NDC transform.
    spv::Id guest_position_formatted;
    {
      // Bypass the `getNumTypeConstituents(typeId) == (int)constituents.size()`
      // assertion in createCompositeConstruct, OpCompositeConstruct can
      // construct vectors not only from scalars, but also from other vectors.
      std::unique_ptr<spv::Instruction> composite_construct_op = std::make_unique<spv::Instruction>(
          builder_->getUniqueId(), type_float4_, spv::OpCompositeConstruct);
      composite_construct_op->addIdOperand(position_xyz);
      composite_construct_op->addIdOperand(position_w);
      guest_position_formatted = composite_construct_op->getResultId();
      builder_->getBuildPoint()->addInstruction(std::move(composite_construct_op));
    }
    uint32_t& user_clip_plane_next_component = shader_modification.vertex.user_clip_plane_cull
                                                   ? cull_distance_next_component
                                                   : clip_distance_next_component;
    for (uint32_t i = 0; i < shader_modification.vertex.user_clip_plane_count; ++i) {
      id_vector_temp_.clear();
      id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantUserClipPlanes));
      id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
      spv::Id user_clip_plane = builder_->createLoad(
          builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                      id_vector_temp_),
          spv::NoPrecision);
      spv::Id user_clip_distance =
          builder_->createBinOp(spv::OpDot, type_float_, guest_position_formatted, user_clip_plane);
      id_vector_temp_.clear();
      id_vector_temp_.push_back(
          builder_->makeIntConstant(int(output_per_vertex_member_clip_or_cull_distance)));
      id_vector_temp_.push_back(builder_->makeIntConstant(int(user_clip_plane_next_component)));
      builder_->createStore(user_clip_distance,
                            builder_->createAccessChain(spv::StorageClassOutput, output_per_vertex_,
                                                        id_vector_temp_));
      ++user_clip_plane_next_component;
    }
  }

  // Apply the NDC scale and offset for guest to host viewport transformation.
  id_vector_temp_.clear();
  id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantNdcScale));
  spv::Id ndc_scale =
      builder_->createLoad(builder_->createAccessChain(spv::StorageClassUniform,
                                                       uniform_system_constants_, id_vector_temp_),
                           spv::NoPrecision);
  position_xyz =
      builder_->createNoContractionBinOp(spv::OpFMul, type_float3_, position_xyz, ndc_scale);
  id_vector_temp_.clear();
  id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantNdcOffset));
  spv::Id ndc_offset =
      builder_->createLoad(builder_->createAccessChain(spv::StorageClassUniform,
                                                       uniform_system_constants_, id_vector_temp_),
                           spv::NoPrecision);
  spv::Id ndc_offset_mul_w = builder_->createNoContractionBinOp(
      spv::OpVectorTimesScalar, type_float3_, ndc_offset, position_w);
  position_xyz =
      builder_->createNoContractionBinOp(spv::OpFAdd, type_float3_, position_xyz, ndc_offset_mul_w);

  spv::Id kill_vertex = spv::NoResult;
  if (current_shader().writes_point_size_edge_flag_kill_vertex() & 0b100) {
    assert_true(var_main_point_size_edge_flag_kill_vertex_ != spv::NoResult);
    id_vector_temp_.clear();
    // Z component.
    id_vector_temp_.push_back(builder_->makeIntConstant(2));
    spv::Id kill_vertex_bits = builder_->createUnaryOp(
        spv::OpBitcast, type_uint_,
        builder_->createLoad(builder_->createAccessChain(spv::StorageClassFunction,
                                                         var_main_point_size_edge_flag_kill_vertex_,
                                                         id_vector_temp_),
                             spv::NoPrecision));
    kill_vertex = builder_->createBinOp(
        spv::OpINotEqual, type_bool_,
        builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, kill_vertex_bits,
                              builder_->makeUintConstant(UINT32_C(0x7FFFFFFF))),
        const_uint_0_);
  }
  if (kill_vertex != spv::NoResult && shader_modification.vertex.vertex_kill_and &&
      output_per_vertex_member_cull_distance_ != UINT32_MAX) {
    // In AND mode, kill via cull distance so the primitive is culled only if
    // all vertices request kill.
    id_vector_temp_.clear();
    id_vector_temp_.push_back(
        builder_->makeIntConstant(int(output_per_vertex_member_cull_distance_)));
    id_vector_temp_.push_back(builder_->makeIntConstant(int(cull_distance_next_component)));
    builder_->createStore(
        builder_->createTriOp(spv::OpSelect, type_float_, kill_vertex,
                              builder_->makeFloatConstant(-1.0f), const_float_0_),
        builder_->createAccessChain(spv::StorageClassOutput, output_per_vertex_, id_vector_temp_));
    ++cull_distance_next_component;
  } else if (kill_vertex != spv::NoResult) {
    // OR mode - kill the primitive by setting W to NaN.
    position_w = builder_->createTriOp(
        spv::OpSelect, type_float_, kill_vertex,
        builder_->createUnaryOp(spv::OpBitcast, type_float_,
                                builder_->makeUintConstant(UINT32_C(0x7FC00000))),
        position_w);
  }

  // Write the point size.
  if (output_point_size_ != spv::NoResult) {
    spv::Id point_size;
    if (current_shader().writes_point_size_edge_flag_kill_vertex() & 0b001) {
      assert_true(var_main_point_size_edge_flag_kill_vertex_ != spv::NoResult);
      id_vector_temp_.clear();
      // X vector component.
      id_vector_temp_.push_back(const_int_0_);
      point_size = builder_->createLoad(
          builder_->createAccessChain(spv::StorageClassFunction,
                                      var_main_point_size_edge_flag_kill_vertex_, id_vector_temp_),
          spv::NoPrecision);
    } else {
      // Not statically overridden - write a negative value.
      point_size = builder_->makeFloatConstant(-1.0f);
    }
    builder_->createStore(point_size, output_point_size_);
  }

  // Expand the point sprite.
  if (shader_modification.vertex.host_vertex_shader_type ==
      Shader::HostVertexShaderType::kPointListAsTriangleStrip) {
    // Top-left, bottom-left, top-right, bottom-right order (chosen arbitrarily,
    // simply based on counterclockwise meaning front with
    // frontFace = VkFrontFace(0), but faceness is ignored for non-polygon
    // primitive types).
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeUintConstant(0b10));
    id_vector_temp_.push_back(builder_->makeUintConstant(0b01));
    spv::Id point_vertex_positive = builder_->createBinOp(
        spv::OpINotEqual, type_bool2_,
        builder_->createBinOp(
            spv::OpBitwiseAnd, type_uint2_,
            builder_->smearScalar(spv::NoPrecision,
                                  builder_->createUnaryOp(
                                      spv::OpBitcast, type_uint_,
                                      builder_->createLoad(input_vertex_index_, spv::NoPrecision)),
                                  type_uint2_),
            builder_->createCompositeConstruct(type_uint2_, id_vector_temp_)),
        SpirvSmearScalarResultOrConstant(const_uint_0_, type_uint2_));

    // Load the point diameter in guest pixels, with the override from the
    // vertex shader if provided.
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantPointConstantDiameter));
    spv::Id point_guest_diameter = builder_->createLoad(
        builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                    id_vector_temp_),
        spv::NoPrecision);
    if (current_shader().writes_point_size_edge_flag_kill_vertex() & 0b001) {
      assert_true(var_main_point_size_edge_flag_kill_vertex_ != spv::NoResult);
      id_vector_temp_.clear();
      id_vector_temp_.push_back(const_int_0_);
      spv::Id point_vertex_diameter = builder_->createLoad(
          builder_->createAccessChain(spv::StorageClassFunction,
                                      var_main_point_size_edge_flag_kill_vertex_, id_vector_temp_),
          spv::NoPrecision);
      // The vertex shader's header writes -1.0 to point_size by default, so any
      // non-negative value means that it was overwritten by the translated
      // vertex shader, and needs to be used instead of the constant size. The
      // per-vertex diameter has already been clamped earlier in translation
      // (combined with making it non-negative).
      point_guest_diameter = builder_->createTriOp(
          spv::OpSelect, type_float2_,
          builder_->smearScalar(spv::NoPrecision,
                                builder_->createBinOp(spv::OpFOrdGreaterThanEqual, type_bool_,
                                                      point_vertex_diameter, const_float_0_),
                                type_bool2_),
          builder_->smearScalar(spv::NoPrecision, point_vertex_diameter, type_float2_),
          point_guest_diameter);
    }
    // Transform the diameter in the guest screen coordinates to radius in the
    // normalized device coordinates.
    id_vector_temp_.clear();
    id_vector_temp_.push_back(
        builder_->makeIntConstant(kSystemConstantPointScreenDiameterToNdcRadius));
    spv::Id point_radius = builder_->createNoContractionBinOp(
        spv::OpFMul, type_float2_, point_guest_diameter,
        builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                        id_vector_temp_),
            spv::NoPrecision));
    // Transform the radius from the normalized device coordinates to the clip
    // space.
    point_radius = builder_->createNoContractionBinOp(spv::OpVectorTimesScalar, type_float2_,
                                                      point_radius, position_w);

    // Expand the point sprite in the direction for the current host vertex.
    uint_vector_temp_.clear();
    uint_vector_temp_.push_back(0);
    uint_vector_temp_.push_back(1);
    spv::Id point_position_xy = builder_->createNoContractionBinOp(
        spv::OpFAdd, type_float2_,
        builder_->createRvalueSwizzle(spv::NoPrecision, type_float2_, position_xyz,
                                      uint_vector_temp_),
        builder_->createTriOp(
            spv::OpSelect, type_float2_, point_vertex_positive, point_radius,
            builder_->createNoContractionUnaryOp(spv::OpFNegate, type_float2_, point_radius)));
    spv::Id point_position_z = builder_->createCompositeExtract(position_xyz, type_float_, 2);

    // Store the position.
    spv::Id position;
    {
      // Bypass the `getNumTypeConstituents(typeId) == (int)constituents.size()`
      // assertion in createCompositeConstruct, OpCompositeConstruct can
      // construct vectors not only from scalars, but also from other vectors.
      std::unique_ptr<spv::Instruction> composite_construct_op = std::make_unique<spv::Instruction>(
          builder_->getUniqueId(), type_float4_, spv::OpCompositeConstruct);
      composite_construct_op->addIdOperand(point_position_xy);
      composite_construct_op->addIdOperand(point_position_z);
      composite_construct_op->addIdOperand(position_w);
      position = composite_construct_op->getResultId();
      builder_->getBuildPoint()->addInstruction(std::move(composite_construct_op));
    }
    builder_->createStore(position, position_ptr);

    // Write the point coordinates.
    if (output_point_coordinates_ != spv::NoResult) {
      builder_->createStore(
          builder_->createTriOp(spv::OpSelect, type_float2_, point_vertex_positive, const_float2_1_,
                                const_float2_0_),
          output_point_coordinates_);
    }

    bool point_recalculate_clip_distances = shader_modification.vertex.user_clip_plane_count &&
                                            !shader_modification.vertex.user_clip_plane_cull &&
                                            shader_modification.vertex.point_ps_ucp_mode >= 2;
    bool point_recalculate_cull_distances = shader_modification.vertex.user_clip_plane_count &&
                                            shader_modification.vertex.user_clip_plane_cull &&
                                            shader_modification.vertex.point_ps_ucp_mode >= 3;
    if (point_recalculate_clip_distances || point_recalculate_cull_distances) {
      uint32_t output_per_vertex_member_user_clip_distance =
          point_recalculate_cull_distances ? output_per_vertex_member_cull_distance_
                                           : output_per_vertex_member_clip_distance_;
      assert_true(output_per_vertex_member_user_clip_distance != UINT32_MAX);

      // Convert host clip space back to guest clip space before applying user
      // clip planes.
      spv::Id point_position_xyz;
      {
        std::unique_ptr<spv::Instruction> composite_construct_op =
            std::make_unique<spv::Instruction>(builder_->getUniqueId(), type_float3_,
                                               spv::OpCompositeConstruct);
        composite_construct_op->addIdOperand(point_position_xy);
        composite_construct_op->addIdOperand(point_position_z);
        point_position_xyz = composite_construct_op->getResultId();
        builder_->getBuildPoint()->addInstruction(std::move(composite_construct_op));
      }
      spv::Id point_guest_position_xyz = builder_->createNoContractionBinOp(
          spv::OpFSub, type_float3_, point_position_xyz,
          builder_->createNoContractionBinOp(spv::OpVectorTimesScalar, type_float3_, ndc_offset,
                                             position_w));
      point_guest_position_xyz = builder_->createNoContractionBinOp(
          spv::OpFDiv, type_float3_, point_guest_position_xyz, ndc_scale);
      spv::Id point_guest_position;
      {
        std::unique_ptr<spv::Instruction> composite_construct_op =
            std::make_unique<spv::Instruction>(builder_->getUniqueId(), type_float4_,
                                               spv::OpCompositeConstruct);
        composite_construct_op->addIdOperand(point_guest_position_xyz);
        composite_construct_op->addIdOperand(position_w);
        point_guest_position = composite_construct_op->getResultId();
        builder_->getBuildPoint()->addInstruction(std::move(composite_construct_op));
      }

      for (uint32_t i = 0; i < shader_modification.vertex.user_clip_plane_count; ++i) {
        id_vector_temp_.clear();
        id_vector_temp_.push_back(builder_->makeIntConstant(kSystemConstantUserClipPlanes));
        id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
        spv::Id user_clip_plane = builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                        id_vector_temp_),
            spv::NoPrecision);
        spv::Id user_clip_distance =
            builder_->createBinOp(spv::OpDot, type_float_, point_guest_position, user_clip_plane);
        id_vector_temp_.clear();
        id_vector_temp_.push_back(
            builder_->makeIntConstant(int(output_per_vertex_member_user_clip_distance)));
        id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
        builder_->createStore(user_clip_distance,
                              builder_->createAccessChain(spv::StorageClassOutput,
                                                          output_per_vertex_, id_vector_temp_));
      }
    }
  } else {
    // Store the position converted to the host.
    spv::Id position;
    {
      // Bypass the `getNumTypeConstituents(typeId) == (int)constituents.size()`
      // assertion in createCompositeConstruct, OpCompositeConstruct can
      // construct vectors not only from scalars, but also from other vectors.
      std::unique_ptr<spv::Instruction> composite_construct_op = std::make_unique<spv::Instruction>(
          builder_->getUniqueId(), type_float4_, spv::OpCompositeConstruct);
      composite_construct_op->addIdOperand(position_xyz);
      composite_construct_op->addIdOperand(position_w);
      position = composite_construct_op->getResultId();
      builder_->getBuildPoint()->addInstruction(std::move(composite_construct_op));
    }
    builder_->createStore(position, position_ptr);
  }
}

void SpirvShaderTranslator::StartFragmentShaderBeforeMain() {
  Modification shader_modification = GetSpirvShaderModification();

  if (edram_fragment_shader_interlock_) {
    builder_->addExtension("SPV_EXT_fragment_shader_interlock");

    // EDRAM buffer uint[].
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeRuntimeArray(type_uint_));
    // Storage buffers have std430 packing, no padding to 4-component vectors.
    builder_->addDecoration(id_vector_temp_.back(), spv::DecorationArrayStride, sizeof(uint32_t));
    spv::Id type_edram = builder_->makeStructType(id_vector_temp_, "XeEdram");
    builder_->addMemberName(type_edram, 0, "edram");
    builder_->addMemberDecoration(type_edram, 0, spv::DecorationCoherent);
    builder_->addMemberDecoration(type_edram, 0, spv::DecorationRestrict);
    builder_->addMemberDecoration(type_edram, 0, spv::DecorationOffset, 0);
    builder_->addDecoration(type_edram, features_.spirv_version >= spv::Spv_1_3
                                            ? spv::DecorationBlock
                                            : spv::DecorationBufferBlock);
    buffer_edram_ = builder_->createVariable(spv::NoPrecision,
                                             features_.spirv_version >= spv::Spv_1_3
                                                 ? spv::StorageClassStorageBuffer
                                                 : spv::StorageClassUniform,
                                             type_edram, "xe_edram");
    builder_->addDecoration(buffer_edram_, spv::DecorationDescriptorSet,
                            int(kDescriptorSetSharedMemoryAndEdram));
    builder_->addDecoration(buffer_edram_, spv::DecorationBinding, 1);
    if (features_.spirv_version >= spv::Spv_1_4) {
      main_interface_.push_back(buffer_edram_);
    }
  }

  bool param_gen_needed =
      !is_depth_only_fragment_shader_ && GetPsParamGenInterpolator() != UINT32_MAX;

  if (!is_depth_only_fragment_shader_) {
    uint32_t input_location = 0;

    // Interpolator inputs.
    {
      uint32_t interpolators_remaining = GetModificationInterpolatorMask();
      uint32_t interpolator_index;
      while (rex::bit_scan_forward(interpolators_remaining, &interpolator_index)) {
        interpolators_remaining &= ~(UINT32_C(1) << interpolator_index);
        spv::Id interpolator = builder_->createVariable(
            spv::NoPrecision, spv::StorageClassInput, type_float4_,
            fmt::format("xe_in_interpolator_{}", interpolator_index).c_str());
        input_output_interpolators_[interpolator_index] = interpolator;
        builder_->addDecoration(interpolator, spv::DecorationLocation, int(input_location));
        if (shader_modification.pixel.interpolators_centroid &
            (UINT32_C(1) << interpolator_index)) {
          builder_->addDecoration(interpolator, spv::DecorationCentroid);
        }
        main_interface_.push_back(interpolator);
        ++input_location;
      }
    }

    // Point coordinate input.
    if (shader_modification.pixel.param_gen_point) {
      if (param_gen_needed) {
        input_point_coordinates_ = builder_->createVariable(
            spv::NoPrecision, spv::StorageClassInput, type_float2_, "xe_in_point_coordinates");
        builder_->addDecoration(input_point_coordinates_, spv::DecorationLocation,
                                int(input_location));
        main_interface_.push_back(input_point_coordinates_);
      }
      ++input_location;
    }
  }

  bool float24_depth_conversion = IsWritingFloat24Depth();
  bool float24_depth_from_fragment_coordinates =
      float24_depth_conversion && !current_shader().writes_depth();
  bool alpha_to_coverage_possible = !is_depth_only_fragment_shader_ &&
                                    current_shader().writes_color_target(0) &&
                                    !IsExecutionModeEarlyFragmentTests();

  // Fragment coordinates.
  // TODO(Triang3l): More conditions - alpha to coverage (if RT 0 is written,
  // and there's no early depth / stencil), depth writing in the fragment shader
  // (per-sample if supported).
  bool memexport_resolution_scaled = current_shader().memexport_eM_written() &&
                                     (draw_resolution_scale_x_ > 1 || draw_resolution_scale_y_ > 1);
  const bool object_slot_output =
      !edram_fragment_shader_interlock_ && GetSpirvShaderModification().pixel.object_slot_output;
  if (edram_fragment_shader_interlock_ || param_gen_needed || memexport_resolution_scaled ||
      float24_depth_from_fragment_coordinates || alpha_to_coverage_possible ||
      object_slot_output) {
    input_fragment_coordinates_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassInput,
                                                           type_float4_, "gl_FragCoord");
    builder_->addDecoration(input_fragment_coordinates_, spv::DecorationBuiltIn,
                            spv::BuiltInFragCoord);
    main_interface_.push_back(input_fragment_coordinates_);
  }

  // Is front facing.
  if (edram_fragment_shader_interlock_ ||
      (param_gen_needed && !GetSpirvShaderModification().pixel.param_gen_point)) {
    input_front_facing_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassInput,
                                                   type_bool_, "gl_FrontFacing");
    builder_->addDecoration(input_front_facing_, spv::DecorationBuiltIn, spv::BuiltInFrontFacing);
    main_interface_.push_back(input_front_facing_);
  }

  // Sample mask input.
  if (edram_fragment_shader_interlock_ || IsSampleRate() ||
      (alpha_to_coverage_possible && features_.sample_rate_shading)) {
    // SampleMask depends on SampleRateShading in some SPIR-V revisions.
    builder_->addCapability(spv::CapabilitySampleRateShading);
  }
  if (IsSampleRate()) {
    input_sample_id_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassInput, type_int_,
                                                "gl_SampleID");
    builder_->addDecoration(input_sample_id_, spv::DecorationFlat);
    builder_->addDecoration(input_sample_id_, spv::DecorationBuiltIn, spv::BuiltInSampleId);
    main_interface_.push_back(input_sample_id_);
  }
  if (edram_fragment_shader_interlock_) {
    input_sample_mask_ = builder_->createVariable(
        spv::NoPrecision, spv::StorageClassInput,
        builder_->makeArrayType(type_int_, builder_->makeUintConstant(1), 0), "gl_SampleMaskIn");
    builder_->addDecoration(input_sample_mask_, spv::DecorationFlat);
    builder_->addDecoration(input_sample_mask_, spv::DecorationBuiltIn, spv::BuiltInSampleMask);
    main_interface_.push_back(input_sample_mask_);
  }

  if (!edram_fragment_shader_interlock_) {
    // Framebuffer color attachment outputs.
    std::fill(output_or_var_fragment_data_.begin(), output_or_var_fragment_data_.end(),
              spv::NoResult);
    if (!is_depth_only_fragment_shader_) {
      static const char* const kFragmentDataOutputNames[] = {
          "xe_out_fragment_data_0",
          "xe_out_fragment_data_1",
          "xe_out_fragment_data_2",
          "xe_out_fragment_data_3",
      };
      uint32_t color_targets_remaining = current_shader().writes_color_targets();
      uint32_t color_target_index;
      while (rex::bit_scan_forward(color_targets_remaining, &color_target_index)) {
        color_targets_remaining &= ~(UINT32_C(1) << color_target_index);
        spv::Id output_fragment_data_rt =
            builder_->createVariable(spv::NoPrecision, spv::StorageClassOutput, type_float4_,
                                     kFragmentDataOutputNames[color_target_index]);
        output_or_var_fragment_data_[color_target_index] = output_fragment_data_rt;
        builder_->addDecoration(output_fragment_data_rt, spv::DecorationLocation,
                                int(color_target_index));
        // Make invariant as pixel shaders may be used for various precise
        // computations.
        builder_->addDecoration(output_fragment_data_rt, spv::DecorationInvariant);
        main_interface_.push_back(output_fragment_data_rt);
      }
    }
    output_fragment_depth_ = spv::NoResult;
    output_fragment_sample_mask_ = spv::NoResult;
    if (current_shader().writes_depth() || float24_depth_conversion) {
      output_fragment_depth_ = builder_->createVariable(spv::NoPrecision, spv::StorageClassOutput,
                                                        type_float_, "gl_FragDepth");
      builder_->addDecoration(output_fragment_depth_, spv::DecorationBuiltIn,
                              spv::BuiltInFragDepth);
      main_interface_.push_back(output_fragment_depth_);
    }
    if (alpha_to_coverage_possible && features_.sample_rate_shading) {
      output_fragment_sample_mask_ = builder_->createVariable(
          spv::NoPrecision, spv::StorageClassOutput,
          builder_->makeArrayType(type_int_, builder_->makeUintConstant(1), 0), "gl_SampleMask");
      builder_->addDecoration(output_fragment_sample_mask_, spv::DecorationBuiltIn,
                              spv::BuiltInSampleMask);
      main_interface_.push_back(output_fragment_sample_mask_);
    }
  }
}

void SpirvShaderTranslator::StartFragmentShaderInMain() {
  // Set up pixel killing from within the translated shader without affecting
  // the control flow (unlike with OpKill), similarly to how pixel killing works
  // on the Xenos, and also keeping a single critical section exit and return
  // for safety across different Vulkan implementations with fragment shader
  // interlock.
  if (current_shader().kills_pixels()) {
    if (features_.demote_to_helper_invocation) {
      // TODO(Triang3l): Promoted to SPIR-V 1.6 - don't add the extension there.
      builder_->addExtension("SPV_EXT_demote_to_helper_invocation");
      builder_->addCapability(spv::CapabilityDemoteToHelperInvocationEXT);
    } else {
      var_main_kill_pixel_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_bool_,
                                   "xe_var_kill_pixel", builder_->makeBoolConstant(false));
    }
    // For killing with fragment shader interlock when demotion is supported,
    // using OpIsHelperInvocationEXT to avoid allocating a variable in addition
    // to the execution mask GPUs naturally have.
  }

  if (edram_fragment_shader_interlock_) {
    // Initialize color output variables with fragment shader interlock.
    std::fill(output_or_var_fragment_data_.begin(), output_or_var_fragment_data_.end(),
              spv::NoResult);
    var_main_fragment_depth_ = spv::NoResult;
    var_main_fsi_color_written_ = spv::NoResult;
    if (current_shader().writes_depth()) {
      var_main_fragment_depth_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_float_,
                                   "xe_var_fragment_depth", const_float_0_);
    }
    uint32_t color_targets_written = current_shader().writes_color_targets();
    if (color_targets_written) {
      static const char* const kFragmentDataVariableNames[] = {
          "xe_var_fragment_data_0",
          "xe_var_fragment_data_1",
          "xe_var_fragment_data_2",
          "xe_var_fragment_data_3",
      };
      uint32_t color_targets_remaining = color_targets_written;
      uint32_t color_target_index;
      while (rex::bit_scan_forward(color_targets_remaining, &color_target_index)) {
        color_targets_remaining &= ~(UINT32_C(1) << color_target_index);
        output_or_var_fragment_data_[color_target_index] = builder_->createVariable(
            spv::NoPrecision, spv::StorageClassFunction, type_float4_,
            kFragmentDataVariableNames[color_target_index], const_float4_0_);
      }
      var_main_fsi_color_written_ =
          builder_->createVariable(spv::NoPrecision, spv::StorageClassFunction, type_uint_,
                                   "xe_var_fsi_color_written", const_uint_0_);
    }
  }

  if (edram_fragment_shader_interlock_ && FSI_IsDepthStencilEarly()) {
    spv::Id msaa_samples = LoadMsaaSamplesFromFlags();
    FSI_LoadSampleMask(msaa_samples);
    FSI_LoadEdramOffsets(msaa_samples);
    builder_->createNoResultOp(spv::OpBeginInvocationInterlockEXT);
    FSI_DepthStencilTest(msaa_samples, false);
    if (!is_depth_only_fragment_shader_) {
      // Skip the rest of the shader if the whole quad (due to derivatives) has
      // failed the depth / stencil test, and there are no depth and stencil
      // values to conditionally write after running the shader to check if
      // samples don't additionally need to be discarded.
      spv::Id quad_needs_execution =
          builder_->createBinOp(spv::OpINotEqual, type_bool_, main_fsi_sample_mask_, const_uint_0_);
      // TODO(Triang3l): Use GroupNonUniformQuad operations where supported.
      // If none of the pixels in the quad passed the depth / stencil test, the
      // value of (any samples covered ? 1.0f : 0.0f) for the current pixel will
      // be 0.0f, and since it will be 0.0f in other pixels too, the derivatives
      // will be zero as well.
      builder_->addCapability(spv::CapabilityDerivativeControl);
      // Query the horizontally adjacent pixel.
      quad_needs_execution = builder_->createBinOp(
          spv::OpLogicalOr, type_bool_, quad_needs_execution,
          builder_->createBinOp(
              spv::OpFOrdNotEqual, type_bool_,
              builder_->createUnaryOp(
                  spv::OpDPdxFine, type_float_,
                  builder_->createTriOp(spv::OpSelect, type_float_, quad_needs_execution,
                                        const_float_1_, const_float_0_)),
              const_float_0_));
      // Query the vertically adjacent pair of pixels.
      quad_needs_execution = builder_->createBinOp(
          spv::OpLogicalOr, type_bool_, quad_needs_execution,
          builder_->createBinOp(
              spv::OpFOrdNotEqual, type_bool_,
              builder_->createUnaryOp(
                  spv::OpDPdyCoarse, type_float_,
                  builder_->createTriOp(spv::OpSelect, type_float_, quad_needs_execution,
                                        const_float_1_, const_float_0_)),
              const_float_0_));
      spv::Block& main_fsi_early_depth_stencil_execute_quad = builder_->makeNewBlock();
      main_fsi_early_depth_stencil_execute_quad_merge_ = &builder_->makeNewBlock();
      builder_->createSelectionMerge(main_fsi_early_depth_stencil_execute_quad_merge_,
                                     spv::SelectionControlDontFlattenMask);
      builder_->createConditionalBranch(quad_needs_execution,
                                        &main_fsi_early_depth_stencil_execute_quad,
                                        main_fsi_early_depth_stencil_execute_quad_merge_);
      builder_->setBuildPoint(&main_fsi_early_depth_stencil_execute_quad);
    }
  }

  if (is_depth_only_fragment_shader_) {
    return;
  }

  if (current_shader().memexport_eM_written()) {
    // Make sure memexport is done only once for a guest pixel.
    uint32_t resolution_scaled_axes =
        uint32_t(draw_resolution_scale_x_ > 1) | (uint32_t(draw_resolution_scale_y_ > 1) << 1);
    if (resolution_scaled_axes) {
      assert_true(input_fragment_coordinates_ != spv::NoResult);
      spv::Id memexport_allowed = spv::NoResult;
      for (uint32_t i = 0; i < 2; ++i) {
        if (!(resolution_scaled_axes & (UINT32_C(1) << i))) {
          continue;
        }
        id_vector_temp_.clear();
        id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
        spv::Id position = builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassInput, input_fragment_coordinates_,
                                        id_vector_temp_),
            spv::NoPrecision);
        spv::Id position_mod = builder_->createBinOp(
            spv::OpUMod, type_uint_,
            builder_->createUnaryOp(spv::OpConvertFToU, type_uint_, position),
            builder_->makeUintConstant(i ? draw_resolution_scale_y_ : draw_resolution_scale_x_));
        spv::Id position_is_center =
            builder_->createBinOp(spv::OpIEqual, type_bool_, position_mod,
                                  builder_->makeUintConstant(i ? (draw_resolution_scale_y_ >> 1)
                                                               : (draw_resolution_scale_x_ >> 1)));
        memexport_allowed = memexport_allowed != spv::NoResult
                                ? builder_->createBinOp(spv::OpLogicalAnd, type_bool_,
                                                        memexport_allowed, position_is_center)
                                : position_is_center;
      }
      assert_true(memexport_allowed != spv::NoResult);
      main_memexport_allowed_ =
          main_memexport_allowed_ != spv::NoResult
              ? builder_->createBinOp(spv::OpLogicalAnd, type_bool_, main_memexport_allowed_,
                                      memexport_allowed)
              : memexport_allowed;
    }
    if (IsSampleRate()) {
      assert_true(input_sample_id_ != spv::NoResult);
      spv::Id sample_id = builder_->createUnaryOp(
          spv::OpBitcast, type_uint_, builder_->createLoad(input_sample_id_, spv::NoPrecision));
      spv::Id msaa_samples = LoadMsaaSamplesFromFlags();
      spv::Id preferred_sample = builder_->createTriOp(
          spv::OpSelect, type_uint_,
          builder_->createBinOp(spv::OpUGreaterThanEqual, type_bool_, msaa_samples,
                                builder_->makeUintConstant(uint32_t(xenos::MsaaSamples::k4X))),
          builder_->makeUintConstant(3),
          builder_->createTriOp(
              spv::OpSelect, type_uint_,
              builder_->createBinOp(spv::OpUGreaterThanEqual, type_bool_, msaa_samples,
                                    builder_->makeUintConstant(uint32_t(xenos::MsaaSamples::k2X))),
              builder_->makeUintConstant(native_2x_msaa_with_attachments_ ? 1u : 3u),
              const_uint_0_));
      // gl_SampleMaskIn on Vulkan may not include coverage bits for other
      // sample invocations, unlike Direct3D SV_Coverage - use the sample
      // that's the most friendly to the half-pixel offset.
      spv::Id sample_preferred =
          builder_->createBinOp(spv::OpIEqual, type_bool_, sample_id, preferred_sample);
      main_memexport_allowed_ =
          main_memexport_allowed_ != spv::NoResult
              ? builder_->createBinOp(spv::OpLogicalAnd, type_bool_, main_memexport_allowed_,
                                      sample_preferred)
              : sample_preferred;
    }
  }

  uint32_t param_gen_interpolator = GetPsParamGenInterpolator();

  // Zero general-purpose registers to prevent crashes when the game
  // references them after only initializing them conditionally, and copy
  // interpolants to GPRs.
  uint32_t interpolator_mask = GetModificationInterpolatorMask();
  for (uint32_t i = 0; i < register_count(); ++i) {
    if (i == param_gen_interpolator) {
      continue;
    }
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeIntConstant(int(i)));
    builder_->createStore(
        (i < xenos::kMaxInterpolators && (interpolator_mask & (UINT32_C(1) << i)))
            ? builder_->createLoad(input_output_interpolators_[i], spv::NoPrecision)
            : const_float4_0_,
        builder_->createAccessChain(spv::StorageClassFunction, var_main_registers_,
                                    id_vector_temp_));
  }

  // Pixel parameters.
  if (param_gen_interpolator != UINT32_MAX) {
    Modification modification = GetSpirvShaderModification();
    // Rounding the position down, and taking the absolute value, so in case the
    // host GPU for some reason has quads used for derivative calculation at odd
    // locations, the left and top edges will have correct derivative magnitude
    // and LODs.
    // Assuming that if PsParamGen is needed at all, param_gen_point is always
    // set for point primitives, and is always disabled for other primitive
    // types.
    // OpFNegate requires sign bit flipping even for 0.0 (in this case, the
    // first column or row of pixels) only since SPIR-V 1.5 revision 2 (not the
    // base 1.5).
    // TODO(Triang3l): When SPIR-V 1.6 is used in Xenia, see if OpFNegate can be
    // used there, should be cheaper because it may be implemented as a hardware
    // instruction modifier, though it respects the rule for subnormal numbers -
    // see the actual hardware instructions in both OpBitwiseXor and OpFNegate
    // cases.
    spv::Id const_sign_bit = builder_->makeUintConstant(UINT32_C(1) << 31);
    // X - pixel X .0 in the magnitude, is back-facing in the sign bit.
    assert_true(input_fragment_coordinates_ != spv::NoResult);
    id_vector_temp_.clear();
    id_vector_temp_.push_back(const_int_0_);
    spv::Id param_gen_x = builder_->createUnaryBuiltinCall(
        type_float_, ext_inst_glsl_std_450_, GLSLstd450Floor,
        builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassInput, input_fragment_coordinates_,
                                        id_vector_temp_),
            spv::NoPrecision));
    if (draw_resolution_scale_x_ > 1) {
      param_gen_x = builder_->createNoContractionBinOp(
          spv::OpFMul, type_float_, param_gen_x,
          builder_->makeFloatConstant(1.0f / float(draw_resolution_scale_x_)));
    }
    param_gen_x = builder_->createUnaryBuiltinCall(type_float_, ext_inst_glsl_std_450_,
                                                   GLSLstd450FAbs, param_gen_x);
    if (!modification.pixel.param_gen_point) {
      assert_true(input_front_facing_ != spv::NoResult);
      param_gen_x = builder_->createTriOp(
          spv::OpSelect, type_float_,
          builder_->createBinOp(
              spv::OpLogicalOr, type_bool_,
              builder_->createBinOp(
                  spv::OpIEqual, type_bool_,
                  builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                        builder_->makeUintConstant(kSysFlag_PrimitivePolygonal)),
                  const_uint_0_),
              builder_->createLoad(input_front_facing_, spv::NoPrecision)),
          param_gen_x,
          builder_->createUnaryOp(
              spv::OpBitcast, type_float_,
              builder_->createBinOp(
                  spv::OpBitwiseXor, type_uint_,
                  builder_->createUnaryOp(spv::OpBitcast, type_uint_, param_gen_x),
                  const_sign_bit)));
    }
    // Y - pixel Y .0 in the magnitude, is point in the sign bit.
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeIntConstant(1));
    spv::Id param_gen_y = builder_->createUnaryBuiltinCall(
        type_float_, ext_inst_glsl_std_450_, GLSLstd450Floor,
        builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassInput, input_fragment_coordinates_,
                                        id_vector_temp_),
            spv::NoPrecision));
    if (draw_resolution_scale_y_ > 1) {
      param_gen_y = builder_->createNoContractionBinOp(
          spv::OpFMul, type_float_, param_gen_y,
          builder_->makeFloatConstant(1.0f / float(draw_resolution_scale_y_)));
    }
    param_gen_y = builder_->createUnaryBuiltinCall(type_float_, ext_inst_glsl_std_450_,
                                                   GLSLstd450FAbs, param_gen_y);
    if (modification.pixel.param_gen_point) {
      param_gen_y = builder_->createUnaryOp(
          spv::OpBitcast, type_float_,
          builder_->createBinOp(spv::OpBitwiseXor, type_uint_,
                                builder_->createUnaryOp(spv::OpBitcast, type_uint_, param_gen_y),
                                const_sign_bit));
    }
    // Z - point S in the magnitude, is line in the sign bit.
    // W - point T in the magnitude.
    spv::Id param_gen_z, param_gen_w;
    if (modification.pixel.param_gen_point) {
      assert_true(input_point_coordinates_ != spv::NoResult);
      // Saturate to avoid negative point coordinates if the center of the pixel
      // is not covered, and extrapolation is done.
      spv::Id param_gen_point_coordinates = builder_->createTriBuiltinCall(
          type_float2_, ext_inst_glsl_std_450_, GLSLstd450NClamp,
          builder_->createLoad(input_point_coordinates_, spv::NoPrecision), const_float2_0_,
          const_float2_1_);
      param_gen_z = builder_->createCompositeExtract(param_gen_point_coordinates, type_float_, 0);
      param_gen_w = builder_->createCompositeExtract(param_gen_point_coordinates, type_float_, 1);
    } else {
      param_gen_z = builder_->createUnaryOp(
          spv::OpBitcast, type_float_,
          builder_->createTriOp(
              spv::OpSelect, type_uint_,
              builder_->createBinOp(
                  spv::OpINotEqual, type_bool_,
                  builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, main_system_constant_flags_,
                                        builder_->makeUintConstant(kSysFlag_PrimitiveLine)),
                  const_uint_0_),
              const_sign_bit, const_uint_0_));
      param_gen_w = const_float_0_;
    }
    // Store the pixel parameters.
    id_vector_temp_.clear();
    id_vector_temp_.push_back(param_gen_x);
    id_vector_temp_.push_back(param_gen_y);
    id_vector_temp_.push_back(param_gen_z);
    id_vector_temp_.push_back(param_gen_w);
    spv::Id param_gen = builder_->createCompositeConstruct(type_float4_, id_vector_temp_);
    id_vector_temp_.clear();
    id_vector_temp_.push_back(builder_->makeIntConstant(int(param_gen_interpolator)));
    builder_->createStore(
        param_gen, builder_->createAccessChain(spv::StorageClassFunction, var_main_registers_,
                                               id_vector_temp_));
  }

  if (!edram_fragment_shader_interlock_) {
    // Initialize the colors for safety.
    for (uint32_t i = 0; i < xenos::kMaxColorRenderTargets; ++i) {
      spv::Id output_fragment_data_rt = output_or_var_fragment_data_[i];
      if (output_fragment_data_rt != spv::NoResult) {
        builder_->createStore(const_float4_0_, output_fragment_data_rt);
      }
    }
    if (output_fragment_depth_ != spv::NoResult) {
      // Keep output deterministic if oDepth is not written on a control flow
      // path.
      builder_->createStore(const_float_0_, output_fragment_depth_);
    }
  }
}

void SpirvShaderTranslator::UpdateExecConditionals(ParsedExecInstruction::Type type,
                                                   uint32_t bool_constant_index, bool condition) {
  // Check if we can merge the new exec with the previous one, or the jump with
  // the previous exec. The instruction-level predicate check is also merged in
  // this case.
  if (type == ParsedExecInstruction::Type::kConditional) {
    // Can merge conditional with conditional, as long as the bool constant and
    // the expected values are the same.
    if (cf_exec_conditional_merge_ && cf_exec_bool_constant_or_predicate_ == bool_constant_index &&
        cf_exec_condition_ == condition) {
      return;
    }
  } else if (type == ParsedExecInstruction::Type::kPredicated) {
    // Can merge predicated with predicated if the conditions are the same and
    // the previous exec hasn't modified the predicate register.
    if (!cf_exec_predicate_written_ && cf_exec_conditional_merge_ &&
        cf_exec_bool_constant_or_predicate_ == kCfExecBoolConstantPredicate &&
        cf_exec_condition_ == condition) {
      return;
    }
  } else {
    // Can merge unconditional with unconditional.
    assert_true(type == ParsedExecInstruction::Type::kUnconditional);
    if (!cf_exec_conditional_merge_) {
      return;
    }
  }

  CloseExecConditionals();

  if (type == ParsedExecInstruction::Type::kUnconditional) {
    return;
  }

  EnsureBuildPointAvailable();
  spv::Id condition_id;
  if (type == ParsedExecInstruction::Type::kConditional) {
    id_vector_temp_.clear();
    // Bool constants (member 0).
    id_vector_temp_.push_back(const_int_0_);
    // 128-bit vector.
    id_vector_temp_.push_back(builder_->makeIntConstant(int(bool_constant_index >> 7)));
    // 32-bit scalar of a 128-bit vector.
    id_vector_temp_.push_back(builder_->makeIntConstant(int((bool_constant_index >> 5) & 3)));
    spv::Id bool_constant_scalar = builder_->createLoad(
        builder_->createAccessChain(spv::StorageClassUniform, uniform_bool_loop_constants_,
                                    id_vector_temp_),
        spv::NoPrecision);
    condition_id = builder_->createBinOp(
        spv::OpINotEqual, type_bool_,
        builder_->createBinOp(
            spv::OpBitwiseAnd, type_uint_, bool_constant_scalar,
            builder_->makeUintConstant(uint32_t(1) << (bool_constant_index & 31))),
        const_uint_0_);
    cf_exec_bool_constant_or_predicate_ = bool_constant_index;
  } else if (type == ParsedExecInstruction::Type::kPredicated) {
    condition_id = builder_->createLoad(var_main_predicate_, spv::NoPrecision);
    cf_exec_bool_constant_or_predicate_ = kCfExecBoolConstantPredicate;
  } else {
    assert_unhandled_case(type);
    return;
  }
  cf_exec_condition_ = condition;
  cf_exec_conditional_merge_ =
      new spv::Block(builder_->getUniqueId(), builder_->getBuildPoint()->getParent());
  builder_->createSelectionMerge(cf_exec_conditional_merge_, spv::SelectionControlDontFlattenMask);
  spv::Block& inner_block = builder_->makeNewBlock();
  builder_->createConditionalBranch(condition_id,
                                    condition ? &inner_block : cf_exec_conditional_merge_,
                                    condition ? cf_exec_conditional_merge_ : &inner_block);
  builder_->setBuildPoint(&inner_block);
}

void SpirvShaderTranslator::UpdateInstructionPredication(bool predicated, bool condition) {
  if (!predicated) {
    CloseInstructionPredication();
    return;
  }

  if (cf_instruction_predicate_merge_) {
    if (cf_instruction_predicate_condition_ == condition) {
      // Already in the needed instruction-level conditional.
      return;
    }
    CloseInstructionPredication();
  }

  // If the instruction predicate condition is the same as the exec predicate
  // condition, no need to open a check. However, if there was a `setp` prior
  // to this instruction, the predicate value now may be different than it was
  // in the beginning of the exec.
  if (!cf_exec_predicate_written_ && cf_exec_conditional_merge_ &&
      cf_exec_bool_constant_or_predicate_ == kCfExecBoolConstantPredicate &&
      cf_exec_condition_ == condition) {
    return;
  }

  cf_instruction_predicate_condition_ = condition;
  EnsureBuildPointAvailable();
  spv::Id predicate_id = builder_->createLoad(var_main_predicate_, spv::NoPrecision);
  spv::Block& predicated_block = builder_->makeNewBlock();
  cf_instruction_predicate_merge_ =
      new spv::Block(builder_->getUniqueId(), builder_->getBuildPoint()->getParent());
  builder_->createSelectionMerge(cf_instruction_predicate_merge_, spv::SelectionControlMaskNone);
  builder_->createConditionalBranch(
      predicate_id, condition ? &predicated_block : cf_instruction_predicate_merge_,
      condition ? cf_instruction_predicate_merge_ : &predicated_block);
  builder_->setBuildPoint(&predicated_block);
}

void SpirvShaderTranslator::CloseInstructionPredication() {
  if (!cf_instruction_predicate_merge_) {
    return;
  }
  spv::Block& inner_block = *builder_->getBuildPoint();
  if (!inner_block.isTerminated()) {
    builder_->createBranch(cf_instruction_predicate_merge_);
  }
  inner_block.getParent().addBlock(cf_instruction_predicate_merge_);
  builder_->setBuildPoint(cf_instruction_predicate_merge_);
  cf_instruction_predicate_merge_ = nullptr;
}

void SpirvShaderTranslator::CloseExecConditionals() {
  // Within the exec - instruction-level predicate check.
  CloseInstructionPredication();
  // Exec level.
  if (cf_exec_conditional_merge_) {
    spv::Block& inner_block = *builder_->getBuildPoint();
    if (!inner_block.isTerminated()) {
      builder_->createBranch(cf_exec_conditional_merge_);
    }
    inner_block.getParent().addBlock(cf_exec_conditional_merge_);
    builder_->setBuildPoint(cf_exec_conditional_merge_);
    cf_exec_conditional_merge_ = nullptr;
  }
  // Nothing relies on the predicate value being unchanged now.
  cf_exec_predicate_written_ = false;
}

spv::Id SpirvShaderTranslator::GetStorageAddressingIndex(
    InstructionStorageAddressingMode addressing_mode, uint32_t storage_index,
    bool is_float_constant) {
  const Shader::ConstantRegisterMap& constant_register_map =
      current_shader().constant_register_map();
  EnsureBuildPointAvailable();
  spv::Id base_pointer = spv::NoResult;
  switch (addressing_mode) {
    case InstructionStorageAddressingMode::kAbsolute: {
      uint32_t static_storage_index = storage_index;
      if (is_float_constant) {
        static_storage_index = constant_register_map.GetPackedFloatConstantIndex(storage_index);
        assert_true(static_storage_index != UINT32_MAX);
        if (static_storage_index == UINT32_MAX) {
          static_storage_index = 0;
        }
      }
      return builder_->makeIntConstant(int(static_storage_index));
    }
    case InstructionStorageAddressingMode::kAddressRegisterRelative:
      base_pointer = var_main_address_register_;
      break;
    case InstructionStorageAddressingMode::kLoopRelative:
      // Load X component.
      id_vector_temp_util_.clear();
      id_vector_temp_util_.push_back(const_int_0_);
      base_pointer = builder_->createAccessChain(spv::StorageClassFunction, var_main_loop_address_,
                                                 id_vector_temp_util_);
      break;
  }
  assert_true(!is_float_constant || constant_register_map.float_dynamic_addressing);
  assert_true(base_pointer != spv::NoResult);
  spv::Id index = builder_->createLoad(base_pointer, spv::NoPrecision);
  if (storage_index) {
    index = builder_->createBinOp(spv::OpIAdd, type_int_, index,
                                  builder_->makeIntConstant(int(storage_index)));
  }
  return index;
}

spv::Id SpirvShaderTranslator::LoadOperandStorage(const InstructionOperand& operand) {
  spv::Id index =
      GetStorageAddressingIndex(operand.storage_addressing_mode, operand.storage_index,
                                operand.storage_source == InstructionStorageSource::kConstantFloat);
  EnsureBuildPointAvailable();
  spv::Id vec4_pointer = spv::NoResult;
  switch (operand.storage_source) {
    case InstructionStorageSource::kRegister:
      assert_true(var_main_registers_ != spv::NoResult);
      id_vector_temp_util_.clear();
      // Array element.
      id_vector_temp_util_.push_back(index);
      vec4_pointer = builder_->createAccessChain(spv::StorageClassFunction, var_main_registers_,
                                                 id_vector_temp_util_);
      break;
    case InstructionStorageSource::kConstantFloat:
      assert_true(uniform_float_constants_ != spv::NoResult);
      id_vector_temp_util_.clear();
      // The first and the only structure member.
      id_vector_temp_util_.push_back(const_int_0_);
      // Array element.
      id_vector_temp_util_.push_back(index);
      vec4_pointer = builder_->createAccessChain(spv::StorageClassUniform, uniform_float_constants_,
                                                 id_vector_temp_util_);
      break;
    default:
      assert_unhandled_case(operand.storage_source);
  }
  assert_true(vec4_pointer != spv::NoResult);
  return builder_->createLoad(vec4_pointer, spv::NoPrecision);
}

spv::Id SpirvShaderTranslator::ApplyOperandModifiers(spv::Id operand_value,
                                                     const InstructionOperand& original_operand,
                                                     bool invert_negate, bool force_absolute) {
  spv::Id type = builder_->getTypeId(operand_value);
  assert_true(type != spv::NoType);
  if (type == spv::NoType) {
    return operand_value;
  }
  if (original_operand.is_absolute_value || force_absolute) {
    EnsureBuildPointAvailable();
    operand_value = builder_->createUnaryBuiltinCall(type, ext_inst_glsl_std_450_, GLSLstd450FAbs,
                                                     operand_value);
  }
  if (original_operand.is_negated != invert_negate) {
    EnsureBuildPointAvailable();
    operand_value = builder_->createNoContractionUnaryOp(spv::OpFNegate, type, operand_value);
  }
  return operand_value;
}

spv::Id SpirvShaderTranslator::GetUnmodifiedOperandComponents(
    spv::Id operand_storage, const InstructionOperand& original_operand, uint32_t components) {
  assert_not_zero(components);
  if (!components) {
    return spv::NoResult;
  }
  assert_true(components <= 0b1111);
  if (components == 0b1111 && original_operand.IsStandardSwizzle()) {
    return operand_storage;
  }
  EnsureBuildPointAvailable();
  uint32_t component_count = rex::bit_count(components);
  if (component_count == 1) {
    uint32_t scalar_index;
    rex::bit_scan_forward(components, &scalar_index);
    return builder_->createCompositeExtract(
        operand_storage, type_float_,
        static_cast<unsigned int>(original_operand.GetComponent(scalar_index)) -
            static_cast<unsigned int>(SwizzleSource::kX));
  }
  uint_vector_temp_util_.clear();
  uint32_t components_remaining = components;
  uint32_t component_index;
  while (rex::bit_scan_forward(components_remaining, &component_index)) {
    components_remaining &= ~(uint32_t(1) << component_index);
    uint_vector_temp_util_.push_back(
        static_cast<unsigned int>(original_operand.GetComponent(component_index)) -
        static_cast<unsigned int>(SwizzleSource::kX));
  }
  return builder_->createRvalueSwizzle(spv::NoPrecision, type_float_vectors_[component_count - 1],
                                       operand_storage, uint_vector_temp_util_);
}

void SpirvShaderTranslator::GetOperandScalarXY(spv::Id operand_storage,
                                               const InstructionOperand& original_operand,
                                               spv::Id& a_out, spv::Id& b_out, bool invert_negate,
                                               bool force_absolute) {
  spv::Id a = GetOperandComponents(operand_storage, original_operand, 0b0001, invert_negate,
                                   force_absolute);
  a_out = a;
  b_out = original_operand.GetComponent(0) != original_operand.GetComponent(1)
              ? GetOperandComponents(operand_storage, original_operand, 0b0010, invert_negate,
                                     force_absolute)
              : a;
}

spv::Id SpirvShaderTranslator::GetAbsoluteOperand(spv::Id operand_storage,
                                                  const InstructionOperand& original_operand) {
  if (original_operand.is_absolute_value && !original_operand.is_negated) {
    return operand_storage;
  }
  EnsureBuildPointAvailable();
  return builder_->createUnaryBuiltinCall(builder_->getTypeId(operand_storage),
                                          ext_inst_glsl_std_450_, GLSLstd450FAbs, operand_storage);
}

void SpirvShaderTranslator::StoreResult(const InstructionResult& result, spv::Id value,
                                        bool can_store_memexport_address) {
  uint32_t used_write_mask = result.GetUsedWriteMask();
  if (!used_write_mask) {
    return;
  }
  bool is_clamped = result.is_clamped;

  EnsureBuildPointAvailable();

  spv::Id target_pointer = spv::NoResult;
  switch (result.storage_target) {
    case InstructionStorageTarget::kNone:
      break;
    case InstructionStorageTarget::kRegister: {
      assert_true(var_main_registers_ != spv::NoResult);
      // Must call GetStorageAddressingIndex first because of
      // id_vector_temp_util_ usage in it.
      spv::Id register_index =
          GetStorageAddressingIndex(result.storage_addressing_mode, result.storage_index);
      id_vector_temp_util_.clear();
      // Array element.
      id_vector_temp_util_.push_back(register_index);
      target_pointer = builder_->createAccessChain(spv::StorageClassFunction, var_main_registers_,
                                                   id_vector_temp_util_);
    } break;
    case InstructionStorageTarget::kInterpolator: {
      assert_true(is_vertex_shader());
      target_pointer = input_output_interpolators_[result.storage_index];
      // Unused interpolators are spv::NoResult in input_output_interpolators_.
    } break;
    case InstructionStorageTarget::kPosition: {
      assert_true(is_vertex_shader());
      id_vector_temp_util_.clear();
      id_vector_temp_util_.push_back(builder_->makeIntConstant(kOutputPerVertexMemberPosition));
      target_pointer = builder_->createAccessChain(spv::StorageClassOutput, output_per_vertex_,
                                                   id_vector_temp_util_);
    } break;
    case InstructionStorageTarget::kPointSizeEdgeFlagKillVertex: {
      assert_true(is_vertex_shader());
      assert_zero(used_write_mask & 0b1000);
      target_pointer = var_main_point_size_edge_flag_kill_vertex_;
    } break;
    case InstructionStorageTarget::kColor: {
      assert_true(is_pixel_shader());
      assert_not_zero(used_write_mask);
      assert_true(current_shader().writes_color_target(result.storage_index));
      target_pointer = output_or_var_fragment_data_[result.storage_index];
      if (edram_fragment_shader_interlock_) {
        assert_true(var_main_fsi_color_written_ != spv::NoResult);
        builder_->createStore(
            builder_->createBinOp(
                spv::OpBitwiseOr, type_uint_,
                builder_->createLoad(var_main_fsi_color_written_, spv::NoPrecision),
                builder_->makeUintConstant(uint32_t(1) << result.storage_index)),
            var_main_fsi_color_written_);
      }
    } break;
    case InstructionStorageTarget::kDepth: {
      assert_true(is_pixel_shader());
      // Writes X to scalar gl_FragDepth.
      assert_true(used_write_mask == 0b0001);
      assert_true(current_shader().writes_depth());
      target_pointer =
          edram_fragment_shader_interlock_ ? var_main_fragment_depth_ : output_fragment_depth_;
      // Guest depth output is expected to be [0, 1].
      is_clamped = true;
    } break;
    case InstructionStorageTarget::kExportAddress: {
      if (!can_store_memexport_address) {
        return;
      }
      if (!current_shader().memexport_eM_written()) {
        return;
      }
      // spv::NoResult if memory export usage is unsupported or invalid.
      target_pointer = var_main_memexport_address_;
    } break;
    case InstructionStorageTarget::kExportData: {
      assert_not_zero(current_shader().memexport_eM_written() &
                      (uint8_t(1) << result.storage_index));
      // spv::NoResult if memory export usage is unsupported or invalid.
      target_pointer = var_main_memexport_data_[result.storage_index];
      if (target_pointer != spv::NoResult) {
        // Mark that the eM# has been written to and needs to be exported.
        assert_true(var_main_memexport_data_written_ != spv::NoResult);
        builder_->createStore(
            builder_->createBinOp(
                spv::OpBitwiseOr, type_uint_,
                builder_->createLoad(var_main_memexport_data_written_, spv::NoPrecision),
                builder_->makeUintConstant(uint32_t(1) << result.storage_index)),
            var_main_memexport_data_written_);
      }
    } break;
    default:
      assert_unhandled_case(result.storage_target);
      return;
  }
  if (target_pointer == spv::NoResult) {
    return;
  }

  uint32_t constant_values;
  uint32_t constant_components = result.GetUsedConstantComponents(constant_values);
  if (value == spv::NoResult) {
    // The instruction processing function decided that nothing useful needs to
    // be stored for some reason, however, some components still need to be
    // written on the guest side - fill them with zeros.
    constant_components = used_write_mask;
  }
  uint32_t non_constant_components = used_write_mask & ~constant_components;

  unsigned int value_num_components =
      value != spv::NoResult ? static_cast<unsigned int>(builder_->getNumComponents(value)) : 0;

  if (is_clamped && non_constant_components) {
    // Apply the saturation modifier to the result.
    value = builder_->createTriBuiltinCall(type_float_vectors_[value_num_components - 1],
                                           ext_inst_glsl_std_450_, GLSLstd450NClamp, value,
                                           const_float_vectors_0_[value_num_components - 1],
                                           const_float_vectors_1_[value_num_components - 1]);
  }

  // The value contains either result.GetUsedResultComponents() in a condensed
  // way, or a scalar to be replicated. Decompress them to create a mapping from
  // guest result components to the ones in the value vector.
  uint32_t used_result_components = result.GetUsedResultComponents();
  unsigned int result_unswizzled_value_components[4] = {};
  if (value_num_components > 1) {
    unsigned int value_component = 0;
    uint32_t used_result_components_remaining = used_result_components;
    uint32_t result_component;
    while (rex::bit_scan_forward(used_result_components_remaining, &result_component)) {
      used_result_components_remaining &= ~(uint32_t(1) << result_component);
      result_unswizzled_value_components[result_component] =
          std::min(value_component++, value_num_components - 1);
    }
  }

  // Get swizzled mapping of non-constant components to the components of
  // `value`.
  unsigned int result_swizzled_value_components[4] = {};
  for (uint32_t i = 0; i < 4; ++i) {
    if (!(non_constant_components & (1 << i))) {
      continue;
    }
    SwizzleSource swizzle = result.components[i];
    assert_true(swizzle >= SwizzleSource::kX && swizzle <= SwizzleSource::kW);
    result_swizzled_value_components[i] =
        result_unswizzled_value_components[uint32_t(swizzle) - uint32_t(SwizzleSource::kX)];
  }

  spv::Id target_type = builder_->getDerefTypeId(target_pointer);
  unsigned int target_num_components = builder_->getNumTypeComponents(target_type);
  assert_true(target_num_components ==
              GetInstructionStorageTargetUsedComponentCount(result.storage_target));
  uint32_t target_component_mask = (1 << target_num_components) - 1;
  assert_zero(used_write_mask & ~target_component_mask);

  spv::Id value_to_store;
  if (target_component_mask == used_write_mask) {
    // All components are overwritten - no need to load the original value.
    // Possible cases:
    // * Non-constants only.
    //   * Vector target.
    //     * Vector source.
    //       * Identity swizzle - store directly.
    //       * Non-identity swizzle - shuffle.
    //     * Scalar source - smear.
    //   * Scalar target.
    //     * Vector source - extract.
    //     * Scalar source - store directly.
    // * Constants only.
    //   * Vector target - make composite constant.
    //   * Scalar target - store directly.
    // * Mixed non-constants and constants (only for vector targets - scalar
    //   targets fully covered by the previous cases).
    //   * Vector source - shuffle with {0, 1} also applying swizzle.
    //   * Scalar source - construct composite.
    if (!constant_components) {
      if (target_num_components > 1) {
        if (value_num_components > 1) {
          // Non-constants only - vector target, vector source.
          bool is_identity_swizzle = target_num_components == value_num_components;
          for (uint32_t i = 0; is_identity_swizzle && i < target_num_components; ++i) {
            is_identity_swizzle &= result_swizzled_value_components[i] == i;
          }
          if (is_identity_swizzle) {
            value_to_store = value;
          } else {
            uint_vector_temp_util_.clear();
            uint_vector_temp_util_.insert(uint_vector_temp_util_.cend(),
                                          result_swizzled_value_components,
                                          result_swizzled_value_components + target_num_components);
            value_to_store = builder_->createRvalueSwizzle(spv::NoPrecision, target_type, value,
                                                           uint_vector_temp_util_);
          }
        } else {
          // Non-constants only - vector target, scalar source.
          value_to_store = builder_->smearScalar(spv::NoPrecision, value, target_type);
        }
      } else {
        if (value_num_components > 1) {
          // Non-constants only - scalar target, vector source.
          value_to_store = builder_->createCompositeExtract(value, type_float_,
                                                            result_swizzled_value_components[0]);
        } else {
          // Non-constants only - scalar target, scalar source.
          value_to_store = value;
        }
      }
    } else if (!non_constant_components) {
      if (target_num_components > 1) {
        // Constants only - vector target.
        id_vector_temp_util_.clear();
        for (uint32_t i = 0; i < target_num_components; ++i) {
          id_vector_temp_util_.push_back((constant_values & (1 << i)) ? const_float_1_
                                                                      : const_float_0_);
        }
        value_to_store = builder_->makeCompositeConstant(target_type, id_vector_temp_util_);
      } else {
        // Constants only - scalar target.
        value_to_store = (constant_values & 0b0001) ? const_float_1_ : const_float_0_;
      }
    } else {
      assert_true(target_num_components > 1);
      if (value_num_components > 1) {
        // Mixed non-constants and constants - vector source.
        std::unique_ptr<spv::Instruction> shuffle_op = std::make_unique<spv::Instruction>(
            builder_->getUniqueId(), target_type, spv::OpVectorShuffle);
        shuffle_op->addIdOperand(value);
        shuffle_op->addIdOperand(const_float2_0_1_);
        for (uint32_t i = 0; i < target_num_components; ++i) {
          shuffle_op->addImmediateOperand((constant_components & (1 << i))
                                              ? value_num_components + ((constant_values >> i) & 1)
                                              : result_swizzled_value_components[i]);
        }
        value_to_store = shuffle_op->getResultId();
        builder_->getBuildPoint()->addInstruction(std::move(shuffle_op));
      } else {
        // Mixed non-constants and constants - scalar source.
        id_vector_temp_util_.clear();
        for (uint32_t i = 0; i < target_num_components; ++i) {
          if (constant_components & (1 << i)) {
            id_vector_temp_util_.push_back((constant_values & (1 << i)) ? const_float_1_
                                                                        : const_float_0_);
          } else {
            id_vector_temp_util_.push_back(value);
          }
        }
        value_to_store = builder_->createCompositeConstruct(target_type, id_vector_temp_util_);
      }
    }
  } else {
    // Only certain components are overwritten.
    // Scalar targets are always overwritten fully, can't reach this case for
    // them.
    assert_true(target_num_components > 1);
    value_to_store = builder_->createLoad(target_pointer, spv::NoPrecision);
    // Two steps:
    // 1) Insert constants by shuffling (first so dependency chain of step 2 is
    //    simpler if constants are written first).
    // 2) Insert value components - via shuffling for vector source, via
    //    composite inserts for scalar value.
    if (constant_components) {
      std::unique_ptr<spv::Instruction> shuffle_op = std::make_unique<spv::Instruction>(
          builder_->getUniqueId(), target_type, spv::OpVectorShuffle);
      shuffle_op->addIdOperand(value_to_store);
      shuffle_op->addIdOperand(const_float2_0_1_);
      for (uint32_t i = 0; i < target_num_components; ++i) {
        shuffle_op->addImmediateOperand((constant_components & (1 << i))
                                            ? target_num_components + ((constant_values >> i) & 1)
                                            : i);
      }
      value_to_store = shuffle_op->getResultId();
      builder_->getBuildPoint()->addInstruction(std::move(shuffle_op));
    }
    if (non_constant_components) {
      if (value_num_components > 1) {
        std::unique_ptr<spv::Instruction> shuffle_op = std::make_unique<spv::Instruction>(
            builder_->getUniqueId(), target_type, spv::OpVectorShuffle);
        shuffle_op->addIdOperand(value_to_store);
        shuffle_op->addIdOperand(value);
        for (uint32_t i = 0; i < target_num_components; ++i) {
          shuffle_op->addImmediateOperand((non_constant_components & (1 << i))
                                              ? target_num_components +
                                                    result_swizzled_value_components[i]
                                              : i);
        }
        value_to_store = shuffle_op->getResultId();
        builder_->getBuildPoint()->addInstruction(std::move(shuffle_op));
      } else {
        for (uint32_t i = 0; i < target_num_components; ++i) {
          if (non_constant_components & (1 << i)) {
            value_to_store = builder_->createCompositeInsert(value, value_to_store, target_type, i);
          }
        }
      }
    }
  }

  if (result.storage_target == InstructionStorageTarget::kPointSizeEdgeFlagKillVertex &&
      used_write_mask & 0b001) {
    // Make the point size non-negative as negative is used to indicate that the
    // default size must be used, and also clamp it to the bounds the way the
    // R400 (Adreno 200, to be more precise) hardware clamps it (functionally
    // like a signed 32-bit integer, -NaN and -Infinity...-0 to the minimum,
    // +NaN to the maximum).
    spv::Id point_size =
        builder_->createUnaryOp(spv::OpBitcast, type_int_,
                                builder_->createCompositeExtract(value_to_store, type_float_, 0));
    id_vector_temp_util_.clear();
    id_vector_temp_util_.push_back(
        builder_->makeIntConstant(kSystemConstantPointVertexDiameterMin));
    spv::Id point_vertex_diameter_min = builder_->createUnaryOp(
        spv::OpBitcast, type_int_,
        builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                        id_vector_temp_util_),
            spv::NoPrecision));
    point_size = builder_->createBinBuiltinCall(type_int_, ext_inst_glsl_std_450_, GLSLstd450SMax,
                                                point_vertex_diameter_min, point_size);
    id_vector_temp_util_.clear();
    id_vector_temp_util_.push_back(
        builder_->makeIntConstant(kSystemConstantPointVertexDiameterMax));
    spv::Id point_vertex_diameter_max = builder_->createUnaryOp(
        spv::OpBitcast, type_int_,
        builder_->createLoad(
            builder_->createAccessChain(spv::StorageClassUniform, uniform_system_constants_,
                                        id_vector_temp_util_),
            spv::NoPrecision));
    point_size = builder_->createBinBuiltinCall(type_int_, ext_inst_glsl_std_450_, GLSLstd450SMin,
                                                point_vertex_diameter_max, point_size);
    value_to_store = builder_->createCompositeInsert(
        builder_->createUnaryOp(spv::OpBitcast, type_float_, point_size), value_to_store,
        type_float3_, 0);
  }

  builder_->createStore(value_to_store, target_pointer);
}

spv::Id SpirvShaderTranslator::EndianSwap32Uint(spv::Id value, spv::Id endian) {
  spv::Id type = builder_->getTypeId(value);
  spv::Id const_uint_8_scalar = builder_->makeUintConstant(8);
  spv::Id const_uint_00ff00ff_scalar = builder_->makeUintConstant(0x00FF00FF);
  spv::Id const_uint_16_scalar = builder_->makeUintConstant(16);
  spv::Id const_uint_8_typed, const_uint_00ff00ff_typed, const_uint_16_typed;
  int num_components = builder_->getNumTypeComponents(type);
  if (num_components > 1) {
    id_vector_temp_.clear();
    id_vector_temp_.insert(id_vector_temp_.cend(), num_components, const_uint_8_scalar);
    const_uint_8_typed = builder_->makeCompositeConstant(type, id_vector_temp_);
    id_vector_temp_.clear();
    id_vector_temp_.insert(id_vector_temp_.cend(), num_components, const_uint_00ff00ff_scalar);
    const_uint_00ff00ff_typed = builder_->makeCompositeConstant(type, id_vector_temp_);
    id_vector_temp_.clear();
    id_vector_temp_.insert(id_vector_temp_.cend(), num_components, const_uint_16_scalar);
    const_uint_16_typed = builder_->makeCompositeConstant(type, id_vector_temp_);
  } else {
    const_uint_8_typed = const_uint_8_scalar;
    const_uint_00ff00ff_typed = const_uint_00ff00ff_scalar;
    const_uint_16_typed = const_uint_16_scalar;
  }

  // 8-in-16 or one half of 8-in-32 (doing 8-in-16 swap).
  spv::Id is_8in16 = builder_->createBinOp(
      spv::OpIEqual, type_bool_, endian,
      builder_->makeUintConstant(static_cast<unsigned int>(xenos::Endian::k8in16)));
  spv::Id is_8in32 = builder_->createBinOp(
      spv::OpIEqual, type_bool_, endian,
      builder_->makeUintConstant(static_cast<unsigned int>(xenos::Endian::k8in32)));
  spv::Id is_8in16_or_8in32 =
      builder_->createBinOp(spv::OpLogicalOr, type_bool_, is_8in16, is_8in32);
  SpirvBuilder::IfBuilder if_8in16(is_8in16_or_8in32, spv::SelectionControlMaskNone, *builder_);
  spv::Id swapped_8in16;
  {
    swapped_8in16 = builder_->createBinOp(
        spv::OpBitwiseOr, type,
        builder_->createBinOp(
            spv::OpBitwiseAnd, type,
            builder_->createBinOp(spv::OpShiftRightLogical, type, value, const_uint_8_typed),
            const_uint_00ff00ff_typed),
        builder_->createBinOp(
            spv::OpShiftLeftLogical, type,
            builder_->createBinOp(spv::OpBitwiseAnd, type, value, const_uint_00ff00ff_typed),
            const_uint_8_typed));
  }
  if_8in16.makeEndIf();
  value = if_8in16.createMergePhi(swapped_8in16, value);

  // 16-in-32 or another half of 8-in-32 (doing 16-in-32 swap).
  spv::Id is_16in32 = builder_->createBinOp(
      spv::OpIEqual, type_bool_, endian,
      builder_->makeUintConstant(static_cast<unsigned int>(xenos::Endian::k16in32)));
  spv::Id is_8in32_or_16in32 =
      builder_->createBinOp(spv::OpLogicalOr, type_bool_, is_8in32, is_16in32);
  SpirvBuilder::IfBuilder if_16in32(is_8in32_or_16in32, spv::SelectionControlMaskNone, *builder_);
  spv::Id swapped_16in32;
  {
    swapped_16in32 = builder_->createQuadOp(
        spv::OpBitFieldInsert, type,
        builder_->createBinOp(spv::OpShiftRightLogical, type, value, const_uint_16_typed), value,
        builder_->makeIntConstant(16), builder_->makeIntConstant(16));
  }
  if_16in32.makeEndIf();
  value = if_16in32.createMergePhi(swapped_16in32, value);

  return value;
}

spv::Id SpirvShaderTranslator::EndianSwap128Uint4(spv::Id value, spv::Id endian) {
  // Change 8-in-64 and 8-in-128 to 8-in-32, and then swap within 32 bits.

  spv::Id is_8in64 = builder_->createBinOp(
      spv::OpIEqual, type_bool_, endian,
      builder_->makeUintConstant(static_cast<unsigned int>(xenos::Endian128::k8in64)));
  uint_vector_temp_.clear();
  uint_vector_temp_.push_back(1);
  uint_vector_temp_.push_back(0);
  uint_vector_temp_.push_back(3);
  uint_vector_temp_.push_back(2);
  value = builder_->createTriOp(
      spv::OpSelect, type_uint4_, is_8in64,
      builder_->createRvalueSwizzle(spv::NoPrecision, type_uint4_, value, uint_vector_temp_),
      value);

  spv::Id is_8in128 = builder_->createBinOp(
      spv::OpIEqual, type_bool_, endian,
      builder_->makeUintConstant(static_cast<unsigned int>(xenos::Endian128::k8in128)));
  uint_vector_temp_.clear();
  uint_vector_temp_.push_back(3);
  uint_vector_temp_.push_back(2);
  uint_vector_temp_.push_back(1);
  uint_vector_temp_.push_back(0);
  value = builder_->createTriOp(
      spv::OpSelect, type_uint4_, is_8in128,
      builder_->createRvalueSwizzle(spv::NoPrecision, type_uint4_, value, uint_vector_temp_),
      value);

  endian = builder_->createTriOp(
      spv::OpSelect, type_uint_,
      builder_->createBinOp(spv::OpLogicalOr, type_bool_, is_8in64, is_8in128),
      builder_->makeUintConstant(static_cast<unsigned int>(xenos::Endian128::k8in32)), endian);

  return EndianSwap32Uint(value, endian);
}

spv::Id SpirvShaderTranslator::LoadUint32FromSharedMemory(spv::Id address_dwords_int) {
  spv::StorageClass storage_class = features_.spirv_version >= spv::Spv_1_3
                                        ? spv::StorageClassStorageBuffer
                                        : spv::StorageClassUniform;

  if (features_.shared_memory_texel_buffer) {
    // One fetch, no branches: the storage buffer switch below serializes the
    // loads of every word (four dependent fetches on Turnip).
    spv::Id image = builder_->createLoad(texel_buffer_shared_memory_, spv::NoPrecision);
    SpirvBuilder::TextureParameters fetch_parameters = {};
    fetch_parameters.sampler = image;
    fetch_parameters.coords = address_dwords_int;
    return builder_->createCompositeExtract(
        builder_->createTextureCall(spv::NoPrecision, type_uint4_, false, true, false, false,
                                    false, fetch_parameters, spv::ImageOperandsMaskNone),
        type_uint_, 0);
  }

  uint32_t binding_count_log2 = GetSharedMemoryStorageBufferCountLog2();

  if (!binding_count_log2) {
    // Single binding - load directly.
    id_vector_temp_.clear();
    // The only SSBO struct member.
    id_vector_temp_.push_back(const_int_0_);
    id_vector_temp_.push_back(address_dwords_int);
    return builder_->createLoad(
        builder_->createAccessChain(storage_class, buffers_shared_memory_, id_vector_temp_),
        spv::NoPrecision);
  }

  // The memory is split into multiple bindings - check which binding to load
  // from. 29 is log2(512 MB), but addressing in dwords (4 B). Not indexing the
  // array with the variable itself because it needs non-uniform storage buffer
  // indexing.

  uint32_t binding_address_bits = (29 - 2) - binding_count_log2;
  spv::Id binding_index =
      builder_->createBinOp(spv::OpShiftRightLogical, type_uint_,
                            builder_->createUnaryOp(spv::OpBitcast, type_uint_, address_dwords_int),
                            builder_->makeUintConstant(binding_address_bits));
  spv::Id binding_address = builder_->createBinOp(
      spv::OpBitwiseAnd, type_int_, address_dwords_int,
      builder_->makeIntConstant(int((uint32_t(1) << binding_address_bits) - 1)));

  auto value_phi_op =
      std::make_unique<spv::Instruction>(builder_->getUniqueId(), type_uint_, spv::OpPhi);
  // Zero if out of bounds.
  value_phi_op->addIdOperand(const_uint_0_);
  value_phi_op->addIdOperand(builder_->getBuildPoint()->getId());

  SpirvBuilder::SwitchBuilder binding_switch(binding_index, spv::SelectionControlDontFlattenMask,
                                             *builder_);
  uint32_t binding_count = uint32_t(1) << binding_count_log2;

  id_vector_temp_.clear();
  id_vector_temp_.push_back(spv::NoResult);
  // The only SSBO struct member.
  id_vector_temp_.push_back(const_int_0_);
  id_vector_temp_.push_back(binding_address);

  for (uint32_t i = 0; i < binding_count; ++i) {
    binding_switch.makeBeginCase(i);
    id_vector_temp_[0] = builder_->makeIntConstant(int(i));
    value_phi_op->addIdOperand(builder_->createLoad(
        builder_->createAccessChain(storage_class, buffers_shared_memory_, id_vector_temp_),
        spv::NoPrecision));
    value_phi_op->addIdOperand(builder_->getBuildPoint()->getId());
  }

  binding_switch.makeEndSwitch();

  spv::Id value_phi_result = value_phi_op->getResultId();
  builder_->getBuildPoint()->addInstruction(std::move(value_phi_op));
  return value_phi_result;
}

void SpirvShaderTranslator::StoreUint32ToSharedMemory(spv::Id value, spv::Id address_dwords_int,
                                                      spv::Id replace_mask) {
  spv::StorageClass storage_class = features_.spirv_version >= spv::Spv_1_3
                                        ? spv::StorageClassStorageBuffer
                                        : spv::StorageClassUniform;

  spv::Id keep_mask = spv::NoResult;
  if (replace_mask != spv::NoResult) {
    keep_mask = builder_->createUnaryOp(spv::OpNot, type_uint_, replace_mask);
    value = builder_->createBinOp(spv::OpBitwiseAnd, type_uint_, value, replace_mask);
  }

  auto store = [&](spv::Id pointer) {
    if (replace_mask != spv::NoResult) {
      // Don't touch the other bits in the buffer, just modify the needed bits
      // in the most up to date uint32 at the address.
      spv::Id const_scope_device =
          builder_->makeUintConstant(static_cast<unsigned int>(spv::ScopeDevice));
      spv::Id const_semantics_relaxed = const_uint_0_;
      builder_->createQuadOp(spv::OpAtomicAnd, type_uint_, pointer, const_scope_device,
                             const_semantics_relaxed, keep_mask);
      builder_->createQuadOp(spv::OpAtomicOr, type_uint_, pointer, const_scope_device,
                             const_semantics_relaxed, value);
    } else {
      builder_->createStore(value, pointer);
    }
  };

  uint32_t binding_count_log2 = GetSharedMemoryStorageBufferCountLog2();

  if (!binding_count_log2) {
    // Single binding - store directly.
    id_vector_temp_.clear();
    // The only SSBO struct member.
    id_vector_temp_.push_back(const_int_0_);
    id_vector_temp_.push_back(address_dwords_int);
    store(builder_->createAccessChain(storage_class, buffers_shared_memory_, id_vector_temp_));
    return;
  }

  // The memory is split into multiple bindings - check which binding to store
  // to. 29 is log2(512 MB), but addressing in dwords (4 B). Not indexing the
  // array with the variable itself because it needs non-uniform storage buffer
  // indexing.

  uint32_t binding_address_bits = (29 - 2) - binding_count_log2;
  spv::Id binding_index =
      builder_->createBinOp(spv::OpShiftRightLogical, type_uint_,
                            builder_->createUnaryOp(spv::OpBitcast, type_uint_, address_dwords_int),
                            builder_->makeUintConstant(binding_address_bits));
  spv::Id binding_address = builder_->createBinOp(
      spv::OpBitwiseAnd, type_int_, address_dwords_int,
      builder_->makeIntConstant(int((uint32_t(1) << binding_address_bits) - 1)));

  SpirvBuilder::SwitchBuilder binding_switch(binding_index, spv::SelectionControlDontFlattenMask,
                                             *builder_);
  uint32_t binding_count = uint32_t(1) << binding_count_log2;

  id_vector_temp_.clear();
  id_vector_temp_.push_back(spv::NoResult);
  // The only SSBO struct member.
  id_vector_temp_.push_back(const_int_0_);
  id_vector_temp_.push_back(binding_address);

  for (uint32_t i = 0; i < binding_count; ++i) {
    binding_switch.makeBeginCase(i);
    id_vector_temp_[0] = builder_->makeIntConstant(int(i));
    store(builder_->createAccessChain(storage_class, buffers_shared_memory_, id_vector_temp_));
  }

  binding_switch.makeEndSwitch();
}

spv::Id SpirvShaderTranslator::PWLGammaToLinear(spv::Id gamma, bool gamma_pre_saturated) {
  spv::Id value_type = builder_->getTypeId(gamma);
  assert_true(builder_->isFloatType(builder_->getScalarTypeId(value_type)));
  bool is_vector = builder_->isVectorType(value_type);
  assert_true(is_vector || builder_->isFloatType(value_type));
  int num_components = builder_->getNumTypeComponents(value_type);
  assert_true(num_components < 4);
  spv::Id bool_type = type_bool_vectors_[num_components - 1];

  spv::Id const_vector_0 = const_float_vectors_0_[num_components - 1];
  spv::Id const_vector_1 =
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(1.0f), value_type);

  if (!gamma_pre_saturated) {
    // Saturate, flushing NaN to 0.
    gamma = builder_->createTriBuiltinCall(value_type, ext_inst_glsl_std_450_, GLSLstd450NClamp,
                                           gamma, const_vector_0, const_vector_1);
  }

  spv::Id is_piece_at_least_3 = builder_->createBinOp(
      spv::OpFOrdGreaterThanEqual, bool_type, gamma,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(192.0f / 255.0f), value_type));
  spv::Id scale_3_or_2 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_3,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(8.0f / 1024.0f), value_type),
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(4.0f / 1024.0f), value_type));
  spv::Id offset_3_or_2 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_3,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(-1024.0f), value_type),
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(-256.0f), value_type));

  spv::Id is_piece_at_least_1 = builder_->createBinOp(
      spv::OpFOrdGreaterThanEqual, bool_type, gamma,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(64.0f / 255.0f), value_type));
  spv::Id scale_1_or_0 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_1,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(2.0f / 1024.0f), value_type),
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(1.0f / 1024.0f), value_type));
  spv::Id offset_1_or_0 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_1,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(-64.0f), value_type),
      const_vector_0);

  spv::Id is_piece_at_least_2 = builder_->createBinOp(
      spv::OpFOrdGreaterThanEqual, bool_type, gamma,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(96.0f / 255.0f), value_type));
  spv::Id scale = builder_->createTriOp(spv::OpSelect, value_type, is_piece_at_least_2,
                                        scale_3_or_2, scale_1_or_0);
  spv::Id offset = builder_->createTriOp(spv::OpSelect, value_type, is_piece_at_least_2,
                                         offset_3_or_2, offset_1_or_0);

  spv::Op value_times_scalar_opcode = is_vector ? spv::OpVectorTimesScalar : spv::OpFMul;
  // linear = gamma * (255.0f * 1024.0f) * scale + offset
  spv::Id linear = builder_->createNoContractionBinOp(
      spv::OpFAdd, value_type,
      builder_->createNoContractionBinOp(
          spv::OpFMul, value_type,
          builder_->createNoContractionBinOp(value_times_scalar_opcode, value_type, gamma,
                                             builder_->makeFloatConstant(255.0f * 1024.0f)),
          scale),
      offset);
  // linear += trunc(linear * scale)
  linear = builder_->createNoContractionBinOp(
      spv::OpFAdd, value_type, linear,
      builder_->createUnaryBuiltinCall(
          value_type, ext_inst_glsl_std_450_, GLSLstd450Trunc,
          builder_->createNoContractionBinOp(spv::OpFMul, value_type, linear, scale)));
  // linear *= 1.0f / 1023.0f
  linear = builder_->createNoContractionBinOp(value_times_scalar_opcode, value_type, linear,
                                              builder_->makeFloatConstant(1.0f / 1023.0f));
  return linear;
}

spv::Id SpirvShaderTranslator::LinearToPWLGamma(spv::Id linear, bool linear_pre_saturated) {
  spv::Id value_type = builder_->getTypeId(linear);
  assert_true(builder_->isFloatType(builder_->getScalarTypeId(value_type)));
  bool is_vector = builder_->isVectorType(value_type);
  assert_true(is_vector || builder_->isFloatType(value_type));
  int num_components = builder_->getNumTypeComponents(value_type);
  assert_true(num_components < 4);
  spv::Id bool_type = type_bool_vectors_[num_components - 1];

  spv::Id const_vector_0 = const_float_vectors_0_[num_components - 1];
  spv::Id const_vector_1 =
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(1.0f), value_type);

  if (!linear_pre_saturated) {
    // Saturate, flushing NaN to 0.
    linear = builder_->createTriBuiltinCall(value_type, ext_inst_glsl_std_450_, GLSLstd450NClamp,
                                            linear, const_vector_0, const_vector_1);
  }

  spv::Id is_piece_at_least_3 = builder_->createBinOp(
      spv::OpFOrdGreaterThanEqual, bool_type, linear,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(512.0f / 1023.0f), value_type));
  spv::Id scale_3_or_2 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_3,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(1023.0f / 8.0f), value_type),
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(1023.0f / 4.0f), value_type));
  spv::Id offset_3_or_2 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_3,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(128.0f / 255.0f), value_type),
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(64.0f / 255.0f), value_type));

  spv::Id is_piece_at_least_1 = builder_->createBinOp(
      spv::OpFOrdGreaterThanEqual, bool_type, linear,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(64.0f / 1023.0f), value_type));
  spv::Id scale_1_or_0 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_1,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(1023.0f / 2.0f), value_type),
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(1023.0f), value_type));
  spv::Id offset_1_or_0 = builder_->createTriOp(
      spv::OpSelect, value_type, is_piece_at_least_1,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(32.0f / 255.0f), value_type),
      const_vector_0);

  spv::Id is_piece_at_least_2 = builder_->createBinOp(
      spv::OpFOrdGreaterThanEqual, bool_type, linear,
      SpirvSmearScalarResultOrConstant(builder_->makeFloatConstant(128.0f / 1023.0f), value_type));
  spv::Id scale = builder_->createTriOp(spv::OpSelect, value_type, is_piece_at_least_2,
                                        scale_3_or_2, scale_1_or_0);
  spv::Id offset = builder_->createTriOp(spv::OpSelect, value_type, is_piece_at_least_2,
                                         offset_3_or_2, offset_1_or_0);

  // gamma = trunc(linear * scale) * (1.0f / 255.0f) + offset
  return builder_->createNoContractionBinOp(
      spv::OpFAdd, value_type,
      builder_->createNoContractionBinOp(
          is_vector ? spv::OpVectorTimesScalar : spv::OpFMul, value_type,
          builder_->createUnaryBuiltinCall(
              value_type, ext_inst_glsl_std_450_, GLSLstd450Trunc,
              builder_->createNoContractionBinOp(spv::OpFMul, value_type, linear, scale)),
          builder_->makeFloatConstant(1.0f / 255.0f)),
      offset);
}

}  // namespace rex::graphics
